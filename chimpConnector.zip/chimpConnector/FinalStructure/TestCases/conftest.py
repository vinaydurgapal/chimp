import os
import time
from datetime import datetime
from selenium import webdriver
import pytest
from selenium.common import WebDriverException
from selenium import webdriver
from Utilities.logutil import LogGen


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    logger = LogGen.loggen()
    try:
        pytest_html = item.config.pluginmanager.getplugin("html")
        outcome = yield
        report = outcome.get_result()
        extra = getattr(report, "extra", [])
        if report.when == "call":
            feature_request = item.funcargs['request']
            driver = feature_request.getfixturevalue('setup_teardown_method')
            # always add url to report
            extra.append(
                pytest_html.extras.url("https://test.salesforce.com/"))
            xfail = hasattr(report, "wasxfail")
            if (report.skipped and xfail) or (report.failed and xfail) or report.outcome == "failed":
                # only add additional html on failure
                report_dir = os.path.dirname(item.config.option.htmlpath)
                file_name = str(int(round(time.time() * 1000))) + ".png"
                screenshot_repo = os.path.join("testcases", file_name)
                image_destination = os.path.join(report_dir, "testcases", file_name)
                driver.save_screenshot(image_destination)
                if file_name:
                    html = '<div><img src="%s" alt="screenshot" width="300" height="200" onclick="window.open(this.src)" align="right"/></div>' % \
                           screenshot_repo
                    extra.append(pytest_html.extras.html(html))
            report.extras = extra
    except Exception as e:
        # Handle any exception that may occur during the teardown (browser quit)
        logger.info(f"Exception occurred during browser teardown: {e}")


# @pytest.fixture(scope="session")
# def setup_teardown_method(request):
#     options = webdriver.ChromeOptions()
#     # driver = webdriver.Remote(
#     #     command_executor='http://127.0.0.1:4444/wd/hub',
#     #     options=options
#     # )
#     driver.maximize_window()
#     options.page_load_strategy = 'normal'
#     options.add_argument("disable-infobars")
#     options.add_argument("--disable-cache")
#     options.add_argument("--disable-extensions")
#     options.add_argument('--no-sandbox')
#     options.add_argument('--disable-application-cache')
#     options.add_argument('--disable-gpu')
#     options.add_argument("--disable-dev-shm-usage")
#     options.add_argument("--homepage=about:blank")
#     options.add_argument("--no-default-browser-check")
#     options.add_argument("--no-first-run")
#     options.add_argument("--disable-sync")
#     options.add_argument("--disable-default-apps")
#     options.add_argument("--disable-background-networking")
#     options.add_argument("--incognito")
#     driver.set_page_load_timeout(100)
#     driver.set_script_timeout(100)
#     yield driver
#     driver.quit()


from selenium import webdriver


@pytest.fixture(scope="session")
def setup_teardown_method(request):
    driver = webdriver.Chrome()
    yield driver
    driver.quit()

