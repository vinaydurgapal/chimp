import os
import configparser
import subprocess
import sys


def update_url_and_run_tests(url_path):
    sf_login_url = f"{url_path}"

    # Update the setup_url value in the ConfigurationData/data.ini file
    # For Now to run Recheck test case
    config = configparser.ConfigParser()
    config.read('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini')
    config.set('url', 'url', sf_login_url)

    with open('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini',
              'w') as configfile:
        config.write(configfile)

    os.system(f"--sf_login_url='{sf_login_url}'")


def run_scripts_in_order(config_file):
    # to the multiple test cases in the form of precheck functions
    # Create a ConfigParser object
    config = configparser.ConfigParser()
    # Read the configuration file
    config.read(config_file)

    # Get all paths to execute all tests
    test_paths = [path for script, path in config['ExecutionOrder'].items()]

    # List of precheck functions
    # List of precheck functions
    precheck_functions = [
        'test_precheck_function_name',
        'test_precheck_function_lname',
        'test_precheck_function_fname',
        'test_precheck_function_Mname'
    ]
    # Capture the output of the precheck functions
    precheck_output = []
    for precheck_function in precheck_functions:
        precheck_result = subprocess.run(
            ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
             '--html=Reports/prechecks_reports.html', '--self-contained-html', '-k', precheck_function, test_paths[0]],
            capture_output=True)
        # Reason : we used b 'passed ' in precheck_result.stdout.lower() because stdout of the subprocess is in bytes
        if b'passed' not in precheck_result.stdout.lower():
            retry_count = 0
            while retry_count < 2:
                precheck_result = subprocess.run(
                    ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
                     '--html=Reports/prechecks_reports.html', '--self-contained-html', '-k', precheck_function,
                     test_paths[0]],
                    capture_output=True)
                if b'passed' in precheck_result.stdout.lower():
                    break
                retry_count += 1
            print(f"{precheck_function} Not Configured Correctly. Exiting.")
            break
        precheck_output.append(precheck_result.stdout)
    else:
        # If all precheck functions pass, run the subsequent tests
        test_paths = test_paths[1:]  # Skip the test_login.py
        # Create the HTML report
        report_file = os.path.join('Reports', 'prechecks_reports.html')
        with open(report_file, 'w') as f:
            f.write('<html><body>')
            f.write('<h1>Precheck Report</h1>')
            f.write('<ul>')
            for output in precheck_output:
                f.write(f'<li>{output}</li>')
            f.write('</ul>')
            f.write('<h2>All Tests Report</h2>')
        subprocess.call(
            ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
             '--html=Reports/reports.html', '--self-contained-html'] + test_paths)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("URL not provided !")
        sys.exit(1)

    url_from_cli = sys.argv[1]
    update_url_and_run_tests(url_from_cli)

    # Run the scripts in order
    run_scripts_in_order('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/TestCases/script.ini')

