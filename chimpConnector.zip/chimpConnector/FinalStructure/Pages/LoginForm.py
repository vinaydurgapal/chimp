from selenium.webdriver.common.by import By

from Pages.BasePage import ActionOnElementUsingSelenium, ActionOnElementUsingJavaScript
from Utilities import configreader


class LoginForm(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):

    def __init__(self, driver):
        super().__init__(driver)

    def verifyLoginFunctionality(self):

        self.send_text_to_element(locator_strategy=By.NAME,
                                  locator_value=configReader.locatorsReadConfig("locators", "username_name"),
                                  send_text="practice", view="Login Page")

        self.send_text_to_element(locator_strategy=By.NAME,
                                  locator_value=configReader.locatorsReadConfig("locators", "password_name"),
                                  send_text="SuperSecretPassword!", view="Login Page")
        self.click_on_element(locator_strategy=By.CSS_SELECTOR,
                              locator_value=configReader.locatorsReadConfig("locators", "login_button_name"),
                              view="General")
        self.get_validation_text(locator_strategy=By.CSS_SELECTOR,
                                 locator_value=configReader.locatorsReadConfig("locators", "validation"),
                                 view="General")
