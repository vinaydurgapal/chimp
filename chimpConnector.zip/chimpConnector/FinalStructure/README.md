# SalesForce Automation Framework

Contains an Automation testing framework for platform application manager's SalesForce platform-related apps


## Project information:

| Environment                  | Details                                        |
|:-----------------------------|:-----------------------------------------------|
| Scripting Language           | Python V3.8.0                                  |
| Test Framework               | Pytest V7.2.1                                  |
| Reporting Package            | Pytest html V3.2.0                             |
| Browser Manipulation library | Selenium Webdriver V4.7.2                      |
| Execution Environment        | Selenium Grid/Docker                           |
| Platform                     | Linux-4.15.0-194-generic-x86_64-with-glibc2.27 |
| Packages                     | {"pluggy": "1.0.0", "pytest": "7.2.1"}         |
| Plugins                      | {"html": "3.2.0", "metadata": "2.0.4"}         |
| Docker Compose               | {(Docker Inc., v2.21.0) }                      |
| Allure Pytest                | { v2.13.2) }                                   |


## Naming Convention Used:
1. Package/Folder name: Camel casing with no gaps. Complete Words instead of Short
2. Class Name: Camel Casing with no gaps and prefixed with Test
3. Test Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word and prefixed with ‘test’
4. Calling Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word. Should be meaningful with structure <action_field_functionality>
5. Xpath Variable Name: small case with underscore separating each word. Name should be defined as such : Type_field_locator
6. Other Variable: Camel case has the first letter of each word capitalized except for the first word

## 11jun2024
1. Update run.py with url from cli 
2. And run the precheck functions in order 
3. On the basis of that run the test cases 
4. if precheck functions pass then only run the test cases otherwise exit the script and generate the report of failed precheck functions

