import pytest
from Pages.LoginForm import LoginForm
from TestCases.testCasesApp.SalesForceBaseTest import SalesForceBaseTest


class TestLogin(SalesForceBaseTest):
    def test_precheck_function_name(self):
        """Verifying the shop delete functionality
        Parameters:
        - Read From Utilities file by Readconfig function
        Returns:
        - Test Cases: Verifying the shop delete functionality
        """
        print("helklo")
        generalConfiguration = LoginForm(SalesForceBaseTest.driver)
        self.logger.info("helklo")
        generalConfiguration.verifyLoginFunctionality()

    def test_precheck_function_lname(self):
        """Verifying the shop delete functionality
        Parameters:
        - Read From Utilities file by Readconfig function
        Returns:
        - Test Cases: Verifying the shop delete functionality
        """
        generalConfiguration = LoginForm(SalesForceBaseTest.driver)
        generalConfiguration.verifyLoginFunctionality()
        #assert text == "You logged into a secure area!", "Login functionality not verified"

    def test_precheck_function_fname(self):
        """Verifying the shop delete functionality
        Parameters:
        - Read From Utilities file by Readconfig function
        Returns:
        - Test Cases: Verifying the shop delete functionality
        """
        generalConfiguration = LoginForm(SalesForceBaseTest.driver)
        generalConfiguration.verifyLoginFunctionality()

    def test_precheck_function_Mname(self):
        """Verifying the shop delete functionality
        Parameters:
        - Read From Utilities file by Readconfig function
        Returns:
        - Test Cases: Verifying the shop delete functionality
        """
        generalConfiguration = LoginForm(SalesForceBaseTest.driver)
        generalConfiguration.verifyLoginFunctionality()
