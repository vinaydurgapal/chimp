import pytest

from Pages.LoginForm import LoginForm
from TestCases.testCasesApp.SalesForceBaseTest import  SalesForceBaseTest


class TestLogins(SalesForceBaseTest):
    def test_login_functionalityss(self):
        """Verifying the shop delete functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        pytest.fail("Passe===========================")

