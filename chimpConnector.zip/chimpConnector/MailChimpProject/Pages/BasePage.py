from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Utilities.LogUtil import LogGen


class BasePage:

    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()
        self.wait = WebDriverWait(self.driver, timeout=100, poll_frequency=5)


class ElementPresenceCheck(BasePage):
    def __int__(self, driver):
        super().__init__(driver)

    def checks_for_element_presence(self, locator_strategy, locator_value,view):
        """
        Wait for the element present in the page.

        Parameters:
         - locator_strategy: The strategy used to locate the rows (e.g., By.XPATH).
         - locator_value: The value used with the locator strategy to locate the rows.
         - timeout: wait for the element

         Returns:
         - True if an element present, False otherwise.
        """
        try:
            self.wait.until((
                    EC.presence_of_element_located((locator_strategy, locator_value))
                    and EC.visibility_of_element_located((locator_strategy, locator_value))
                    and EC.element_to_be_clickable((locator_strategy, locator_value))
            ))
            element = self.driver.find_element(locator_strategy, locator_value)
            self.driver.execute_script("arguments[0].scrollIntoView({ behavior: 'smooth', block: 'center' });",
                                       element)
            self.driver.execute_script("arguments[0].focus();", element)
            self.logger.info(f"{view}: Focus Action Successfully !")
            return True
        except Exception as e:
            self.logger.error(f"{view} : Element {locator_value} not present .Other Exception Error: {e}")
            return False


class ActionOnElementUsingJavaScript(ElementPresenceCheck):
    def __init__(self, driver):
        super().__init__(driver)

    def send_text_to_element(self, locator_strategy, locator_value, send_text, view):
        if self.checks_for_element_presence(locator_strategy, locator_value,view):
            element = self.driver.find_element(locator_strategy, locator_value)
            self.driver.execute_script(f"arguments[0].value = '{send_text}';", element)
            self.logger.info(f"{view}:Text Send Successfully !")
        else:
            self.logger.error(f"{view} :Element {locator_value} not enable. Skipping send text action.")

    def click_on_element(self, locator_strategy, locator_value, view):
        if self.checks_for_element_presence(locator_strategy, locator_value,view):
            element = self.driver.find_element(locator_strategy, locator_value)
            self.driver.execute_script("arguments[0].click();", element)
            self.logger.info(f"{view}:Click On Element Successfully !")
        else:
            self.logger.error(f"{view} :Element {locator_value} not enable. Skipping click action.")

    def get_validation_text(self, locator_strategy, locator_value, view):
        if self.checks_for_element_presence(locator_strategy, locator_value, view):
            validation_text = self.driver.execute_script(
                f"return document.querySelector('{locator_value}').textContent")
            self.logger.info(f"{view}:Get Validation Text Successfully ! {validation_text}")
            return validation_text
        else:
            self.logger.error(f"{view} :Element {locator_value} not enabled. Skipping get validation action.")


class ActionOnElementUsingSelenium(ElementPresenceCheck):
    def __init__(self, driver):
        super().__init__(driver)

    def send_text_to_element(self, locator_strategy, locator_value, send_text, view):
        if self.checks_for_element_presence(locator_strategy, locator_value):
            element = self.driver.find_element(locator_strategy, locator_value)
            self.driver.execute_script("arguments[0].scrollIntoView({ behavior: 'smooth', block: 'center' });",
                                       element)
            self.driver.execute_script("arguments[0].focus();", element)
            self.driver.execute_script("arguments[0].value = 'practice';", send_text)
            self.logger.info(f"{view}:Text Send Successfully !")
        else:
            self.logger.error(f"{view} :Element {locator_value} not enable. Skipping send text action.")

    def click_on_element(self, locator_strategy, locator_value, view):
        if self.checks_for_element_presence(locator_strategy, locator_value):
            element = self.driver.find_element(locator_strategy, locator_value)
            self.driver.execute_script("arguments[0].scrollIntoView({ behavior: 'smooth', block: 'center' });",
                                       element)
            self.driver.execute_script("arguments[0].focus();", element)
            self.driver.execute_script("arguments[0].click();", element)
            self.logger.info(f"{view}:Click On Element Successfully !")
        else:
            self.logger.error(f"{view} :Element {locator_value} not enable. Skipping click action.")

    def get_validation_text(self, locator_strategy, locator_value, view):
        if self.checks_for_element_presence(locator_strategy, locator_value):
            element = self.driver.find_element(locator_strategy, locator_value)
            driver.execute_script("arguments[0].focus();", element)
            validation_text = driver.execute_script(
                "return document.querySelector('div.alert.alert-success.alert-dismissible.fade.show').textContent")
            self.logger.info(f"{view}:Get Validation Text Successfully !")
            return validation_text
        else:
            self.logger.error(f"{view} :Element {locator_value} not enable. Skipping get validation action.")
