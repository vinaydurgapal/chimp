import time

import pytest
import requests
from selenium.common import StaleElementReferenceException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.common.by import By

from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from Utilities import ConfigReader


class SF_Prechecks(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    def __init__(self, driver):
        super().__init__(driver)

    def check_url_status(self):
        try:
            response = requests.get(ConfigReader.dataReadConfig("setup url", "scratch_org_url"))
            if response.status_code == 200:
                self.logger.info(f"URL is  active. Status code: {response.status_code}")
                return True
            else:
                self.logger.error(f"URL is not active. Status code: {response.status_code}")
                return False
        except Exception as e:
            self.logger.error(f"An error occurred while checking URL: {e}")
            return False

    # Common Function
    def quick_find(self, send_text, view):
        self.sm_send_txt_to_elm(locator_strategy=By.CSS_SELECTOR,
                                locator_value=ConfigReader.locatorsReadConfig("salesforce prechecks locators",
                                                                              "quick_find_css"),
                                send_text=send_text, view=view)

    def site_select_and_register(self):
        # Objective : Registering the site
        self.sm_click_on_elm(locator_strategy=By.CSS_SELECTOR,
                             locator_value=ConfigReader.locatorsReadConfig("site enable locators", "setup_site_css"),
                             view="Home : Site : ")
        self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "setup_site_iframe_css"),
                                 view="Home : Site : Site Setup : Iframe : ")
        self.driver.switch_to.default_content()
        self.logger.info("function is used to switch back to the default content of the webpage")
        self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "setup_site_iframe_css"),
                                 view="Home : Site : Site Setup : Iframe : ")
        element_presence = self.return_elm_from_root_elm(locator_strategy=By.CSS_SELECTOR,
                                                         locator_value=ConfigReader.locatorsReadConfig(
                                                             "site enable locators",
                                                             "site_setup_form_css"),
                                                         view="Home : Site : Site Setup : Form:  ",
                                                         elm_locator_strategy=By.CSS_SELECTOR,
                                                         elm_locator_value=ConfigReader.locatorsReadConfig(
                                                             "site enable locators", "site_terms_use_css"),
                                                         elm_view="Home : Site : Site Setup : Form : Terms of Use Checkbox")
        if element_presence is not None:
            self.sm_get_the_elm_from_the_root_and_clk(locator_strategy=By.CSS_SELECTOR,
                                                      locator_value=ConfigReader.locatorsReadConfig(
                                                          "site enable locators",
                                                          "site_setup_form_css"),
                                                      view="Home : Site : Site Setup : Form:  ",
                                                      elm_locator_strategy=By.CSS_SELECTOR,
                                                      elm_locator_value=ConfigReader.locatorsReadConfig(
                                                          "site enable locators",
                                                          "site_terms_use_css"),
                                                      elm_view="Home : Site : Site Setup : Terms of Use Checkbox")
            self.sm_get_the_elm_from_the_root_and_clk(locator_strategy=By.CSS_SELECTOR,
                                                      locator_value=ConfigReader.locatorsReadConfig(
                                                          "site enable locators",
                                                          "site_setup_form_css"),
                                                      view="Home : Site : Site Setup : Form : ",
                                                      elm_locator_strategy=By.CSS_SELECTOR,
                                                      elm_locator_value=ConfigReader.locatorsReadConfig(
                                                          "site enable locators",
                                                          "site_register_btn_css"),
                                                      elm_view="Home : Site : Site Setup : Site Register")
            validation_text = self.sm_alerts_acceptance()
            self.logger.info(f"Home : Site : Site Setup : Form : Validation Text : {validation_text}")
            if 'Once you register, you will not be able to modify your Salesforce site domain name. Are you sure?' in validation_text:
                self.logger.info("Home : Site : Site Setup : Form : Site is registered")
            else:
                pytest.fail("Home : Site : Site Setup : Form : Site is not registered")
        else:
            self.logger.info("Home : Site : Site Setup : Form : Site is already registered")

    def site_select_and_enable(self):
        # Objective : Enabling the site
        self.sm_click_on_elm(locator_strategy=By.CSS_SELECTOR,
                             locator_value=ConfigReader.locatorsReadConfig("site enable locators", "setup_site_css"),
                             view="Home : Site : ")
        # iframe switch locator is same as site_select_and_register
        self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "setup_site_iframe_css"),
                                 view="Home : Site : Site Setup : Iframe : ")
        self.driver.switch_to.default_content()
        self.logger.info("function is used to switch back to the default content of the webpage")
        self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "setup_site_iframe_css"),
                                 view="Home : Site : Site Setup : Iframe : ")
        elm_attribute = self.sm_elm_attribute(locator_strategy=By.CSS_SELECTOR,
                                              locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                                            "site_active_css"),
                                              view="Home : Site : Site Setup : Form: ", attribute_value="alt")
        # self.logger.info("elm_attribute :" + elm_attribute)  # only string is concatenated none not
        self.logger.info(f'Attribute of the element : {elm_attribute}')
        if elm_attribute is None:
            time.sleep(5)  # for now using time sleep Reason: need to hold the page to load the frame completely
            self.sm_get_the_elm_from_the_root_and_clk(locator_strategy=By.CSS_SELECTOR,
                                                      locator_value=ConfigReader.locatorsReadConfig(
                                                          "site enable locators",
                                                          "btn_new_form_css"),
                                                      view="Home : Site : Site Setup : Form: ",
                                                      elm_locator_strategy=By.CSS_SELECTOR,
                                                      elm_locator_value=ConfigReader.locatorsReadConfig(
                                                          "site enable locators", "btn_new_css"),
                                                      elm_view="Home : Site : Site Setup : Form : New :")

            self.driver.switch_to.default_content()
            time.sleep(5)  # for now using time sleep Reason: need to hold the page to load the frame completely

            self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                     locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                                   "setup_site_iframe_css"),
                                     view="Home : Site : Site Setup : Iframe : ")

            self.sm_send_txt_to_elm(locator_strategy=By.CSS_SELECTOR,
                                    locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                                  "txt_site_label_css"),
                                    send_text=ConfigReader.dataReadConfig('setup prechecks', 'site_label_txt'),
                                    view='Home : Site : Site Setup : Form : New : Site Edit : site label')
            self.sm_click_on_elm(locator_strategy=By.CSS_SELECTOR,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "txt_site_name_css"),
                                 view="Home : Site : Site Setup : Form : New : Site Edit : site name")
            self.sm_click_on_elm(locator_strategy=By.CSS_SELECTOR,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "cb_tive_site_css"),
                                 view="Home : Site : Site Setup : Form : New : Site Edit : active checkbox")
            self.sm_send_txt_to_elm(locator_strategy=By.CSS_SELECTOR,
                                    locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                                  "txt_active_site_page_css"),
                                    send_text=ConfigReader.dataReadConfig('setup prechecks', 'active_site_home_page'),
                                    view='Home : Site : Site Setup : Form : New : Site Edit : site label')

            self.sm_click_on_elm(locator_strategy=By.CSS_SELECTOR,
                                 locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                               "save_btn_css"),
                                 view="Home : Site : Site Setup : Form : New : Site Edit : Save :")
            self.driver.switch_to.default_content()
            time.sleep(5)  # for now using time sleep Reason: need to hold the page to load the frame completely

            self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                     locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                                   "setup_site_iframe_css"),
                                     view="Home : Site : Site Setup : Iframe : ")
            time.sleep(5)  # for now using time sleep Reason: need to hold the page to load the frame completely
            elm_verification = self.js_get_vld_txt(locator_strategy=By.CSS_SELECTOR,
                                                   locator_value=ConfigReader.locatorsReadConfig("site enable locators",
                                                                                                 "txt_site_vld_css"),
                                                   view="Home : Site : Site Setup : Form : New : Site Edit : Validation :")
            return elm_verification

        else:
            self.logger.info("Site is already enabled")
            return "Site is already enabled"

    # Object Related Precheck
    # Common Function
    def select_object_manager(self, send_text=None, view=None):
        self.js_click_on_elm(locator_strategy=By.CSS_SELECTOR,
                             locator_value=ConfigReader.locatorsReadConfig("Object manager page layout locators",
                                                                           "lnk_object_manager_css"),
                             view="Home : Page Layout : Object Manager : ")
        self.sm_send_txt_to_elm(locator_strategy=By.CSS_SELECTOR,
                                locator_value=ConfigReader.locatorsReadConfig("Object manager page layout locators",
                                                                              "txt_quick_find_css"),
                                send_text=send_text,
                                view=view)

    # Element name should be defined as such:
    # page_layout as pl
    def audience_mailchimp_pc_pl(self, locator_strategy, locator_value, view):
        self.sm_switch_to_iframe(locator_strategy=locator_strategy,
                                 locator_value=locator_value,
                                 view=view)

    def audience_mailchimp_pc(self, locator_strategy, locator_values, view, required_text=None):
        # Objective: Audience:Mailchimp Custom Object
        # Verify the Audience:Mailchimp page layout functionality
        # Verify the Audience:Mailchimp related list
        """Verify the Audience:Mailchimp page layout functionality and related list.

        Args:
            locator_values:
            locator_strategy (str): The strategy to locate the element.
            view (str): The view where the action is taking place.
            required_text (str, optional): The text required for verification. Defaults to None.
        """
        # aggressively click on the list items for that we need to hold the page until the list is loaded completely otherwise it gives an error
        # element node id not found
        # time.sleep(5)
        # storing_list = self.sm_return_list_of_elms(locator_strategy=locator_strategy,
        #                                            locator_value=locator_values,
        #                                            view=view)
        # for storing_elm in storing_list:
        #     try:
        #         if str(required_text) in storing_elm.text:
        #             self.logger.info(f"{view} : {storing_elm.text} : Clicked Successfully")
        #             storing_elm.click()
        #             # self.driver.execute_script("arguments[0].click();", storing_elm)
        #             break
        #     except StaleElementReferenceException:
        #         try:
        #             if str(required_text) in storing_elm.text:
        #                 self.logger.info(f"{view} : {storing_elm.text} : Clicked Successfully")
        #                 storing_elm.click()
        #                 # self.driver.execute_script("arguments[0].click();", storing_elm)
        #                 break
        #         except StaleElementReferenceException:
        #             pass
        max_retries = 5
        retry_interval = 2

        for _ in range(max_retries):
            time.sleep(retry_interval)
            storing_list = self.sm_return_list_of_elms(locator_strategy=locator_strategy, locator_value=locator_values,
                                                       view=view)

            for storing_elm in storing_list:
                try:
                    if str(required_text) in storing_elm.text:
                        self.logger.info(f"{view} : {storing_elm.text} : Clicked Successfully")
                        storing_elm.click()
                        break
                except StaleElementReferenceException:
                    storing_list = self.sm_return_list_of_elms(locator_strategy=locator_strategy,
                                                               locator_value=locator_values,
                                                               view=view)
                    for storing_elms in storing_list:
                        try:
                            if str(required_text) in storing_elm.text:
                                self.logger.info(f"{view} : {storing_elms.text} : Clicked Successfully")
                                storing_elms.click()
                                break
                        except StaleElementReferenceException:
                            pass
            else:
                continue

            # Break out of the outer loop if an element is successfully stored
            break
        else:
            self.logger.info("Element not stored after 5 retries..............")

    # Not in use yet but latter i will use it
    def audience_mailchimp_pc_root_elm(self, locator_strategy, locator_values, view, elm_locator_strategy,
                                       elm_locator_value, elm_view, required_text=None):
        # Objective: Audience:Mailchimp Custom Object
        # Verify the Audience:Mailchimp page layout functionality
        # Verify the Audience:Mailchimp related list
        """Verify the Audience:Mailchimp page layout functionality and related list.

        Args:
            elm_view:  The view where the action is taking place.
            elm_locator_value: The strategy to locate the element.
            elm_locator_strategy:
            locator_values:
            locator_strategy (str): The strategy to locate the element.
            view (str): The view where the action is taking place.
            required_text (str, optional): The text required for verification. Defaults to None.
        """
        self.wait_for_page_load()
        storing_list = self.return_elms_from_root_elm(locator_strategy=locator_strategy,
                                                      locator_value=locator_values,
                                                      view=view,
                                                      elm_locator_strategy=elm_locator_strategy,
                                                      elm_locator_value=elm_locator_value,
                                                      elm_view=elm_view)
        for storing_elm in storing_list:
            try:
                if str(required_text) in storing_elm.text:
                    self.driver.execute_script("arguments[0].click();", storing_elm)
                    self.logger.info(f"{view} : {storing_elm.text} : Clicked Successfully")
                    break
            except StaleElementReferenceException:
                try:
                    if str(required_text) in storing_elm.text:
                        self.driver.execute_script("arguments[0].click();", storing_elm)
                        self.logger.info(f"{view} : {storing_elm.text} : Clicked Successfully")
                        break
                except StaleElementReferenceException:
                    pass

    def audience_mailchimp_pcs(self, locator_strategy, locator_value, view):
        # Objective: Audience:Mailchimp Custom Object
        # Verify the Audience:Mailchimp page layout functionality
        # Verify the Audience:Mailchimp related list
        time.sleep(5)
        max_retries = 3
        retry_count = 0
        while retry_count < max_retries:
            try:
                self.sm_click_on_elm(locator_strategy, locator_value, view)
                break  # Exit the loop if successful
            except StaleElementReferenceException:
                retry_count += 1
                if retry_count == max_retries:
                    # Log an error or handle the exception after max retries
                    print("Max retries reached. Unable to click on the element.")
                else:
                    # Retry the action
                    print("Retrying to click on the element...")

    def audience_mailchimp_fields(self, locator_strategy, locator_value, view):
        """
        The objective of the audience_mailchimp_fields method is to retrieve the
         text from elements identified by the provided locator_strategy and
         locator_value and store this text in a list named fields_level_data.
          Finally, it returns this list of text data.

        """
        fields_level_data = []
        storing_list = self.sm_return_list_of_elms(locator_strategy=locator_strategy,
                                                   locator_value=locator_value,
                                                   view=view)
        for storing_elm in storing_list:
            field_txt = storing_elm.text
            fields_level_data.append(field_txt)
        return fields_level_data

    def audience_mailchimp_drag_field(self, locator_strategy, locator_value, view,
                                      s_locator_strategy, s_locator_value, s_view,
                                      c_locator_strategy, c_locator_value, c_view,
                                      qb_locator_strategy, qb_locator_value, qb_view, expected_data):
        self.driver.switch_to.default_content()
        self.logger.info("function is used to switch back to the default content of the webpage")
        self.sm_switch_to_iframe(locator_strategy=By.XPATH,
                                 locator_value=ConfigReader.locatorsReadConfig(
                                     "Object manager page layout locators",
                                     'iframe_layout_xpath'),
                                 view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : ")
        target_element = self.sm_return_elm(locator_strategy=locator_strategy,
                                            locator_value=locator_value,
                                            view=view)
        x_offset = target_element.location_once_scrolled_into_view['x']
        y_offset = target_element.location_once_scrolled_into_view['y']
        expected_list = expected_data
        for expected_title in expected_list:
            try:
                source_elements = self.sm_return_list_of_elms(locator_strategy=s_locator_strategy,
                                                              locator_value=s_locator_value,
                                                              view=s_view)
                for source_element in source_elements:
                    actual_title = source_element.text
                    self.logger.info(f"Trying to drag the element: {actual_title}")
                    if actual_title == expected_title:
                        container = self.sm_return_list_of_elms(locator_strategy=c_locator_strategy,
                                                                locator_value=c_locator_value,
                                                                view=c_view)
                        scroll_amount = 1000
                        self.driver.execute_script(f"arguments[0].scrollLeft += {scroll_amount};", container)
                        # time.sleep(4)  # Due Page Loading time
                        try:
                            actions = ActionChains(self.driver)
                            actions.key_down(Keys.SHIFT)
                            actions.click(source_element)
                            actions.key_up(Keys.SHIFT)
                            actions.click_and_hold(source_element)
                            actions.move_by_offset(x_offset, y_offset)
                            actions.release(
                                target_element)
                            actions.perform()
                        except StaleElementReferenceException:
                            self.logger.info(
                                "Stale element reference encountered during drag and drop. Retrying...")
                            continue
            except StaleElementReferenceException:
                self.logger.info("Stale element reference encountered. Continuing with the loop.")
                continue
            self.sm_move_and_click_on_elm(locator_strategy=qb_locator_strategy,
                                          locator_value=qb_locator_value,
                                          view=qb_view)
        # time.sleep(5)  # Due Page Loading time
        self.sm_move_and_click_on_elm(locator_strategy=qb_locator_strategy,
                                      locator_value=qb_locator_value,
                                      view=qb_view)
