#!/bin/bash

echo "Creating backup and Delete Last report"
cd /var/www/html/staging/ && tar -cvf /var/www/html/backups/staging/PAM_$(date +%Y%m%d%H%M).tar Reports_wix && cd -
ls -t /var/www/html/backups/staging/ | sort -r | tail -n +4 | xargs -I {} rm /var/www/html/backups/staging/{}
rm -rf /var/www/html/staging/Reports_wix/

echo "start selenium"

# Start drivers one by one and wait for each to exit before starting the next one
docker-compose -f docker-compose-v3-dev-channel.yml up -d

sleep 15 # Added Sleep to allow wait for docker ready

docker ps -a

echo "Open the Grid URL: http://192.168.1.31:4444/ui#/sessions and use password (secret) to check selenium running status"

echo "Start Salesforce Automation Framework script"

python3 run.py

echo "stop docker container"

# For Stopping Grid
docker-compose -f docker-compose-v3-dev-channel.yml down

# - docker-compose -f docker-composer-dev.yml stop
echo "Creating URL of report for Attaching with Mail"
rsync -rav /home/gitlab-runner/builds/AUsumrrS/0/pam_automation/pam_wix_automation_framework/Reports/ /var/www/html/staging/Reports_wix/
#mv /var/www/html/Reports /var/www/html/Reports_wix

echo "To check Salesforce automation Framework's test Report open: http://192.168.1.31/staging/Reports_wix/reports.html"

echo "Sending Email Notification"

python3 mail_staging.py

echo "Process Completed"