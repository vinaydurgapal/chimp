# SalesForce Automation Framework

Contains an Automation testing framework for platform application manager's SalesForce platform-related apps


## Project information:

| Environment                  | Details                                        |
|:-----------------------------|:-----------------------------------------------|
| Scripting Language           | Python V3.8.0                                  |
| Test Framework               | Pytest V7.2.1                                  |
| Reporting Package            | Pytest html V3.2.0                             |
| Browser Manipulation library | Selenium Webdriver V4.7.2                      |
| Execution Environment        | Selenium Grid/Docker                           |
| Platform                     | Linux-4.15.0-194-generic-x86_64-with-glibc2.27 |
| Packages                     | {"pluggy": "1.0.0", "pytest": "7.2.1"}         |
| Plugins                      | {"html": "3.2.0", "metadata": "2.0.4"}         |
| Docker Compose               | {(Docker Inc., v2.21.0) }                      |
| Allure Pytest                | { v2.13.2) }                                   |


## Naming Convention Used:
1. Package/Folder name: Camel casing with no gaps. Complete Words instead of Short
2. Class Name: Camel Casing with no gaps and prefixed with Test
3. Test Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word and prefixed with ‘test’
4. Calling Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word. Should be meaningful with structure <action_field_functionality>
5. Xpath Variable Name: small case with underscore separating each word. Name should be defined as such : Type_field_locator
6. Other Variable: Camel case has the first letter of each word capitalized except for the first word

###
NOTE:
1. Use All types of CLick functionality in this framework like  
2. Selenium Action 
3. Javascript CLick Execution 
4. Simple Driver Click Functionality
## Points We Have Covered 31 jan 2024
Phase 1: Sprint 1: Task details ->

# Cover the basic architecture and create the test plan for covering, pre-checks
1. a. Shopify End preChecks. Configure Payment. Setup Shipments
2. Give Admin level access (Read And Write)
3. Salesforce End Pre-Checks
4. Enable PriceBook
5. Enable Site To achieve Real time Syncing
6. Enable Permission Set and Assign to the User to configure the application
7. Enable Reduction Order flow
8. Enable check for session setting->Lightning Web Security->Use Lightning Web Security for Lightning web components and Aura components

# Cover the Configuration page related scenarios
1. Global settings
-> verification and validation
2. Configuration Page verification
-> All static elements available in default without enabling any feature or option from store configuration

## Allure report CLI (14-feb-2024)

1. pytest --alluredir=<output_directory>
2. allure serve <output_directory>

## Phase 2: Sprint 2: Task details ->


1. Verify SaleForce Dashboard Side Views

. Collections. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import .
. Products. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import. Products. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import 
. Location. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting  , Delete  , Mass Import
. Customers. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import
. Orders. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import , Drfat Order
. Leads First Enable This View from Object setting. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import
. Opportunity: First Enable This View from Object setting. Total Record and Total Loaded Record, Search , Refresh , Filter , Setting , Plus Icon (Add ) , Delete , Add Condition , Mass Import . Order

1. Verify The listed Action present inside the side views
2. For Now I made Add Button Functionality for required fields only


## Phase 3: Sprint 3: Task details ->
Cover the Configuration page related scenarios
a. Global settings
-> verification and validation
b. Configuration Page verification
-> All static elements available in default without enabling any feature or option from store configuration

## Phase 4: Sprint 4 : Task details

1. Mark proper log for prechecks (shopify end)
2. Correction in Parametrization function (Configuration section )
3. Dynamic Locator for dropdown specially when click on the element
(First get the locator of that element , validate it and then click on it )
4. Right now I'm scrolling the page on the view of Element (Try to scroll the page on the basis of side scroll bar : selenium driver provide that feature )
5. Mark the Points Sprint-wise in Readme file
6.SIDE VIEW : Now We have to verify and validate Record Level fileds on the basis of  Object setting (Configuration ) Section
Verify Only these functionality
.Import
.Export
 
later we will verify them on the basis of these fields
. MultiStore
. MultiCurrency
. Metafield
. Conditional Import
. Conditional Export
. Schedule Import
7. Right now we are just checking the Drop-down Enablity and select the random element from dropdown on the basis of their locators . When we are using thoes drop down for actual or internal features then we will get the element text and check verify thoes element text as per our reqiurment and then click on that particular element that make the function more dynamic

8. Set required page layouts for side views (SalesForce Eshopify Esync)

## Phase 5: Sprint 5 : Task details

1. Sync Condition 
2. Record Type Mapping
3. Matching Criteria

### Some CLI Added Command in Pytest.in and Run.py file

1. Display progress of Test Cases Along with test cases 
2. Proper indentation in logs
3. console_output_style = progress
4. console_output_style = progress
5. log-auto-indent = True
6. Remove -s from run.py
