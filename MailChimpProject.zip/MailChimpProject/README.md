# SalesForce Automation Framework

Contains an Automation testing framework for platform application manager's SalesForce platform-related apps


## Project information:

| Environment                  | Details                                        |
|:-----------------------------|:-----------------------------------------------|
| Scripting Language           | Python V3.8.0                                  |
| Test Framework               | Pytest V7.2.1                                  |
| Reporting Package            | Pytest html V3.2.0                             |
| Browser Manipulation library | Selenium Webdriver V4.7.2                      |
| Execution Environment        | Selenium Grid/Docker                           |
| Platform                     | Linux-4.15.0-194-generic-x86_64-with-glibc2.27 |
| Packages                     | {"pluggy": "1.0.0", "pytest": "7.2.1"}         |
| Plugins                      | {"html": "3.2.0", "metadata": "2.0.4"}         |
| Docker Compose               | {(Docker Inc., v2.21.0) }                      |
| Allure Pytest                | { v2.13.2) }                                   |


## Naming Convention Used:
1. Package/Folder name: Camel casing with no gaps. Complete Words instead of Short
2. Class Name: Camel Casing with no gaps and prefixed with Test
3. Test Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word and prefixed with ‘test’
4. Calling Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word. Should be meaningful with structure <action_field_functionality>
5. Xpath Variable Name: small case with underscore separating each word. Name should be defined as such : Type_field_locator
6. Other Variable: Camel case has the first letter of each word capitalized except for the first word

## 11jun2024
1. Update run.py with url from cli
2. And run the precheck functions in order
3. On the basis of that run the test cases
4. if precheck functions pass then only run the test cases otherwise exit the script and generate the report of failed precheck functions


## 12june2024
1. NOTE: Before using Base Class Please read these Shortcuts of Selenium , Javascript , Text , Send , click , element , validation
javascript = js
Selenium = sm
Text = txt
Send = snd
click = clk
element = elm
validation = vld


1. NOTE: Before running locator.ini file make sure read comment section bellow
element locators button=btn
element locators input=inp
element locators css=css
element locators xpath=xp
element locators link=lk
element locators id=id
element locators name=nm
element locators class=cls

. File name update
SalesForce = SF
salesforce = sf

1. Update Base class Function For both javascript and Selenium based function
2. Docker is not running , test cases are running in Queue , So for now i had update the conftest to run the test cases in local browser
3. Update run.py Because as per the discussion we do not need to make separate html file for prechecks either fail or pass try to configure all prechecks in same report.html in both cases


### 14june2024

1. Make Precheck to check Scratch org url is active or not 
2. Make Browser initialization function dynamic for all(Chrome,firefox,edge) , on the basis of user input from cli
3. Make common precheck for object manager , to get the custom and standard object 
4. Explore run to precheck conditionally oon the basis of indexing, although it is working but still need to verify it with other precheck as well 
5. update locator strategy ex. txt_quick_find_css (mark field info at the first of the locator value)

### 17 june 2024
1. Update Base page code 
2. Reason : In some Unable to locate element directly , to locate them directly need to locate parent element 
3. Make this prechecks
4. 'test_pc_url_status','test_pc_site_register',    'test_pc_site_enable','test_pc_object_manager'

### 18 jun 2024
1. Common function for Mailchimp page layout functionality
2. 'test_pc_audience_mc',
3. 'test_pc_campaign_mc',
4. 'test_pc_segment_mc',
5. 'test_pc_tag_mc',
6. 'test_pc_group_mc'
7. Along with it Explore when we have to use javascript based functionality and when selenium in build functionality
Reason : Facing such error at the time of development
8. self.error_handler.check_response(response) ../../../.local/lib/python3.8/site-packages/selenium/webdriver/remote/errorhandler.py:229: in check_response raise exception_class(message, screen, stacktrace) E selenium.common.exceptions.TimeoutException: Message: Unable to execute request for an existing session: java.util.concurrent.TimeoutException E Build info: version: '4.10.0', revision: 'c14d967899' E System info: os.name: 'Linux', os.arch: 'amd64', os.version: '5.15.0-107-generic', java.version: '11.0.19' E Driver info: driver.version: unknown E Stacktrace: E java.lang.RuntimeException: Unable to execute request for an existing session: java.util.concurrent.TimeoutException E Build info: version: '4.10.0', revision: 'c14d967899' E System info: os.name: 'Linux', os.arch: 'amd64', os.version: '5.15.0-107-generic', java.version: '11.0.19' E Driver info: driver.version: unknown
9. Related with unable to find node of the element

Solution for that is
1. When you use selenium in build function, it directly interacts with the browser through the WebDriver,
2. And when we use javascript related function , such function are not work along with webdriver , javscript function some time by pass the website checks due to which some time it fail to maintain a session and gives an session error

3. Locate strategy :
href link :
4. org href : [href="/one/one.app#/setup/ObjectManager/01ID10000002lvY/view"]
5. org href : [href="/one/one.app#/setup/ObjectManager/01IO4000001BY5w/view"]

the only difference is of link id so for that cases we can locate them this way
Solution of such locator

1. [href*="/one/one.app#/setup/ObjectManager/"][href*="/view"]

### 21 june 2024 
4. Salesforce Object: Record Type: Create {NOTE : Make Both Type of Record Type (Active )}
Campaign
Segment:Mailchimp
Contact
Tag:Mailchimp
Groups:Mailchimp
Campaign:Mailchimp
Subscriber:Mailchimp

### 28 june 2024 
TC_Audience.py :

Verifying the Refresh Button Of Page View Of Audience
Verifying the Select Default Audience
Verifying the Audience Mass Import

TC_Campaigns.py

Verifying the Refresh Button Of Page View Of Audience
Verifying the Select Default Audience
Verifying the Audience Mass Import

TC_Configuration.py
Verifying the Refresh Button Of Page View Of Campaigns

TC_Groups.py
Verifying the Refresh Button Of Page View Of Audience
Verifying the Select Default Audience
Verifying the Select Default Audience Groups
Verifying the Audience Mass Import

TC_MailchimpContacts.py

Verifying the Refresh Button Of Page View Of Audience
Verifying the Select Default Audience
Verifying the Select Default Audience Groups
Verifying the Audience Mass Import

TC_Segments.py
Verifying the Refresh Button Of Page View Of Audience
Verifying the Select Default Audience
Verifying the Select Default Audience Groups
Verifying the Audience Mass Import

TC_Tags.py
Verifying the Refresh Button Of Page View Of Audience
Verifying the Select Default Audience
Verifying the Select Default Audience Groups
Verifying the Audience Mass Import

 

 

1. Made common function for loader to avoid time sleep 

2. Made Common function for mass import  progress bar to avoid time sleep


### 1 july 2024 
TC_Audience.py :
Verifying select field to Search (In progress) : DONE

TC_Campaigns.py
Verifying select field to Search (In progress): DONE

TC_Groups.py
Verifying select field to Search (In progress) : DONE

TC_MailchimpContacts.py
Verifying select field to Search (In progress) : DONE

TC_Segments.py
Verifying select field to Search (In progress) : DONE

TC_Tags.py
Verifying select field to Search (In progress) : DONE


### 3 july 2024 
TC_Audience.py
Verifying the Audience , Delete Field
Verifying the Audience , Utility Setting Selected Field to search and save
Verifying the Audience , Filter button functionality: In Progress

TC_Campaigns.py
Verifying the Campaigns , Delete Field
Verifying the Audience , Utility Setting Selected Field to search and save
Verifying the Audience , Filter button functionality In Progress

TC_Configuration.py
TC_Groups.py
Verifying the Groups , Delete Field
Verifying the Audience , Utility Setting Selected Field to search and save
Verifying the Audience , Filter button functionality In Progress

TC_MailchimpContacts.py
Verifying the MailchimpContacts , Delete Field
Verifying the Audience , Utility Setting Selected Field to search and save
Verifying the Audience , Filter button functionality In Progress

TC_Prechecks.py
TC_Segments.py
Verifying the Segments , Delete Field
Verifying the Audience , Utility Setting Selected Field to search and save
Verifying the Audience , Filter button functionality In Progress

TC_Tags.py
Verifying the Tags , Delete Field
Verifying the Audience , Utility Setting Selected Field to search and save
Verifying the Audience , Filter button functionality In Progress

1. Make common and dynamic function for Select field to display and select field to serach
2. Make Common and dynamic function for filter button functionality


### 4 july 2024 

1. Keys Action is not working properly in the Filter button functionality.
2. Switch Frame method is also not working properly.
3. At the end, I have use mouse action functionality:

Use These steps :

First, hover over the element.
Click and hold the element.
Use element X and Y offset to send text to the desired location.

the final function is this to handle filter button functionality



### 8 july 2024 

TC_Campaigns.py

Verifying the Audience , Filter button functionality

TC_MailchimpContacts.py
Verifying the MailchimpContacts , Filter button functionality

Not Working currently
Reason : Value field not taking proper input

 

Make toggle based locator : dynamically  by using target locate  text onlge 

same thing we can do for other locate as well on the basis of there label text 

### 10 july 2024 
make some Function apart from update locators 

Reason : Update Conditional logic

.

clickOnElementTemp
.
typeOnElementTemp
.
returnElementTemp
 
1. To remove Time Sleep from some test cases in place of that we have to wait for loader 
So I have loader wait function and remove time sleep from thoes places 
. wait_for_loader_to_disappear
2. Try to remove time sleep from progress bar as well but currently it is not working 
 
.
wait_for_progress_bar


### 12 july 2024 
1. Push Updated code on git branch name : Dev_vinay

2. Due to Opportunity some test cases are getting xfail : reason product are not properly deleting due to what ever the changes we are making for test cases is not displyaying , in result tets case status is : Xfail to avoid such case , I have made on function in test file which will delete opportunity , if they exist

3. Make some function base class using logger error not with pytest.fail  

. clickOnElementTemp

. typeOnElementTemp
. returnElementTemp


### 13 july 2024 

Make Structure
TestCases
TC_MailChimp
TC_SalesforceChimp
Test_Dashboard
__init__.py
TC_Audience.py
TC_Campaigns.py
TC_Configuration.py
TC_Configuration_Global_Setting.py
TC_Groups.py
TC_MailchimpContacts.py
TC_Segments.py
TC_Tags.py
Separate folder for Edit CConfiguration tabs
Test_Edit_Configurations
__init__.py
TC_EC_General_Setting.py
TC_EC_Merge_Field_Mapping.py
TC_EC_Real_Time_Setting.py
TC_EC_Record_Type_Mapping.py
TC_EC_Sync_Conditions.py
__init__.py
BaseTest_SF.py
TC_Prechecks.py

1. Update Dashboard view Test cases which will skip if setup fail
2. Make Test Plan For Sprint 3



### 16 july 2024 
For Edit Configuration General Setting :-

1.
Test case to edit the configuration setting.
1. 
test_create_lead_of_mailChimp_subscriber
1. 
test_create_contact_of_mailChimp_subscriber
1. 
test_create_subscriber_only_when_email_matches
 
1. Make Common function for toggle button functionality :
2. Basic Structure for edit configuration functionality

script10 = TestCases/TC_SalesforceChimp/Test_Edit_Configurations/TC_EC_Merge_Field_Mapping.py
script11 = TestCases/TC_SalesforceChimp/Test_Edit_Configurations/TC_EC_Real_Time_Setting.py
script12 = TestCases/TC_SalesforceChimp/Test_Edit_Configurations/TC_EC_Record_Type_Mapping.py
script13 = TestCases/TC_SalesforceChimp/Test_Edit_Configurations/TC_EC_Sync_Conditions.py


### 17 july 2024 
1.
TC_EC_General_Setting.py
.Test case to create a lead of MailChimp subscriber.

.Test case to create a contact of MailChimp subscriber.

.Test case to create a subscriber only when email matches.

.Test method to change the field in the default view. (Call only when we need )

2.
TC_EC_Log_Setting.py
.This test case clicks on the edit icon of Log Setting and sets the number of days to 5.
It then saves the configuration and checks if the validation message is "Success".
If the validation message is not "Success", it closes the modal and fails the test.

.Test case to create a webhook log in the configuration settings.

3.
TC_EC_Merge_Field_Mapping.py
.Test case to edit the configuration setting for lead mapping.

.Test case to edit the configuration setting for contact mapping.

.Test case to edit the configuration setting for dynamic mapping.

4.
TC_EC_Real_Time_Setting.py

.This test case verifies that the configuration setting is successfully edited real site selection.

.This test case verifies that the configuration setting is successfully edited webhook list.

.This test case verifies that the configuration setting is successfully edited export setting.

### 19 july 2024 
## Merge Field Mapping
test cases related with merge field mapping

### test_lead_mapping_import_export_update_on
test cases related with merge field mapping: import, export, and update operations

### test_lead_mapping_import_on
test cases related with merge field mapping: import operation

### test_lead_mapping_update_on
test cases related with merge field mapping: update operation

### test_lead_mapping_export_on
test cases related with merge field mapping: export operation

### test_lead_mapping_import_export_update_off
test cases related with merge field mapping: import, export, and update operations turned off

### test_lead_mapping_teardown
test cases related with merge field mapping: teardown

### test_contact_mapping_import_and_export
test cases related with merge field mapping: import and export operations for contacts

### test_contact_mapping_import_on
test cases related with merge field mapping: import operation for contacts

### test_contact_mapping_import_export_on
test cases related with merge field mapping: import and export operations for contacts

### test_contact_mapping_import_and_export_off
test cases related with merge field mapping: import and export operations for contacts turned off

### test_contact_mapping_teardown
test cases related with merge field mapping: teardown for contacts

### 20 july 2024

1. Update log info : update the log info in each test case step.

2. Make tear down for Edit configuration tap: create a separate tear down method specifically for the Edit configuration tap. This method can be called after each test case that involves the Edit configuration tap.

3. Make setup method for all test cases: create a setup method that is called before each test case. This method can set up any common resources or configurations that are needed for all test cases.

4. Make individual folder/packages/files for all views: organize your test cases into separate folders or packages based on the views they test. For example, you could create a folder for each view and organize the test cases within those folders

Setup_Methods
SF_Setup_Methods
SF_SM_Dashboards
SF_SM_Edit_Configuration
__init__.py
SF_General_Setting.py
SF_Log_Setting.py
SF_Merge_Field_Mapping.py
SF_Real_Time_Setting.py
SF_Record_Type_Mapping.py
__init__.py

__init__.py
TC_MailChimp
TC_SalesforceChimp
Test_Dashboard

__init__.py
TC_Audience.py
TC_Campaigns.py
TC_Configuration.py
TC_Configuration_Global_Setting.py
TC_Groups.py
TC_MailchimpContacts.py
TC_Segments.py
TC_Tags.py
Test_Edit_Configurations

__init__.py
TC_EC_General_Setting.py
TC_EC_Log_Setting.py
TC_EC_Merge_Field_Mapping.py
TC_EC_Real_Time_Setting.py
TC_EC_Record_Type_Mapping.py
TC_EC_Sync_Conditions.py

__init__.py
BaseTest_SF.py
TC_Prechecks.py
Teardown_Methods
SF_Teardown_Methods
__init__.py
SF_LS_Teardown_Methods.py
SF_MF_Teardown_Methods.py


### 23 july 2024 

1. Test Case: test_contact
- Description: Test case to validate the contact functionality.

2. Test Case: test_lead
- Description: Test case to validate the lead functionality.

3. Test Case: test_campaign_mailchimp
- Description: Test case to validate the campaign functionality for Mailchimp.

4. Test Case: test_subscriber
- Description: Test case to validate the subscriber functionality.

5. Test Case: test_Segment
- Description: Test case to validate the segment functionality.

6. Test Case: test_Tag
- Description: Test case to validate the tag functionality.

7. Test Case: test_groups
- Description: Test case to validate the groups functionality.


### 25 july 2024 

@pytest.mark.task1
def test_stop_record_creation_mailchimp_contacts_setup():
# Test setup for stopping record creation for Mailchimp contacts

# Task 2
@pytest.mark.task2
def test_stop_record_creation_contact_setup():
# Test setup for stopping record creation for contacts

# Task 3
@pytest.mark.task3
def test_stop_record_creation_group_setup():
# Test setup for stopping record creation for groups

# Task 4
@pytest.mark.task4
def test_stop_record_creation_segments_setup():
# Test setup for stopping record creation for segments

# Task 5
@pytest.mark.task5
def test_stop_record_creation_lead_setup():
# Test setup for stopping record creation for leads

# Task 6
@pytest.mark.task6
def test_allow_record_creation_segment_setup():
# Test setup for allowing record creation for segments

# Task 7
@pytest.mark.task7
def test_allow_record_creation_mailchimp_contacts_setup():
# Test setup for allowing record creation for Mailchimp contacts

# Task 8
@pytest.mark.task8
def test_allow_record_creation_contact_setup():
# Test setup for allowing record creation for contacts

# Task 9
@pytest.mark.task9
def test_allow_record_creation_group_setup():
# Test setup for allowing record creation for groups

# Task 10
@pytest.mark.task10
def test_allow_record_creation_lead_setup():
# Test setup for allowing record creation for leads