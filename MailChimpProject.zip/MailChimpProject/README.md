# SalesForce Automation Framework

Contains an Automation testing framework for platform application manager's SalesForce platform-related apps


## Project information:

| Environment                  | Details                                        |
|:-----------------------------|:-----------------------------------------------|
| Scripting Language           | Python V3.8.0                                  |
| Test Framework               | Pytest V7.2.1                                  |
| Reporting Package            | Pytest html V3.2.0                             |
| Browser Manipulation library | Selenium Webdriver V4.7.2                      |
| Execution Environment        | Selenium Grid/Docker                           |
| Platform                     | Linux-4.15.0-194-generic-x86_64-with-glibc2.27 |
| Packages                     | {"pluggy": "1.0.0", "pytest": "7.2.1"}         |
| Plugins                      | {"html": "3.2.0", "metadata": "2.0.4"}         |
| Docker Compose               | {(Docker Inc., v2.21.0) }                      |
| Allure Pytest                | { v2.13.2) }                                   |


## Naming Convention Used:
1. Package/Folder name: Camel casing with no gaps. Complete Words instead of Short
2. Class Name: Camel Casing with no gaps and prefixed with Test
3. Test Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word and prefixed with ‘test’
4. Calling Function Name: Camel case has the first letter of each word capitalized except for the first word with underscore separating each word. Should be meaningful with structure <action_field_functionality>
5. Xpath Variable Name: small case with underscore separating each word. Name should be defined as such : Type_field_locator
6. Other Variable: Camel case has the first letter of each word capitalized except for the first word

## 11jun2024
1. Update run.py with url from cli
2. And run the precheck functions in order
3. On the basis of that run the test cases
4. if precheck functions pass then only run the test cases otherwise exit the script and generate the report of failed precheck functions


## 12june2024
1. NOTE: Before using Base Class Please read these Shortcuts of Selenium , Javascript , Text , Send , click , element , validation
javascript = js
Selenium = sm
Text = txt
Send = snd
click = clk
element = elm
validation = vld


1. NOTE: Before running locator.ini file make sure read comment section bellow
element locators button=btn
element locators input=inp
element locators css=css
element locators xpath=xp
element locators link=lk
element locators id=id
element locators name=nm
element locators class=cls

. File name update
SalesForce = SF
salesforce = sf

1. Update Base class Function For both javascript and Selenium based function
2. Docker is not running , test cases are running in Queue , So for now i had update the conftest to run the test cases in local browser
3. Update run.py Because as per the discussion we do not need to make separate html file for prechecks either fail or pass try to configure all prechecks in same report.html in both cases


### 14june2024

1. Make Precheck to check Scratch org url is active or not 
2. Make Browser initialization function dynamic for all(Chrome,firefox,edge) , on the basis of user input from cli
3. Make common precheck for object manager , to get the custom and standard object 
4. Explore run to precheck conditionally oon the basis of indexing, although it is working but still need to verify it with other precheck as well 
5. update locator strategy ex. txt_quick_find_css (mark field info at the first of the locator value)

### 17 june 2024
1. Update Base page code 
2. Reason : In some Unable to locate element directly , to locate them directly need to locate parent element 
3. Make this prechecks
4. 'test_pc_url_status','test_pc_site_register',    'test_pc_site_enable','test_pc_object_manager'

### 18 jun 2024
1. Common function for Mailchimp page layout functionality
2. 'test_pc_audience_mc',
3. 'test_pc_campaign_mc',
4. 'test_pc_segment_mc',
5. 'test_pc_tag_mc',
6. 'test_pc_group_mc'
7. Along with it Explore when we have to use javascript based functionality and when selenium in build functionality
Reason : Facing such error at the time of development
8. self.error_handler.check_response(response) ../../../.local/lib/python3.8/site-packages/selenium/webdriver/remote/errorhandler.py:229: in check_response raise exception_class(message, screen, stacktrace) E selenium.common.exceptions.TimeoutException: Message: Unable to execute request for an existing session: java.util.concurrent.TimeoutException E Build info: version: '4.10.0', revision: 'c14d967899' E System info: os.name: 'Linux', os.arch: 'amd64', os.version: '5.15.0-107-generic', java.version: '11.0.19' E Driver info: driver.version: unknown E Stacktrace: E java.lang.RuntimeException: Unable to execute request for an existing session: java.util.concurrent.TimeoutException E Build info: version: '4.10.0', revision: 'c14d967899' E System info: os.name: 'Linux', os.arch: 'amd64', os.version: '5.15.0-107-generic', java.version: '11.0.19' E Driver info: driver.version: unknown
9. Related with unable to find node of the element

Solution for that is
1. When you use selenium in build function, it directly interacts with the browser through the WebDriver,
2. And when we use javascript related function , such function are not work along with webdriver , javscript function some time by pass the website checks due to which some time it fail to maintain a session and gives an session error

3. Locate strategy :
href link :
4. org href : [href="/one/one.app#/setup/ObjectManager/01ID10000002lvY/view"]
5. org href : [href="/one/one.app#/setup/ObjectManager/01IO4000001BY5w/view"]

the only difference is of link id so for that cases we can locate them this way
Solution of such locator

1. [href*="/one/one.app#/setup/ObjectManager/"][href*="/view"]