from colorama import Fore, Style

#{Fore.YELLOW}{Style.RESET_ALL}

# # test_example.py
#
# import pytest
# import os
#
# # Shared setup
# @pytest.fixture
# def setup():
#     data = {"username": "test_user", "password": "secure_pass"}
#     return data
#
# # Major test case with conditional sub-tests
# @pytest.mark.parametrize("sub_test", ["sub_test1", "sub_test2", "sub_test3", "sub_test4"])
# def test_major(setup, sub_test):
#     run_tests = os.getenv("RUN_TESTS", "")
#     if sub_test in run_tests:
#         if sub_test == "sub_test1":
#             sub_test1(setup)
#         elif sub_test == "sub_test2":
#             sub_test2(setup)
#         elif sub_test == "sub_test3":
#             sub_test3(setup)
#         elif sub_test == "sub_test4":
#             sub_test4(setup)
#
# # Sub-test case 1
# def sub_test1(setup):
#     assert setup["username"] == "test_user"
#
# # Sub-test case 2
# def sub_test2(setup):
#     assert setup["password"] == "secure_pass"
#
# # Sub-test case 3
# def sub_test3(setup):
#     assert len(setup["username"]) > 0
#
# # Sub-test case 4
# def sub_test4(setup):
#     assert len(setup["password"]) > 0
def select_fields_move_from_visible_to_available(
        self,
        utility_setting_section,
        utility_setting_key,
        utility_setting_view,
        available_selected_field_data_config,
        select_fields_section,
        select_fields_key,
        select_fields_view,
        available_data_config,
        move_button_section,
        move_button_key,
        move_button_view,
        save_button_section,
        save_button_key,
        save_button_view,
):
    """
    Process and move fields based on configuration.

    Args:
        utility_setting_section (str): Configuration section to read utility setting.
        utility_setting_key (str): Configuration key to read utility setting.
        utility_setting_view (str): View to display before clicking on the utility setting.
        available_selected_field_data_config (str): Configuration to read available selected field data.
        select_fields_section (str): Configuration section to read select fields.
        select_fields_key (str): Configuration key to read select fields.
        select_fields_view (str): View to display before clicking on the select fields.
        available_data_config (str): Configuration to read available data.
        move_button_section (str): Configuration section to read move button locator.
        move_button_key (str): Configuration key to read move button locator.
        move_button_view (str): View to display before clicking on the move button.
        save_button_section (str): Configuration section to read save_ button locator.
        save_button_key (str): Configuration key to read save_ button locator.
        save_button_view (str): View to display before clicking on the save_ button.
    """
    # Retrieve select fields to display

    select_fields_to_display = self.utility_setting_items(
        locator_strategy=utility_setting_section,
        locator_value=utility_setting_key,
        view=utility_setting_view,
    )

    # Loop through select_field_to_display elements
    for field in select_fields_to_display:
        # Check if the text of the element matches the expected value from configuration
        if field.text == available_selected_field_data_config:
            field.click()
            # Retrieve available fields to display and search
            available_fields = self.selected_field_to_display_and_search(
                locator_strategy=select_fields_section,
                locator_value=select_fields_key,
                view=select_fields_view,
            )

            # Loop through available_fields
            for available_field in available_fields:
                # Check if the text of the field matches the expected available data from configuration
                if available_field.text == available_data_config:
                    available_field.click()

                    # Move selected item to visible field
                    self.move_selected_to_visible_field(
                        locator_strategy=move_button_section,
                        locator_value=move_button_key,
                        view=move_button_view,
                    )

                    # Save form action
                    self.save_btn(
                        locator_strategy=save_button_section,
                        locator_value=save_button_key,
                        view=save_button_view,
                    )
                    break
            else:
                # If the text of the field doesn't match the expected available data, log an error message
                # self.logger.error("Field doesn't match the expected available data")
                # Cancel form action
                continue
        else:
            # If the text of the field doesn't match the expected available data, log an error message
            # self.logger.error("Field doesn't match the expected available data")
            # Cancel form action
            continue

    def select_fields_move_from_visible_to_available_and_save(
            self,
            utility_setting_section,
            utility_setting_key,
            utility_setting_view,
            available_selected_field_data_config,
            select_fields_section,
            select_fields_key,
            select_fields_view,
            available_data_config,
            move_button_section,
            move_button_key,
            move_button_view,
            save_button_section,
            save_button_key,
            save_button_view,
    ):
        """
        Process and move fields based on configuration.

        Args:
            utility_setting_section (str): Configuration section to read utility setting.
            utility_setting_key (str): Configuration key to read utility setting.
            utility_setting_view (str): View to display before clicking on the utility setting.
            available_selected_field_data_config (str): Configuration to read available selected field data.
            select_fields_section (str): Configuration section to read select fields.
            select_fields_key (str): Configuration key to read select fields.
            select_fields_view (str): View to display before clicking on the select fields.
            available_data_config (str): Configuration to read available data.
            move_button_section (str): Configuration section to read move button locator.
            move_button_key (str): Configuration key to read move button locator.
            move_button_view (str): View to display before clicking on the move button.
            save_button_section (str): Configuration section to read save_ button locator.
            save_button_key (str): Configuration key to read save_ button locator.
            save_button_view (str): View to display before clicking on the save_ button.
        """
        # Retrieve select fields to display

        select_fields_to_display = self.utility_setting_items(
            locator_strategy=utility_setting_section,
            locator_value=utility_setting_key,
            view=utility_setting_view,
        )

        # Loop through select_field_to_display elements
        for field in select_fields_to_display:
            # Check if the text of the element matches the expected value from configuration
            if field.text == available_selected_field_data_config:
                field.click()
                # Retrieve available fields to display and search
                available_fields = self.selected_field_to_display_and_search(
                    locator_strategy=select_fields_section,
                    locator_value=select_fields_key,
                    view=select_fields_view,
                )

                # Loop through available_fields
                for available_field in available_fields:
                    # Check if the text of the field matches the expected available data from configuration
                    if available_field.text == available_data_config:
                        available_field.click()

                        # Move selected item to visible field
                        self.move_selected_to_visible_field(
                            locator_strategy=move_button_section,
                            locator_value=move_button_key,
                            view=move_button_view,
                        )

                        # Save form action
                        self.save_btn(
                            locator_strategy=save_button_section,
                            locator_value=save_button_key,
                            view=save_button_view,
                        )
                        break
                else:
                    # If the text of the field doesn't match the expected available data, log an error message
                    # self.logger.error("Field doesn't match the expected available data")
                    # Cancel form action
                    continue
            else:
                # If the text of the field doesn't match the expected available data, log an error message
                # self.logger.error("Field doesn't match the expected available data")
                # Cancel form action
                continue