# # test_example.py
#
# import pytest
# import os
#
# # Shared setup
# @pytest.fixture
# def setup():
#     data = {"username": "test_user", "password": "secure_pass"}
#     return data
#
# # Major test case with conditional sub-tests
# @pytest.mark.parametrize("sub_test", ["sub_test1", "sub_test2", "sub_test3", "sub_test4"])
# def test_major(setup, sub_test):
#     run_tests = os.getenv("RUN_TESTS", "")
#     if sub_test in run_tests:
#         if sub_test == "sub_test1":
#             sub_test1(setup)
#         elif sub_test == "sub_test2":
#             sub_test2(setup)
#         elif sub_test == "sub_test3":
#             sub_test3(setup)
#         elif sub_test == "sub_test4":
#             sub_test4(setup)
#
# # Sub-test case 1
# def sub_test1(setup):
#     assert setup["username"] == "test_user"
#
# # Sub-test case 2
# def sub_test2(setup):
#     assert setup["password"] == "secure_pass"
#
# # Sub-test case 3
# def sub_test3(setup):
#     assert len(setup["username"]) > 0
#
# # Sub-test case 4
# def sub_test4(setup):
#     assert len(setup["password"]) > 0
