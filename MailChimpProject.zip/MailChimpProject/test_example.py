#
# import pytest
#
# def test_1():
#     print("test_1")
#
# def test_2():
#     print("test_2")
#
# def test_3():
#     print("test_3")
#
# @pytest.mark.parametrize("test_func, skip", [
#     (test_1, True),
#     (test_2, False),
#     (test_3, True),
# ])
# def test_major(test_func, skip):
#     if skip:
#         pytest.skip("Skipping this test")
#     test_func()
import logging

# import pytest
#
#
# def test_1():
#     print("test_1")
#
#
# def test_2():
#     print("test_2")
#
#
# def test_3():
#     print("test_3")
#
#
# def test_conditional_execution(should_run_test_1, should_run_test_2, should_run_test_3):
#     if should_run_test_1:
#         test_1()
#     if should_run_test_2:
#         test_2()
#     if should_run_test_3:
#         test_3()
#
#
# @pytest.mark.parametrize("should_run_test_1, should_run_test_2, should_run_test_3", [
#     (True, False, True),
#     # Add other combinations as needed
# ])
# def test_major(should_run_test_1, should_run_test_2, should_run_test_3):
#     test_conditional_execution(should_run_test_1, should_run_test_2, should_run_test_3)
#
# import pytest
#
# def test_1():
#     print("test_1")
#
# def test_2():
#     print("test_2")
#
# def test_3():
#     print("test_3")
#
# @pytest.mark.parametrize("test_func, skip", [
#     (test_1, True),
#     (test_2, False),
#     (test_3, True),
# ])
# def test_major(test_func, skip):
#     if skip:
#         pytest.skip("Skipping this test")
#     else:
#         test_func()

import pytest

# def test_major():
#     def test_1():
#         print("test_1")
#
#
#     def test_2():
#         print("test_2")
#
#
#     def test_3():
#         print("test_3")
#
#
# def test_conditional_execution(should_run_test_1, should_run_test_2, should_run_test_3):
#     if should_run_test_1:
#         test_1()
#     if should_run_test_2:
#         test_2()
#     if should_run_test_3:
#         test_3()
#
#
# # Add test_conditional_execution to your test suite
# test_conditional_execution(should_run_test_1=False, should_run_test_2=True, should_run_test_3=False)

# import pytest
#
# @pytest.mark.parametrize("should_run", [True])
# def test_1(should_run):
#     if not should_run:
#         pytest.skip("Skipping test_1")
#     print("test_1")
#
# @pytest.mark.parametrize("should_run", [False])
# def test_2(should_run):
#     if not should_run:
#         pytest.skip("Skipping test_2")
#     print("test_2")
#
# @pytest.mark.parametrize("should_run", [True])
# def test_3(should_run):
#     if not should_run:
#         pytest.skip("Skipping test_3")
#     print("test_3")

# import pytest
#
# def test_major():
#     def test_1():
#         print("test_1")
#
#     def test_2():
#         print("test_2")
#
#     def test_3():
#         print("test_3")
#
#     # Define the conditions for each test
#     should_run_test_1 = False
#     should_run_test_2 = True
#     should_run_test_3 = True
#
#     # Execute each test based on its condition
#     if should_run_test_1:
#         test_1()
#     else:
#         pytest.skip("Skipping test_1")
#
#     if should_run_test_2:
#         test_2()
#     else:
#         pytest.skip("Skipping test_2")
#
#     if should_run_test_3:
#         test_3()
#     else:
#         pytest.skip("Skipping test_3")
#
# # Call the test_major function to execute the tests
# if __name__ == "__main__":
#     pytest.main(["-v", __file__])


# import pytest
#
# def test_1():
#     print("test_1")
#
# def test_2():
#     print("test_2")
#
# def test_3():
#     print("test_3")
#
# @pytest.mark.parametrize("should_run_test_1, should_run_test_2, should_run_test_3", [
#
# ])
# def test_conditional_execution(should_run_test_1, should_run_test_2, should_run_test_3):
#     if should_run_test_1:
#         test_1()
#     if should_run_test_2:
#         test_2()
#     if should_run_test_3:
#         test_3()
#
# def test_major():
#     # Run test_conditional_execution with desired conditions
#     test_conditional_execution(should_run_test_1=True, should_run_test_2=True, should_run_test_3=True)
#

# @pytest.mark.parametrize("test_case", ["test_1", "test_2", "test_3"])
# def test_major(test_case):
#     should_run = True if test_case == "test_1" else False
#     if not should_run:
#         pytest.skip(f"Skipping {test_case}")
#     print(test_case)

import logging

logger = logging.getLogger(__name__)


# def test_1():
#     logger.info("test_1")
# def test_2():
#     logger.info("test_2")
#
# def test_3():
#     logger.info("test_3")

# @pytest.mark.parametrize("test_case", ["test_1", "test_2", "test_3"])
# def test_major(test_case):
#     should_run = True if test_case == "test_1" else False
#     if not should_run:
#         pytest.skip(f"Skipping {test_case}")
#     logger.info(f"Executing {test_case}")
#     print(test_case)

# def lead_mapping_import_merge_field1(test_case_number1=None):
#     logging.info("lead_mapping_import_merge_field==============================")
#
# def lead_mapping_import_merge_field2(test_case_number2=None):
#         logging.info("lead_mapping_import_merge_field==============================")
#
# def lead_mapping_import_merge_field3(test_case_number3=None):
#     logging.info("lead_mapping_import_merge_field==============================")
# #@pytest.mark.parametrize("test_case_number", ["test_case_number1", "test_case_number2", "test_case_number3"])
# def test_lead_mapping_import_merge_field(test_case_number1=None, test_case_number2=None, test_case_number3=None):
#     print("test_lead_mapping_import_merge_field==============================")
#     if test_case_number1:
#         logging.info("Executing test case 1")
#
#     else:
#         logging.info("skip  Executing test case")
#     if test_case_number2:
#         logging.info("Executing test case 2")
#     if test_case_number3:
#         logging.info("Executing test case 3")
#     else:
#         logging.info("skip  Executing test case")
#
#
# # Run the test cases conditionally
# def lead_mapping_import_merge_field_case1():
#     lead_mapping_import_merge_field1(test_case_number1=True)
#
#
# def test_lead_mapping_import_merge_field_case2():
#     lead_mapping_import_merge_field2(test_case_number2=True)
#
#
# def test_lead_mapping_import_merge_field_case3():
#     lead_mapping_import_merge_field3(test_case_number3=True)



import pytest
import logging

# Configure logging to display messages
logging.basicConfig(level=logging.INFO, format='%(message)s')

def lead_mapping_import_merge_field1(test_case_number1):
    if test_case_number1:
        logging.info("Executing lead_mapping_import_merge_field1")
    else:
        logging.info("Skipping lead_mapping_import_merge_field1")

def lead_mapping_import_merge_field2(test_case_number2):
    if test_case_number2:
        logging.info("Executing lead_mapping_import_merge_field2")
    else:
        logging.info("Skipping lead_mapping_import_merge_field2")

def lead_mapping_import_merge_field3(test_case_number3):
    if test_case_number3:
        logging.info("Executing lead_mapping_import_merge_field3")
    else:
        logging.info("Skipping lead_mapping_import_merge_field3")

def test_lead_mapping_import_merge_field():
    # Define conditions for each test
    test_case_number1 = False
    test_case_number2 = False
    test_case_number3 = False

    # Execute each test case based on the conditions
    lead_mapping_import_merge_field1(test_case_number1)
    lead_mapping_import_merge_field2(test_case_number2)
    lead_mapping_import_merge_field3(test_case_number3)

# if __name__ == "__main__":
#     pytest.main(["-v", __file__])
