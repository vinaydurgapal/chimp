from configparser import ConfigParser


# Return Locators of the element
def locatorsReadConfig(section, key):
    """
    To read static data present in config file
    Parameters:
    - section: Parsing the value from the section
    - key: Parsing key via a section

    Returns:
        object:
    - key value of the section
    """
    config = ConfigParser()
    config.read(
        "/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/elementLocators.ini")
    return config.get(section, key)


# Return data, use for the test cases execution
def dataReadConfig(section, key):
    """
    To read static data present in config file
    Parameters:
    - section: Parsing the value from the section
    - key: Parsing key via a section

    Returns:
    - key value of the section
    """
    config = ConfigParser()
    config.read(
        "/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini")
    return config.get(section, key)
