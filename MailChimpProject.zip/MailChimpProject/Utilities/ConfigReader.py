from configparser import ConfigParser


# Return Locators of the element
from configparser import ConfigParser


def locatorsReadConfig(section, key):
    """
    Reads a specific key-value pair from the 'elementLocators.ini' configuration file.

    Parameters:
    - section (str): The section in the configuration file where the key-value pair is located.
    - key (str): The key to retrieve the corresponding value from the section.

    Returns:
    - object: The value corresponding to the specified key in the specified section.
    """
    # Create a ConfigParser object
    config = ConfigParser()

    # Read the configuration file
    config.read(
        "/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/elementLocators.ini")

    # Get the value corresponding to the specified key in the specified section
    return config.get(section, key)


# Return data, use for the test cases execution
def dataReadConfig(section, key):
    """
    Read static data present in the configuration file.

    Parameters:
    - section: The section from which to parse the value.
    - key: The key via a section to parse.

    Returns:
    - The value corresponding to the key in the specified section.
    """
    config = ConfigParser()
    config.read(
        "/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini")
    return config.get(section, key)
