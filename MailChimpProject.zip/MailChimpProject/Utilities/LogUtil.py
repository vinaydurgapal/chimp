import logging
import os


class LogGen:
    logger = {}  # Use a dictionary to store loggers for each worker

    @classmethod
    def loggen(cls):
        worker_id = os.getenv("PYTEST_XDIST_WORKER")  # Get the worker ID from the environment variable
        test_case_id = os.getpid()

        # Check if a logger exists for the current worker
        if (worker_id, test_case_id) not in cls.logger:
            logger = logging.getLogger(f"worker_{worker_id}_testcasesID_{test_case_id}")
            # logger = logging.getLogger()
            logger.setLevel(logging.INFO)

            # Create a directory to store logs if it doesn't exist
            log_dir = '/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/Logs'  # for Local execution
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)

            # Use the worker_id and test_case_id to create a unique log file for each worker
            log_file = f'{log_dir}/worker_{worker_id}_log.log'

            # Create File handler and set level to INFO
            handler = logging.FileHandler(log_file, mode="w")
            handler.setLevel(logging.INFO)
            formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
            handler.setFormatter(formatter)

            # Clear existing handlers to avoid duplication
            logger.handlers = []

            logger.addHandler(handler)
            # Store the logger in the dictionary
            # Create a console handler   # Remove because of Duplication in log (Report ) , It print STDR error in report
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.DEBUG)

            # Set the formatter for the console handler
            # formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            #                               datefmt='%m-%d-%Y %I:%M:%S%p')
            # console_handler.setFormatter(formatter)
            #
            # # Add the console handler to the logger
            # logger.addHandler(console_handler)
            #
            # # Store the logger in the dictionary

            cls.logger[(worker_id, test_case_id)] = logger

        return cls.logger[(worker_id, test_case_id)]
