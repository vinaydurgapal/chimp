import pytest


@pytest.mark.usefixtures("setup_teardown_method")
class BaseTest:
    """
    This is a base test class that utilizes the setup_teardown_method fixture.
    """

    pass
