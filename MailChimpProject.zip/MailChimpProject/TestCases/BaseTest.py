import pytest


@pytest.mark.usefixtures("setup_teardown_method")
class BaseTest:
    pass
