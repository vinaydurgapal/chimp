import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Tags import SF_Tags
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def tags_setup_method():
    """Set up the Tags page view for verification.

    This function initializes the Tags and CF_Dashboard_View instances with the provided driver.
    It waits for the loader to disappear and redirects to the tag page.
    It then retrieves the page heading and verifies if the page is opened successfully.

    Returns:
    None
    """
    # Get the logger instance
    logger = LogGen.loggen()
    # Initialize Tags and Dashboard instances
    sf_tag = SF_Tags(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Tags : Wait for loader to disappear ",
    )

    # Redirect to tag page
    sf_tag.redirect_to_tag_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("tag locators", "tag_name_xpath")
        ),
        view="Setup Methods : Side View : Tags ",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Tags : Wait for loader to disappear ",
    )

    # Get the page heading
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )

    # Verify if the page is opened successfully
    if page_head.text == "Tags":
        logger.info("Setup Methods : Side View : Tags : Opened : ")
    else:
        pytest.fail("Tags Page not Opened Successfully!")
