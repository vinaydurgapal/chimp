import colorama
import pytest
from selenium.common import NoSuchElementException, TimeoutException, StaleElementReferenceException, \
    ElementClickInterceptedException
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_DashBoard.SF_Audience import SF_Audience
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Audience import SF_Audience
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_SetupPage import SF_CF_SetupPage
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def audience_setup_method():
    """
    Setup Method: Verifies the page view of Audience.

    Initializes the SF_Audience and CF_Dashboard_View classes with the driver.
    Waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.

    Parameters:
        None

    Returns:
        None
    """
    # Get the logger instance
    logger = LogGen.loggen()

    # Create instances of SF_Audience and CF_Dashboard_View classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_aud = SF_Audience(SalesForceBaseTest.driver)

    # Wait for the loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view=f"{colorama.Fore.YELLOW}Setup Methods : {colorama.Style.RESET_ALL} Side View : Audience : Wait for loader to disappear",
    )

    sf_aud.redirect_to_audience_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "audience locators", "audience_name_xpath"
            )
        ),
        view=f"{colorama.Fore.RED}Setup Methods : {colorama.Style.RESET_ALL} Side View : Audience :",
    )
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view=" ",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view=f"{colorama.Fore.RED}Setup Methods : {colorama.Style.RESET_ALL} Side View : Audience : Wait for loader to disappear ",
    )
    if page_head.text == "Audience":
        logger.info(f"{colorama.Fore.RED}Setup Methods : {colorama.Style.RESET_ALL} Side View : Audience : Audience Page Opened Successfully!")
    else:
        pytest.fail(f"{colorama.Fore.RED}Setup Methods : {colorama.Style.RESET_ALL} Side View : Audience : Audience Page not Opened Successfully!")


def app_redirection():
    """
    Redirects to the app page from the setup page by clicking on the nine dots icon and searching for "ChimpConnect".
    """
    # Get the logger instance
    logger = LogGen.loggen()

    # Initialize the Salesforce Common Functions (SF_CF_SetupPage) instance
    sf_cf = SF_CF_SetupPage(SalesForceBaseTest.driver)

    # Redirect to the app page
    sf_cf.redirect_to_app_page()
