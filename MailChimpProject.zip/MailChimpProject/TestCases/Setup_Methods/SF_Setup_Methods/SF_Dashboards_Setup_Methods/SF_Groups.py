import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Groups import SF_Groups
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def groups_setup_method():
    """
    Setup method to verify the page view of Groups.

    This function sets up the Groups page view for verification.
    It initializes the SF_Groups and CF_Dashboard_View instances with the provided driver.
    It waits for the loader to disappear and redirects to the Groups page.

    Parameters:
    - Read From Utilities file by Readconfig function
    """
    # Get the logger instance
    logger = LogGen.loggen()
    sf_group = SF_Groups(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # Wait for the loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Groups : Wait for loader to disappear ",
    )

    # Redirect to the Groups page
    sf_group.redirect_to_groups_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("group locators", "group_name_xpath")
        ),
        view="Setup Methods : Side View : Groups ",
    )

    # Get the page heading
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Groups : Wait for loader to disappear ",
    )

    # Verify if the page heading is "Groups"
    if page_head.text == "Groups":
        logger.info("Setup Methods : Side View : Groups : Opened : ")
    else:
        pytest.fail("Groups Page not Opened Successfully!")
