import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Campaigns import SF_Campaigns
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def campaigns_setup_method():
    """
    Setup Method: Verifies the page view of Campaigns.

    Initializes the SF_Campaigns and CF_Dashboard_View classes with the driver.
    Waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.

    Parameters:
        None

    Returns:
        None
    """
    # Get the logger instance
    logger = LogGen.loggen()

    # Create instances of SF_Campaigns and CF_Dashboard_View classes
    sf_camp = SF_Campaigns(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # Wait for the loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Campaigns : Wait for loader to disappear",
    )

    # Redirect to the campaign page
    sf_camp.redirect_to_campaign_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("campaign locators", "campaign_name_xpath")
        ),
        view="Setup Methods : Side View : Campaigns : ",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Campaigns : Wait for loader to disappear",
    )

    # Get the page heading
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Methods : Side View : Campaigns : Wait for loader to disappear",
    )

    # Verify if the page is opened successfully
    if page_head.text == "Campaigns":
        logger.info("Setup Methods : Side View : Campaigns : Opened : ")
        skip_tests = True
    else:
        pytest.fail("Campaigns Page not Opened Successfully!")
