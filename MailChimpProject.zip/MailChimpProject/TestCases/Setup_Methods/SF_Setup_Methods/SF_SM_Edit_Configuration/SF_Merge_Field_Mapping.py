import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_MailchimpContacts import SF_MailChimpContacts
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def merge_field_lead_mapping_setup_method():
    """
    Setup method to verify the page view of Configuration.
    This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
    It waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.
    Parameters:
        - None
    Returns:
        - None
    """
    # Get the logger instance
    logger = LogGen.loggen()
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_mail_chimp_contact = SF_MailChimpContacts(SalesForceBaseTest.driver)

    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    sf_config.redirect_to_configuration_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "configuration locators", "config_name_xpath"
            )
        ),
        view="Setup Method : Side view : Configuration :",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    if page_head.text == "Configuration":
        logger.info("Setup Method : Side view : Configuration : Opened : ")
    else:
        pytest.fail("Configuration Page not Opened Successfully!")

    toggle_data_list = [
        {
            "locator_strategy": By.XPATH,
            "locator_value": str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            "view": "Setup Method : Side view : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber ",
            "conditions_dict": {"MailChimp Subscriber": "True"},
            "toggle_field_data": "MailChimp Subscriber",
        },
        {
            "locator_strategy": By.XPATH,
            "locator_value": str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            "view": "Setup Method : Side view : Configuration : Edit Configuration : General Setting : Create a Contact of MailChimp Subscriber ",
            "conditions_dict": {"Create Contact": "False"},
            "toggle_field_data": "Create Contact",
        },
    ]
    sf_edit_config.edit_configuration(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_edit_config_xpath"
            )
        ),
        view="Setup Method : Side view : Configuration : Edit Configuration",
    )

    try:
        for toggle_data in toggle_data_list:
            toggle_field(toggle_data)
        # Wait for the loader to disappear after toggling the field
        sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        # Check box the field to update the lead of MailChimp subscriber
        sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_lead_mailchimp_subscriber_xpath",
                )
            ),
            view="Setup Method : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber : ",
            conditions_dict={"Update lead": "True"},
            check_box_data="Update lead",
        )
        # Check box the field to update the contact of MailChimp subscriber
        # sf_edit_config.check_box(
        #     locator_strategy=By.XPATH,
        #     locator_value=str(
        #         ConfigReader.locatorsReadConfig(
        #             "general setting locators",
        #             "chk_box_contact_mailchimp_subscriber_xpath",
        #         )
        #     ),
        #     view="Setup Method : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber : ",
        #     conditions_dict={"Update contact": "False"},
        #     check_box_data="Update contact",
        # )
        # Save the changes made
        sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Save Button",
        )

        # Get the validation message and check if it is 'Success'
        validation_txt = sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        logger.info(
            f"Setup Method : Side view : Configuration : Edit Configuration : General Setting : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text == "Success"
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Close Button",
            )

        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Close Button",
            )
            sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Setup Method : Side view : Configuration : Edit Configuration : General Setting :  Sure Ok Button",
            )
            pytest.fail("Required Toggle field not Enabled successfully!")
    except Exception as e:
        # Close the modal after creating the lead of MailChimp subscriber
        sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Close Button",
        )
        sf_cf_dash.ok_btn(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting :  Sure Ok Button",
        )
        pytest.fail("Required Toggle field not Enabled successfully!")


def merge_field_contact_mapping_setup_method():
    """
    Setup method to verify the page view of Configuration.
    This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
    It waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.
    Parameters:
        - None
    Returns:
        - None
    """
    # Get the logger instance
    logger = LogGen.loggen()
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_mail_chimp_contact = SF_MailChimpContacts(SalesForceBaseTest.driver)

    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    sf_config.redirect_to_configuration_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "configuration locators", "config_name_xpath"
            )
        ),
        view="Setup Method : Side view : Configuration :",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    if page_head.text == "Configuration":
        logger.info("Setup Method : Side view : Configuration : Opened : ")
    else:
        pytest.fail("Configuration Page not Opened Successfully!")

    toggle_data_list = [
        {
            "locator_strategy": By.XPATH,
            "locator_value": str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            "view": "Setup Method : Side view : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber ",
            "conditions_dict": {"MailChimp Subscriber": "False"},
            "toggle_field_data": "MailChimp Subscriber",
        },
        {
            "locator_strategy": By.XPATH,
            "locator_value": str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            "view": "Setup Method : Side view : Configuration : Edit Configuration : General Setting : Create a Contact of MailChimp Subscriber ",
            "conditions_dict": {"Create Contact": "True"},
            "toggle_field_data": "Create Contact",
        },
    ]
    sf_edit_config.edit_configuration(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_edit_config_xpath"
            )
        ),
        view="Setup Method : Side view : Configuration : Edit Configuration",
    )

    try:
        for toggle_data in toggle_data_list:
            toggle_field(toggle_data)
        # Wait for the loader to disappear after toggling the field
        sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        # Check box the field to update the lead of MailChimp subscriber
        # sf_edit_config.check_box(
        #     locator_strategy=By.XPATH,
        #     locator_value=str(
        #         ConfigReader.locatorsReadConfig(
        #             "general setting locators",
        #             "chk_box_lead_mailchimp_subscriber_xpath",
        #         )
        #     ),
        #     view="Setup Method : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber : ",
        #     conditions_dict={"Update lead": "False"},
        #     check_box_data="Update lead",
        # )
        # Check box the field to update the contact of MailChimp subscriber
        sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_contact_mailchimp_subscriber_xpath",
                )
            ),
            view="Setup Method : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber : ",
            conditions_dict={"Update contact": "True"},
            check_box_data="Update contact",
        )
        # Save the changes made
        sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Save Button",
        )

        # Get the validation message and check if it is 'Success'
        validation_txt = sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        logger.info(
            f"Setup Method : Side view : Configuration : Edit Configuration : General Setting : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text == "Success"
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Close Button",
            )

        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Close Button",
            )
            sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Setup Method : Side view : Configuration : Edit Configuration : General Setting :  Sure Ok Button",
            )
            pytest.fail("Required Toggle field not Enabled successfully!")
    except Exception as e:
        # Close the modal after creating the lead of MailChimp subscriber
        sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting : Close Button",
        )
        sf_cf_dash.ok_btn(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            view="Setup Method : Side view : Configuration : Edit Configuration : General Setting :  Sure Ok Button",
        )
        pytest.fail("Required Toggle field not Enabled successfully!")


def toggle_field(toggle_data):
    """
    Toggles a field based on the provided toggle data.

    Args:
        toggle_data (dict): A dictionary containing the following keys:
            - locator_strategy (str): The strategy to use for locating the field.
            - locator_value (str): The value to use for locating the field.
            - view (str): The view to display before toggling the field.
            - conditions_dict (dict): Dictionary containing conditions for toggling the field.
            - toggle_field_data (str): The data used for toggling.

    Returns:
        None
    """
    # Create instances of the necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)

    # Wait for the loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear",
    )

    # Toggle the field using the provided data
    sf_edit_config.toggle_field(
        toggle_data["locator_strategy"],
        toggle_data["locator_value"],
        toggle_data["view"],
        toggle_data["conditions_dict"],
        toggle_data["toggle_field_data"],
    )
