import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Campaigns import SF_Campaigns
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def configuration_setup_method():
    """
    Setup method to verify the page view of Configuration.

    This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
    It waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.

    Parameters:
        - None

    Returns:
        - None
    """
    # Get the logger instance
    logger = LogGen.loggen()
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    """
    Set up a new instance of the Configuration class.
    This method creates a new instance of the Configuration class and initializes it with the provided driver.
    """
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    sf_config.redirect_to_configuration_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "configuration locators", "config_name_xpath"
            )
        ),
        view="Setup Method : Side view : Configuration :",
    )
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side view : Configuration : Wait for loader to disappear ",
    )
    if page_head.text == "Configuration":
        logger.info("Setup Method : Side View : Configuration : Opened : ")
    else:
        pytest.fail("Configuration Page not Opened Successfully!")
