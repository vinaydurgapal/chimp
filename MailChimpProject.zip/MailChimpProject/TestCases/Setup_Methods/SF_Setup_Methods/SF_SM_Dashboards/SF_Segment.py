import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Segments import SF_Segments
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def segments_setup_method():
    """
    Setup method to verify the page view of Segments.

    This function sets up the Segments page view for verification.
    It initializes the SF_Segments and CF_Dashboard_View instances with the provided driver.
    It waits for the loader to disappear and redirects to the Segments page.

    Parameters:
    - Read From Utilities file by Readconfig function
    """
    # Get the logger instance
    logger = LogGen.loggen()
    sf_segment = SF_Segments(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    """
    Set up a new instance of the Segments class.
    This method creates a new instance of the Segments class and initializes it with the provided driver.
    """
    sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                              "loader_xpath")),
                                            view="Side view : Segments : Wait for loader to disappear ")
    sf_segment.redirect_to_segment_page(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("segment locators",
                                                                                          "segment_name_xpath")),
                                        view="Side View : Segments : ")
    page_head = sf_cf_dash.return_page_heading(locator_strategy=By.XPATH,
                                               locator_value=str(
                                                   ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                   "txt_heading_page_xpath"))
                                               , view="")
    sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                              "loader_xpath")),
                                            view="Side view : Segments : Wait for loader to disappear ")
    if page_head.text == "Segment":
        logger.info("Setup Method : Side View : Segments : Opened : ")
    else:
        pytest.fail("Segments  Page not Opened Successfully!")