import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_MailchimpContacts import SF_MailChimpContacts
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def mailchimp_contact_setup_method():
    """Setup method to verify the page view of  MailchimpContacts.

    This test verifies the page view of the MailchimpContacts page by performing the following steps:
    1. Set up a new instance of the SF_MailChimpContacts class.
    2. Initialize the CF_Dashboard_View class with the provided driver.
    3. Wait for the loader to disappear on the Mailchimp Contacts page.
    4. Redirect to the Mailchimp Contacts page.
    5. Verify the page heading.

    Parameters:
    - No input parameters required.
    Returns:
    - No return value.
    """
    # Get the logger instance
    logger = LogGen.loggen()
    # Create a new instance of SF_MailChimpContacts and initialize the CF_Dashboard_View
    sf_mail_chimp_contact = SF_MailChimpContacts(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # Wait for the loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side View : Mailchimp Contacts : Wait for loader to disappear ",
    )

    # Redirect to the Mailchimp Contacts page
    sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "mailchimp contact locators", "mailchimp_contact_name_xpath"
            )
        ),
        view="Setup Method : Side View : Mailchimp Contacts ",
    )

    # Get the page heading element
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view=" ",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Setup Method : Side View : Mailchimp Contacts : Wait for loader to disappear ",
    )
    # Verify if the page heading is "Mailchimp Contacts"
    if page_head.text == "Mailchimp Contacts":
        logger.info("Setup Method : Side View : Mailchimp Contacts : Opened : ")
    else:
        pytest.fail("Mailchimp Contacts Page not Opened Successfully!")
