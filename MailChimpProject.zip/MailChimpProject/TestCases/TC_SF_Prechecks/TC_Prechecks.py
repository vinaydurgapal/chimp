import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_Prechecks.SF_Prechecks import SF_Prechecks
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class TestLogin(SalesForceBaseTest):

    # NOTE:  Before using Base Class Please read these Shortcuts of
    # prechecks=pc
    # salesforce=sf

    def test_pc_url_status(self):
        """Verifying the Status of the URL
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.check_url_status()

    def test_pc_site_register(self):
        """Verifying the Site Registration functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.quick_find(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "site_quick_find_txt"
            ),
            view="Home : Site : Site Setup : Quick Find",
        )
        sf_pc.site_select_and_register()

    def test_pc_site_enable(self):
        """Verifying the Quick Find functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.quick_find(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "site_quick_find_txt"
            ),
            view="Home : Site : Site Setup : Quick Find",
        )
        verification_txt = sf_pc.site_select_and_enable()
        if "ChimpConnect" or "Site is already enabled" in verification_txt:
            self.logger.info(
                "Home : Site : Site Setup : Form : New : Site Edit : Save : Site is enabled"
            )
        else:
            pytest.fail(
                "Home : Site : Site Setup : Form : New : Site Edit : Save : Site is not enabled"
            )

    # Element name should be defined as such:
    # Audience:Mailchimp : audience_mc
    def test_pc_audience_mc(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "obj_m_quick_find_txt"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimps : Page Layout Name : ",
            required_text="Audience:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : ",
            required_text="Page Layout",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_name_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout Name : ",
            required_text="essMC_Mailchimp Audience Layout",
        )
        sf_pc.switch_iframe_functionality(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : ",
        )
        sf_pc.drag_and_drop_functionality(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_target_element_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : Target Fields",
            s_locator_strategy=By.XPATH,
            s_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_source_layout_xpath"
            ),
            s_view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : Source Fields",
            c_locator_strategy=By.CSS_SELECTOR,
            c_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_container_css"
            ),
            c_view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : Source Fields Container",
            qb_locator_strategy=By.CSS_SELECTOR,
            qb_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "quick_save_button_css"
            ),
            qb_view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : Quick Save Button",
            expected_data=ConfigReader.dataReadConfig("setup prechecks", "list"),
        )

    def test_pc_campaign_mc(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "obj_m_quick_find_campaign_txt"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Campaign:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : ",
            required_text="Page Layout",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_name_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout Name : ",
            required_text="essMC Campaign Layout",
        )
        sf_pc.switch_iframe_functionality(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : ",
        )
        sf_pc.drag_and_drop_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators",
                "campaign_fields_target_element_xpath",
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : Target Fields",
            s_locator_strategy=By.XPATH,
            s_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_source_layout_xpath"
            ),
            s_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : Source Fields",
            c_locator_strategy=By.CSS_SELECTOR,
            c_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_container_css"
            ),
            c_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : Source Fields Container",
            qb_locator_strategy=By.CSS_SELECTOR,
            qb_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "quick_save_button_css"
            ),
            qb_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : Quick Save Button",
            expected_data=ConfigReader.dataReadConfig(
                "setup prechecks", "campaign_mc_fields"
            ),
        )

    #
    def test_pc_segment_mc(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "obj_m_find_segment_txt"
            ),
            view="Home : Page Layout : Object Manager : ",
        )

        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Segment:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout : ",
            required_text="Page Layout",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_name_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout Name : ",
            required_text="essMC_Segment Layout",
        )
        sf_pc.switch_iframe_functionality(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout : ",
        )
        sf_pc.drag_and_drop_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "tag_fields_target_element_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout : Target Fields",
            s_locator_strategy=By.XPATH,
            s_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_source_layout_xpath"
            ),
            s_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout : Source Fields",
            c_locator_strategy=By.CSS_SELECTOR,
            c_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_container_css"
            ),
            c_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout : Source Fields Container",
            qb_locator_strategy=By.CSS_SELECTOR,
            qb_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "quick_save_button_css"
            ),
            qb_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Page Layout : Quick Save Button",
            expected_data=ConfigReader.dataReadConfig(
                "setup prechecks", "segment_mc_fields"
            ),
        )

    #
    def test_pc_tag_mc(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "obj_m_find_tag_txt"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Tag:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout : ",
            required_text="Page Layout",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_name_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout Name : ",
            required_text="Tags Layout",
        )
        sf_pc.switch_iframe_functionality(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout : ",
        )
        sf_pc.drag_and_drop_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "tag_fields_target_element_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout : Target Fields",
            s_locator_strategy=By.XPATH,
            s_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_source_layout_xpath"
            ),
            s_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout : Source Fields",
            c_locator_strategy=By.CSS_SELECTOR,
            c_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_container_css"
            ),
            c_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout : Source Fields Container",
            qb_locator_strategy=By.CSS_SELECTOR,
            qb_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "quick_save_button_css"
            ),
            qb_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Page Layout : Quick Save Button",
            expected_data=ConfigReader.dataReadConfig(
                "setup prechecks", "tag_mc_fields"
            ),
        )

    def test_pc_group_mc(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "obj_m_find_group_txt"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        # time.sleep(5)
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Group:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout : ",
            required_text="Page Layout",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_name_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout Name : ",
            required_text="Group:Mailchimp Layout",
        )
        sf_pc.switch_iframe_functionality(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout : ",
        )
        sf_pc.drag_and_drop_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "tag_fields_target_element_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout : Target Fields",
            s_locator_strategy=By.XPATH,
            s_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_source_layout_xpath"
            ),
            s_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout : Source Fields",
            c_locator_strategy=By.CSS_SELECTOR,
            c_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "fields_container_css"
            ),
            c_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout : Source Fields Container",
            qb_locator_strategy=By.CSS_SELECTOR,
            qb_locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "quick_save_button_css"
            ),
            qb_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Page Layout : Quick Save Button",
            expected_data=ConfigReader.dataReadConfig(
                "setup prechecks", "group_mc_fields"
            ),
        )

    #
    # def test_pc_campaign(self):
    #     """Verifying the Object Manager functionality
    #     Parameters:
    #     -Read From Utilities file by Readconfig function
    #     Returns:
    #     --
    #     """
    #     sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
    #     sf_pc.select_object_manager(
    #         send_text=ConfigReader.dataReadConfig("setup prechecks", "obj_m_find_campaign_txt"),
    #         view='Home : Page Layout : Object Manager : ')
    #     sf_pc.audience_mailchimp_pc(locator_strategy=By.CSS_SELECTOR,
    #                                 locator_value=ConfigReader.locatorsReadConfig("Object manager page layout locators",
    #                                                                               "lnk_ac_css"),
    #                                 view="Home : Page Layout : Object Manager : Setup : ",
    #                                 required_text='Campaign')
    #     sf_pc.audience_mailchimp_pc(locator_strategy=By.CSS_SELECTOR,
    #                                 locator_value=ConfigReader.locatorsReadConfig("Object manager page layout locators",
    #                                                                               "lnk_page_layout_css"),
    #                                 view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : ",
    #                                 required_text='Page Layout')
    #     sf_pc.audience_mailchimp_pc(locator_strategy=By.CSS_SELECTOR,
    #                                 locator_value=ConfigReader.locatorsReadConfig("Object manager page layout locators",
    #                                                                               "lnk_page_layout_name_css"),
    #                                 view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout Name : ",
    #                                 required_text='Campaign Layout')
    #     sf_pc.audience_mailchimp_pc_pl(locator_strategy=By.XPATH,
    #                                    locator_value=ConfigReader.locatorsReadConfig(
    #                                        "Object manager page layout locators",
    #                                        'iframe_layout_xpath'),
    #                                    view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : ")
    #     drag_fields = sf_pc.audience_mailchimp_fields(locator_strategy=By.XPATH,
    #                                                   locator_value=ConfigReader.locatorsReadConfig(
    #                                                       "Object manager page layout locators", "fields_layout_xpath"),
    #                                                   view="Home : Page Layout : Setup : Object Manager :  Audience:Mailchimp : fields "
    #                                                   )
    #     self.logger.info(drag_fields)

    # TestCases name defined as such:
    # Record Type :rt

    # Prechecks for Record Types  (For All Required Custom And Standard Record Types)
    def test_pc_contact_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig("setup prechecks", "contact"),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Contact",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact: Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.standard_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
                        l_send_text="contact",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Name ",
                        n_send_text="",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Select Record Type : Contact Layout ",
                        srt_send_text="Contact Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass

    # TestCases name defined as such:
    # Record Type :rt
    def test_pc_campaign_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig("setup prechecks", "campaign"),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Campaign",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign: Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.standard_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign : Record Types : New : Record Type Label",
                        l_send_text="Campaign",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign : Record Types : New : Record Type Name ",
                        n_send_text="Campaign",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign : Record Types : New : Select Record Type : Campaign Layout ",
                        srt_send_text="Campaign Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass

    # TestCases name defined as such:
    # Campaign:Mailchimp : campaign_m
    def test_pc_campaign_m_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "campaign_mailchimp"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Campaign:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.custome_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Record Types : New : Record Type Label",
                        l_send_text="CampaignMailchimp",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Record Types : New : Record Type Name ",
                        n_send_text="CampaignMailchimp",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Campaign:Mailchimp : Record Types : New : Select Record Type : essMC Campaign Layout ",
                        srt_send_text="essMC Campaign Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass

    # TestCases name defined as such:
    # Record Type :rt
    # Tag: Mailchimp:tag_m
    def test_pc_tag_m_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig("setup prechecks", "tag_mailchimp"),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Tag:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp: Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.custome_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Record Types : New : Record Type Label",
                        l_send_text="Tags",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Record Types : New : Record Type Name ",
                        n_send_text="",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Tag:Mailchimp : Record Types : New : Select Record Type : Tags Layout ",
                        srt_send_text="Tags Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass

    # TestCases name defined as such:
    # Record Type :rt
    # Segment: Mailchimp:segment_m
    def test_pc_segment_m_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "segment_mailchimp"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Segment:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp: Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.custome_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Record Types : New : Record Type Label",
                        l_send_text="Segment",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Record Types : New : Record Type Name ",
                        n_send_text="",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Segment:Mailchimp : Record Types : New : Select Record Type : essMC_Segment Layout ",
                        srt_send_text="essMC_Segment Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass

    # TestCases name defined as such:
    # Record Type :rt
    # Subscriber: Mailchimp:subscriber_m
    def test_pc_subscriber_m_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig(
                "setup prechecks", "subscriber_mailchimp"
            ),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Subscriber:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Subscriber:Mailchimp: Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.custome_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Subscriber:Mailchimp : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Subscriber:Mailchimp : Record Types : New : Record Type Label",
                        l_send_text="Subscribers",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Subscriber:Mailchimp : Record Types : New : Record Type Name ",
                        n_send_text="",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Subscriber:Mailchimp : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Subscriber:Mailchimp : Record Types : New : Select Record Type : essMC Subscriber Layout ",
                        srt_send_text="essMC Subscriber Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass

    # TestCases name defined as such:
    # Record Type :rt
    # Group: Mailchimp:segment_m

    def test_pc_group_m_rt(self):
        """Verifying the Object Manager functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        --
        """
        sf_pc = SF_Prechecks(SalesForceBaseTest.driver)
        sf_pc.select_object_manager(
            send_text=ConfigReader.dataReadConfig("setup prechecks", "group_mailchimp"),
            view="Home : Page Layout : Object Manager : ",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_ac_css"
            ),
            view="Home : Page Layout : Object Manager : Setup : ",
            required_text="Group:Mailchimp",
        )
        sf_pc.setup_object_manager_functionality(
            locator_strategy=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_page_layout_css2"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp: Page Layout : ",
            required_text="Record Types",
        )
        try:
            list_element = sf_pc.sm_return_elm(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "Object manager page layout locators", "txt_contact_xpath"
                ),
                view="Home : Page Layout : Object Manager : Setup: Object Manager: Contact : Record Types : New : Record Type Label",
            )
            try:
                if not list_element:
                    sf_pc.custome_record_types_enabled(
                        locator_strategy=By.CSS_SELECTOR,
                        locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators",
                            "btn_record_type_new_css",
                        ),
                        view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Record Types : New ",
                        l_locator_strategy=By.XPATH,
                        l_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtl_xpath"
                        ),
                        l_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Record Types : New : Record Type Label",
                        l_send_text="Group",
                        n_locator_strategy=By.XPATH,
                        n_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_rtn_xpath"
                        ),
                        n_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Record Types : New : Record Type Name ",
                        n_send_text="Group",
                        nx_locator_strategy=By.CSS_SELECTOR,
                        nx_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "inpt_nxt_css"
                        ),
                        nx_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Record Types : New : Next ",
                        srt_locator_strategy=By.CSS_SELECTOR,
                        srt_locator_value=ConfigReader.locatorsReadConfig(
                            "Object manager page layout locators", "select_lo_css"
                        ),
                        srt_view="Home : Page Layout : Object Manager : Setup: Object Manager: Group:Mailchimp : Record Types : New : Select Record Type : Group:Mailchimp Layout",
                        srt_send_text="Group:Mailchimp Layout",
                    )
            except Exception as e:
                self.logger.info("Record Type Is Already Active")
        except Exception as e:
            pass
