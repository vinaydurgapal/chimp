from Pages.MailChimp.MC_Login import MC_MailChimpLogin
from TestCases.TC_MailChimp.BaseTest_MC import MailChimpBaseTest


class Test_a(MailChimpBaseTest):
    def test_a(self):
        mc_login = MC_MailChimpLogin(MailChimpBaseTest.driver)
        mc_login.login_page()
        self.logger.info("Mail Chimp Login Successfully!")

    def test_b(self):
        print("test_b")
