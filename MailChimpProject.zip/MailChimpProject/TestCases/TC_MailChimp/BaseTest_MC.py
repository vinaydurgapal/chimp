
import pytest
from TestCases.BaseTest import BaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


class MailChimpBaseTest(BaseTest):
    logger = LogGen.loggen()
    driver = None
    """
       Test class for Salesforce login functionality.
       Attributes:
       - login: An instance of the LoginPage class for interacting with the login page.
       - driver: The WebDriver instance used for testing.
       """

    @pytest.fixture(scope="class", autouse=True)
    def setup_teardown_class(self, setup_teardown_method):
        """
        Fixture for setting up and tearing down the class.

            This fixture does the following:
            1. Initialize the WebDriver instance.
            2. Initialize the LoginPage instance for interacting with the login page.
            3. Navigate to the Salesforce login page.
            4. Performs login using credentials from the configuration file.
            5. Yields control to the test methods.
            6. Cleans up after the test class.

            Usage:
        """
        if not MailChimpBaseTest.driver:
            MailChimpBaseTest.driver = setup_teardown_method
            # self.driver.execute_script("window.open('about:blank','_blank');")
            # main_window = self.driver.current_window_handle
            # # Switch to the opened tab
            # for handle in self.driver.window_handles:
            #     if handle != main_window:
            #         self.driver.switch_to.window(handle)
            self.driver.get(ConfigReader.dataReadConfig("mailchimp login", "url"))
            self.logger.info("Mail Chimp Account Opened Successfully!")

