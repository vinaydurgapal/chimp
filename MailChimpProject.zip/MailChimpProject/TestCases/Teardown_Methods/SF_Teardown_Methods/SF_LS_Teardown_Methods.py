import pytest
from selenium.common import StaleElementReferenceException, NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Log_Setting import Sf_Log_Setting
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Merge_Field_Mapping import (
    SF_Merge_Field_Mapping,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def log_setting_teardown_method():
    """
    Test case to create a webhook log in the configuration settings.

    This test case creates a webhook log, saves the configuration, and validates the success message.

    Parameters:
        - None

    Returns:
        - None
    """
    # Get the logger instance
    logger = LogGen.loggen()
    # Initialize the necessary objects
    sf_log_setting = Sf_Log_Setting(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config.toggle_field(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "log setting", "toggle_create_webhook_log_xpath"
            )
        ),
        view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Create Webhook Log : -",
        conditions_dict={"Create Webhook Log": "True"},
        toggle_field_data="Create Webhook Log",
    )
    # Wait for the loader to disappear after toggling the field
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Wait for loader to disappear ",
    )
    try:
        # Select the webhook events
        available_events = sf_log_setting.select_webhook_events(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "log setting", "list_selected_webhook_list_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Select Webhook Events",
        )
        for event in available_events:
            event.click()
            sf_log_setting.move_from_available_to_selected(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "log setting", "btn_move_to_available_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Move from Available to Selected",
            )
            break
        # Save the configuration
        sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Save Button",
        )

        # Get the validation message
        validation_txt = sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Validation Message",
        )
        # Check if the validation message is "Success"
        assert validation_txt.text == "Saved"

        # Close the modal
        sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
        )

    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Save Button",
        )
        # Close the modal and fail the test if the validation message is not "Success"
        sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
        )
        sf_cf_dash.ok_btn(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Log Setting : Sure Ok Button",
        )
