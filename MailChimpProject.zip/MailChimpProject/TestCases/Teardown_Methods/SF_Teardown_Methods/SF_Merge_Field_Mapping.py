import pytest
from selenium.common import StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Merge_Field_Mapping import (
    SF_Merge_Field_Mapping,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


# Tear Down Method For  Dynamic Mapping Field Creation
def dynamic_mapping_teardown():
    """
    This function performs teardown actions after dynamic mapping.
    It handles closing modals, deleting buttons, and checking validation messages.
    """
    # Get the logger instance
    logger = LogGen.loggen()
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_merge_mapping = SF_Merge_Field_Mapping(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
    )
    sf_config.redirect_to_configuration_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "configuration locators", "config_name_xpath"
            )
        ),
        view="Teardown Method : Side View : Configuration :",
    )
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
    )

    if page_head.text == "Configuration":
        logger.info("Configuration Page Opened Successfully!")
        sf_edit_config.edit_configuration(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_edit_config_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration",
        )
        sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
        )
        sf_merge_mapping.merge_field_mapping(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : ",
        )
        sf_edit_config.drop_down(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "btn_dm_xpath")
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Dynamic Mapping : Drop Down",
        )
        sf_edit_config.drop_down(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "merge field mapping", "btn_dm_sub_drop_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : Dynamic Mapping : Sub Drop Down",
        )
        sf_cf_dash.delete_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "merge field mapping", "btn_dm_delete_xpath"
                )
            ),
            view="Teardown Method : Side View : Campaigns : Delete Button",
        )
        sf_cf_dash.ok_btn(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            view="Teardown Method : Side View : Campaigns : Delete Button",
        )

        # Get the validation message and check if it is 'Success'
        validation_txt = sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
        except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
            # Close the modal after creating the lead of MailChimp subscriber
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : General Setting :  Sure Ok Button",
            )
            pytest.fail("Required Toggle field not Enabled successfully!")


# Tear Down Method For Lead Mapping
def lead_mapping_teardown():
    """
    This function performs teardown actions after lead mapping.
    It handles configuration, merge field mapping, and validation messages.
    """

    # Get the logger instance
    logger = LogGen.loggen()

    # Initialize necessary objects
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_merge_mapping = SF_Merge_Field_Mapping(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
    )

    # Redirect to configuration page
    sf_config.redirect_to_configuration_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "configuration locators", "config_name_xpath"
            )
        ),
        view="Teardown Method : Side View : Configuration :",
    )
    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
    )
    # Get the page heading
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )

    # Check if the page heading is "Configuration"
    if page_head.text == "Configuration":
        logger.info("Configuration Page Opened Successfully!")

        # Edit configuration settings for lead mapping
        sf_edit_config.edit_configuration(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_edit_config_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration",
        )

        # Wait for loader to disappear
        sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
        )
        try:
            # Perform merge field mapping
            sf_merge_mapping.merge_field_mapping(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : ",
            )

            # Remove field
            sf_edit_config.remove_field(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "merge field mapping", "btn_lm_remove_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :Remove Field",
            )

            # Get the validation message
            validation_txt = sf_edit_config.get_validation_message(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "txt_validation_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Validation Message",
            )
            try:
                # Check if validation message is 'Success'
                assert validation_txt.text == "Success"
                sf_edit_config.save_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_save_and_close_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Save Button",
                )
                sf_edit_config.close_modal(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_close_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :  Close Button",
                )
                sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_cancel_sure_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :   Sure Ok Button",
                )
            except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
                # Handle exception and fail test
                sf_edit_config.close_modal(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_close_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :  Close Button",
                )
                sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_cancel_sure_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :   Sure Ok Button",
                )
        except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
            # Handle exception and fail test
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :  Close Button",
            )
            pytest.fail("Merge Field Mapping (Lead Mapping ) Failed")


def contact_mapping_teardown():
    """
    This function performs teardown actions after lead mapping.
    It handles configuration, merge field mapping, and validation messages.
    """

    # Get the logger instance
    logger = LogGen.loggen()

    # Initialize necessary objects
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_merge_mapping = SF_Merge_Field_Mapping(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
    )

    # Redirect to configuration page
    sf_config.redirect_to_configuration_page(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "configuration locators", "config_name_xpath"
            )
        ),
        view="Teardown Method : Side View : Configuration :",
    )

    # Get the page heading
    page_head = sf_cf_dash.return_page_heading(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "dashboard locators", "txt_heading_page_xpath"
            )
        ),
        view="",
    )

    # Check if the page heading is "Configuration"
    if page_head.text == "Configuration":
        logger.info("Configuration Page Opened Successfully!")

        # Edit configuration settings for lead mapping
        sf_edit_config.edit_configuration(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_edit_config_xpath"
                )
            ),
            view="Teardown Method : Side View : Configuration : Edit Configuration",
        )

        # Wait for loader to disappear
        sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Teardown Method : Side View : Configuration : Wait for loader to disappear ",
        )
        try:
            # Perform merge field mapping
            sf_merge_mapping.merge_field_mapping(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : ",
            )

            # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
            # sf_edit_config.drop_down(
            #     locator_strategy=By.XPATH,
            #     locator_value=str(
            #         ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")
            #     ),
            #     view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Drop Down",
            # )
            # sf_edit_config.drop_down(
            #     locator_strategy=By.XPATH,
            #     locator_value=str(
            #         ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_xpath")
            #     ),
            #     view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Drop Down",
            # )

            # Remove field
            sf_edit_config.remove_field(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "merge field mapping", "btn_cm_remove_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Remove Field",
            )

            # Get the validation message
            validation_txt = sf_edit_config.get_validation_message(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "txt_validation_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Validation Message",
            )
            try:
                # Check if validation message is 'Success'
                assert validation_txt.text == "Success"
                sf_edit_config.save_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_save_and_close_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Save Button",
                )
                sf_edit_config.close_modal(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_close_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :  Close Button",
                )
                sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_cancel_sure_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :   Sure Ok Button",
                )
            except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
                # Handle exception and fail test
                sf_edit_config.close_modal(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_close_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :  Close Button",
                )
                sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_cancel_sure_xpath"
                        )
                    ),
                    view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :   Sure Ok Button",
                )
                pytest.fail("Merge Field Mapping (Lead Mapping ) not removed successfully!")
        except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
            # Handle exception and fail test
            sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Teardown Method : Side View : Configuration : Edit Configuration : Merge Field Mapping :  Close Button",
            )
            pytest.fail("Merge Field Mapping (Lead Mapping ) Failed")