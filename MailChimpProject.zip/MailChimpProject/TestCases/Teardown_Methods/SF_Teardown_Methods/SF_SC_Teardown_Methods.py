import pytest
from selenium.common import StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Sync_Conditions import (
    SF_Sync_Conditions,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen





def sync_condition_teardown_segments_method():
    """
    Setup method to verify the page view of Configuration.

    This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
    It waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.

    Teardown method to clean up the Sync Conditions page.
    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the segments.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        - None

    Returns:
        - None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Allow record creation
    sf_sync.allow_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_allow_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Allow Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
    )

    # Delete segments
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_seg_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Segments : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Configuration : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_teardown_mailchimp_contacts_method():
    """
    Teardown method to clean up the Sync Conditions page.

    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the mailchimp contact.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        - None

    Returns:
        - None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Toggle allow record creation
    sf_sync.allow_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_allow_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Allow Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
    )

    # Delete mailchimp contact
    sf_sync.mailchimp_contact(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "sync conditions", "btn_mailchimp_contact_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Mailchimp Contact  ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_mc_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Mailchimp Contact : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Configuration : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate changes
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_teardown_contact_method():
    """
    This teardown method cleans up the Sync Conditions page by deleting the contact.

    It initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the contact.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        None

    Returns:
        None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Allow record creation
    sf_sync.allow_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_allow_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Allow Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
    )

    # Delete contact
    sf_sync.contact(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_contact_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Contact  ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_c_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Contact : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Configuration : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_teardown_lead_method():
    """
    Teardown method to clean up the Sync Conditions page.

    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the lead.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        - None

    Returns:
        - None
    """

    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Allow record creation
    sf_sync.allow_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_allow_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Allow Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
    )

    # Delete lead
    sf_sync.lead(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Lead  ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Lead : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_teardown_group_method():
    """
    Teardown method to clean up the Sync Conditions page.

    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the groups.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        None

    Returns:
        None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Allow record creation
    sf_sync.allow_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_allow_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Allow Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
    )

    # Delete groups
    sf_sync.groups(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Groups ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "sync conditions", "btn_groups_delete_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Groups : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Groups : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Groups : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )



def sync_condition_stop_teardown_segments_method():
    """
    Setup method to verify the page view of Configuration.

    This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
    It waits for the loader to disappear, redirects to the campaign page,
    retrieves the page heading, and verifies if the page is opened successfully.

    Teardown method to clean up the Sync Conditions page.
    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the segments.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        - None

    Returns:
        - None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Stop record creation
    sf_sync.stop_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_stop_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Stop Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
    )

    # Delete segments
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_seg_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Segments : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Configuration : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_stop_teardown_mailchimp_contacts_method():
    """
    Teardown method to clean up the Sync Conditions page.

    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the mailchimp contact.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        - None

    Returns:
        - None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Stop record creation
    sf_sync.stop_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_stop_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Stop Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
    )

    # Delete mailchimp contact
    sf_sync.mailchimp_contact(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "sync conditions", "btn_mailchimp_contact_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Mailchimp Contact  ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_mc_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Mailchimp Contact : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Configuration : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate changes
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_stop_teardown_contact_method():
    """
    This teardown method cleans up the Sync Conditions page by deleting the contact.

    It initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the contact.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        None

    Returns:
        None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Stop record creation
    sf_sync.stop_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_stop_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Stop Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
    )

    # Delete contact
    sf_sync.contact(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_contact_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Contact  ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_c_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Contact : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Configuration : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_stop_teardown_lead_method():
    """
    Teardown method to clean up the Sync Conditions page.

    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the lead.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        - None

    Returns:
        - None
    """

    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Stop record creation
    sf_sync.stop_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_stop_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Stop Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
    )

    # Delete lead
    sf_sync.lead(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Lead  ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_delete_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Lead : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


def sync_condition_stop_teardown_group_method():
    """
    Teardown method to clean up the Sync Conditions page.

    This method initializes the necessary classes and performs the following steps:
    1. Waits for the loader to disappear after toggling the field.
    2. Deletes the groups.
    3. Saves the changes.
    4. Validates the changes.

    Parameters:
        None

    Returns:
        None
    """
    # Initialize logger
    logger = LogGen.loggen()

    # Initialize necessary classes
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    # Stop record creation
    sf_sync.stop_record_creation(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_stop_record_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Stop Record Creation : ",
    )

    # Wait for loader to disappear
    sf_cf_dash.wait_for_loader_to_disappear(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
    )

    # Delete groups
    sf_sync.groups(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_xpath")
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Groups ",
    )
    sf_sync.delete_icon(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "sync conditions", "btn_groups_delete_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Groups : Delete Button",
    )

    # Save changes
    sf_edit_config.save_button(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "btn_save_and_close_xpath"
            )
        ),
        view="Teardown Method : Side view : Edit Configuration : Sync Conditions : Save Button",
    )

    # Validate if the changes were successful
    validation_txt = sf_edit_config.get_validation_message(
        locator_strategy=By.XPATH,
        locator_value=str(
            ConfigReader.locatorsReadConfig(
                "edit config locators", "txt_validation_xpath"
            )
        ),
        view="Teardown Method : Edit Configuration : Sync Conditions : Groups : Validation Message",
    )
    logger.info(
        f"Teardown Method : Edit Configuration : Sync Conditions : Groups : Validation Message : {validation_txt.text}"
    )
    try:
        assert validation_txt.text.startswith(
            "Success"
        ) or validation_txt.text.startswith(
            "Error"
        ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
    except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
        pytest.fail(
            "Teardown Method : Edit Configuration : Sync Conditions : Validation Failed"
        )


__all__ = [
    "sync_condition_teardown_segments_method",
    "sync_condition_teardown_mailchimp_contacts_method",
    "sync_condition_teardown_contact_method",
    "sync_condition_teardown_lead_method",
    "sync_condition_teardown_group_method",
    "sync_condition_stop_teardown_segments_method",
    "sync_condition_stop_teardown_mailchimp_contacts_method",
    "sync_condition_stop_teardown_contact_method",
    "sync_condition_stop_teardown_lead_method",
    "sync_condition_stop_teardown_group_method",
]
