import pytest
from selenium.common import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import CF_Edit_Configuration
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader
from Utilities.LogUtil import LogGen


def move_selected_field_to_available_field():
    """
    Moves a selected field from the visible fields to the available fields.
    Validates the changes were successful and logs the validation message.
    """

    # Get the logger instance
    logger = LogGen.loggen()

    # Initialize the CF Dashboard View (CF_Dashboard_View) instance
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)

    try:
        # Navigate to the utility setting page
        sf_cf_dash.utility_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_setting_xpath"
                )
            ),
            view="Teardown Methods : Side View : Campaign : Setting : Utility Setting",
        )

        # Move the selected field from the visible fields to the available fields
        sf_cf_dash.select_fields_move_from_visible_to_available_and_save(
            utility_setting_section=By.XPATH,
            utility_setting_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "lnk_items_xpath")
            ),
            utility_setting_view="Teardown Methods : Side View : Campaign : Setting : Utility Setting ",
            available_selected_field_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_filed_to_display"
            ),
            select_fields_section=By.XPATH,
            select_fields_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_visible_field_to_display"
                )
            ),
            select_fields_view="Teardown Methods : Side View : Campaign : Setting : Utility Setting : Select Fields ",
            available_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_display_camp_fields"
            ),
            move_button_section=By.XPATH,
            move_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_move_selected_xpath"
                )
            ),
            move_button_view="Teardown Methods : Side View : Campaign : Setting : Select Field To Search : Move Selected To Visible",
            save_button_section=By.XPATH,
            save_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_save_pop_up_xpath"
                )
            ),
            save_button_view="Teardown Methods : Side View : Campaign : Setting : Selected Field To Display : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Teardown Methods : Side View : Campaign : Validation Message",
        )

        try:
            assert validation_txt.text.startswith(
                "Success"
            ), f"Validation text '{validation_txt.text}' should start with 'Success'"
            logger.info(
                f"Teardown Methods : Side View : Campaign : Validation Message : {validation_txt.text}")
        except (NoSuchElementException, NoSuchElementException, TimeoutException):
            pytest.fail("Teardown Methods : Side View : Campaign : Label: Teardown fail")
    except (NoSuchElementException, NoSuchElementException, TimeoutException):
        pytest.fail("Teardown Methods : Side View : Campaign : Label: Teardown fail")


def move_search_selected_field_to_available_field():
    """
    Moves a selected field from the visible fields to the available fields.
    Validates the changes were successful and logs the validation message.
    """

    # Get the logger instance
    logger = LogGen.loggen()

    # Initialize the CF Dashboard View (CF_Dashboard_View) instance
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)

    try:
        # Navigate to the utility setting page
        sf_cf_dash.utility_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_setting_xpath"
                )
            ),
            view="Teardown Methods : Side View : Campaign : Setting : Utility Setting",
        )

        # Move the selected field from the visible fields to the available fields
        sf_cf_dash.select_fields_move_from_visible_to_available_and_save(
            utility_setting_section=By.XPATH,
            utility_setting_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "lnk_items_xpath")
            ),
            utility_setting_view="Teardown Methods : Side View : Campaign : Setting : Utility Setting ",
            available_selected_field_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_field_to_search"
            ),
            select_fields_section=By.XPATH,
            select_fields_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_selected_fields_xpath"
                )
            ),
            select_fields_view="Teardown Methods : Side View : Campaign : Setting : Utility Setting : Select Fields ",
            available_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_search_mc_fields"
            ),
            move_button_section=By.XPATH,
            move_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_move_selected_xpath"
                )
            ),
            move_button_view="Teardown Methods : Side View : Campaign : Setting : Select Field To Search : Move Selected To Visible",
            save_button_section=By.XPATH,
            save_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_save_pop_up_xpath"
                )
            ),
            save_button_view="Teardown Methods : Side View : Campaign : Setting : Selected Field To Display : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Teardown Methods : Side View : Campaign : Validation Message",
        )

        try:
            assert validation_txt.text.startswith(
                "Success"
            ), f"Validation text '{validation_txt.text}' should start with 'Success'"
            logger.info(
                f"Teardown Methods : Side View : Campaign : Validation Message : {validation_txt.text}")
        except (NoSuchElementException, NoSuchElementException, TimeoutException):
            pytest.fail("Teardown Methods : Side View : Campaign : Label: Teardown fail")
    except (NoSuchElementException, NoSuchElementException, TimeoutException):
        pytest.fail("Teardown Methods : Side View : Campaign : Label: Teardown fail")
