import pytest
from TestCases.TC_SalesforceChimp.SalesForceBaseTest import SalesForceBaseTest


class TestLogins(SalesForceBaseTest):
    def test_login_functionalityss(self):
        """Verifying the shop delete functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        self.logger.info("Passe===========================")

