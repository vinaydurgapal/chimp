from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Segments import SF_Segments
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Segments(SalesForceBaseTest):

    def test_segments_page(self):
        """Verifying the Page View Of Segments
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_segment = SF_Segments(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Segments class.
        This method creates a new instance of the Segments class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Tags : Wait for loader to disappear ")
        sf_segment.redirect_to_segment_page(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("segment locators",
                                                                                          "segment_name_xpath")),
                                        view="Side View : Segments : ")
        self.logger.info("Segments Page Opened Successfully!")

    def test_segment_refresh_page(self):
        """Verifying the Refresh Button Of Page View Of segment
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the configuration class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Segments : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Segments : Refresh : ")
        self.logger.info("Mailchimp Segments Page Refreshed Successfully!")

    # default_mailchimp_account : dmc
    def test_select_dmc_account(self):
        """Verifying the Select Default Segments
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Segments class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Segments : Wait for loader to disappear ")
        sf_cf_dash.select_mailchimp_account(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                            , view="Side view : Segments : Select Mailchimp Account : ",
                                            locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "select_default_account_xpath"))
                                            , view2="Side view : Segments : Select DMC Account : ")

        self.logger.info("Segments Page Mail Chimp Default Account Selected Successfully!")


    def test_select_audience_account(self):
        """Verifying the Select Default Audience Segments
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the  Segments class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view :  Segments : Wait for loader to disappear ")
        sf_cf_dash.select_mailchimp_account(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_audience_xpath"))
                                            , view="Side view :  Segments : Select Mailchimp Account : ",
                                            locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "select_audience_xpath"))
                                            , view2="Side view : Segments : Select Audience Account : ")

        self.logger.info(" Segments Page Default  Audience Account Selected Successfully!")

    def test_mass_import(self):
        """Verifying the  Segments Mass Import
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Segments class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Segments : Wait for loader to disappear ")
        sf_cf_dash.mass_import(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_mass_import_xpath")),
                               view="Side view : Segments : Mass Import : ")
        # locator = ConfigReader.locatorsReadConfig("dashboard locators", "progress_bar_xpath")
        # self.logger.info(f"{locator}")
        # sf_cf_dash.wait_for_progress_bar(locator_strategy=By.XPATH,
        #                                  locator_value=str(
        #                                      ConfigReader.locatorsReadConfig("dashboard locators",
        #                                                                      "progress_bar_xpath")), view="")