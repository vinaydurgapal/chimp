import pytest
from selenium.common import NoSuchElementException, StaleElementReferenceException, TimeoutException, \
    ElementClickInterceptedException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_MailchimpContacts import SF_MailChimpContacts
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from TestCases.Setup_Methods.SF_Setup_Methods.SF_Configuration_Setup_Methods.SF_General_Setting import (
    general_setting_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_EC_General_Setting(SalesForceBaseTest):
    # SETUP METHODS
    def setup_method(self):
        """
        This method sets up the test case by calling the `general_setting_setup_method()`.

        This method is called before each test case is executed.
        """
        # Call the general_setting_setup_method() function
        general_setting_setup_method()
        self.sf_config = SF_Configuration(SalesForceBaseTest.driver)
        self.sf_mail_chimp_contact = SF_MailChimpContacts(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)

    @pytest.fixture()
    def test_edit_configuration_setting(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """

        self.sf_edit_config.edit_configuration(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_edit_config_xpath"
                )
            ),
            view="Setup Method : Side View : Configuration : Edit Configuration",
        )
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Setup Method : Step : Side View : Configuration : Wait for loader to disappear ",
        )

    
    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_create_lead_of_mailChimp_subscriber(self):
        """
        Test case to create a lead of MailChimp subscriber.

        This test case verifies that the lead is successfully created.

        Parameters:
            - None

        Returns:
            - None
        """

        # Toggle the field for creating a lead of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber ",
            conditions_dict={"MailChimp Subscriber": "True"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Toggle the field for creating a contact of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Contact of MailChimp Subscriber ",
            conditions_dict={"Create Contact": "False"},
            toggle_field_data="Create Contact",
        )
        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            # Wait for the loader to disappear after toggling the field
            self.sf_cf_dash.wait_for_loader_to_disappear(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
            )
            # Validation Section
            try:
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Redirect to Mailchimp Contacts Page ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Mass Import :",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Mass Import :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "txt_ess_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Text",
                )
                if list_text:
                    self.logger.info(
                        f"create a lead of MailChimp subscriber. created successfully!: {list_text}"
                    )
                else:
                    pytest.fail(
                        "create a lead of MailChimp subscriber. not created successfully!"
                    )

            except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
                pytest.fail(
                    "create a lead of MailChimp subscriber. not created successfully!"
                )

        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )

    
    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_create_contact_of_mailChimp_subscriber(self):
        """
        Test case to create a contact of MailChimp subscriber.

        This test case verifies that the lead is successfully created.

        Parameters:
            - None

        Returns:
            - None
        """
        # Toggle the field for creating a lead of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"MailChimp Subscriber": "False"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Toggle the field for creating a contact of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Contact of MailChimp Subscriber :",
            conditions_dict={"Create Contact": "True"},
            toggle_field_data="Create Contact",
        )

        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            # Validation Section
            try:
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Redirect to Mailchimp Contacts Page ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Mass Import :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "txt_ess_contact_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Create a Contacts of MailChimp subscriber. created successfully! : {list_text} "
                    )
                else:
                    pytest.fail(
                        "Create a Contacts of MailChimp subscriber. not created successfully!"
                    )

            except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
                pytest.fail(
                    "create a lead of MailChimp subscriber. not created successfully!"
                )

        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_create_subscriber_only_when_email_matches(self):
        """
        Test case to create a subscriber only when email matches.

        This test case verifies that the lead is successfully created.

        Parameters:
            - None

        Returns:
            - None
        """
        # Toggle the field for creating a lead of MailChimp subscriber

        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_subscriber_only_email_match_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Subscriber Only When Email Matches: ",
            conditions_dict={"Email Match": "False"},
            toggle_field_data="Email Match",
        )

        # Wait for the loader to disappear after toggling the field

        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )

        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )

    @pytest.mark.skip(
        "Toggle Off Function After The Above Test Cases Are Implemented But For Now Skip It"
    )
    def test_change_the_field_in_default_view(self):
        """
        Test method to change the field in the default view.

        This method will update the lead and contact fields in the default view.
        """
        # Define the list of toggle data for different field changes
        toggle_data_list = [
            {
                "locator_strategy": By.XPATH,
                "locator_value": str(
                    ConfigReader.locatorsReadConfig(
                        "general setting locators",
                        "btn_lead_mailchimp_subscriber_xpath",
                    )
                ),
                "view": "Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
                "conditions_dict": {"MailChimp Subscriber": "False"},
                "toggle_field_data": "MailChimp Subscriber",
            },
            {
                "locator_strategy": By.XPATH,
                "locator_value": str(
                    ConfigReader.locatorsReadConfig(
                        "general setting locators",
                        "btn_contact_mailchimp_subscriber_xpath",
                    )
                ),
                "view": "Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create a Contact of MailChimp Subscriber :",
                "conditions_dict": {"Create Contact": "False"},
                "toggle_field_data": "Create Contact",
            },
            {
                "locator_strategy": By.XPATH,
                "locator_value": str(
                    ConfigReader.locatorsReadConfig(
                        "general setting locators",
                        "btn_subscriber_only_email_match_xpath",
                    )
                ),
                "view": "Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create a Subscriber Only When Email Matches: ",
                "conditions_dict": {"Email Match": "False"},
                "toggle_field_data": "Email Match",
            },
        ]
        try:
            # Loop through the toggle data list and toggle each field
            for toggle_data in toggle_data_list:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
                )
                self.sf_config.redirect_to_configuration_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "configuration locators", "config_name_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration :",
                )
                self.sf_edit_config.edit_configuration(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_edit_config_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration : Edit Configuration",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
                )
                self.sf_edit_config.toggle_field(
                    toggle_data["locator_strategy"],
                    toggle_data["locator_value"],
                    toggle_data["view"],
                    toggle_data["conditions_dict"],
                    toggle_data["toggle_field_data"],
                )

                # Wait for the loader to disappear after toggling the field
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
                )

                # Save the changes made
                self.sf_edit_config.save_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_save_and_close_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
                )

                # Get the validation message and check if it is 'Success'
                validation_txt = self.sf_edit_config.get_validation_message(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "txt_validation_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
                )
                try:
                    assert validation_txt.text == "Success"
                    self.sf_edit_config.close_modal(
                        locator_strategy=By.XPATH,
                        locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "edit config locators", "btn_close_xpath"
                            )
                        ),
                        view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
                    )
                except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
                    # Close the modal after creating the lead of MailChimp subscriber
                    self.sf_edit_config.close_modal(
                        locator_strategy=By.XPATH,
                        locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "edit config locators", "btn_close_xpath"
                            )
                        ),
                        view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
                    )
                    self.sf_cf_dash.ok_btn(
                        locator_strategy=By.XPATH,
                        locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "dashboard locators", "btn_cancel_sure_xpath"
                            )
                        ),
                        view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
                    )
                    pytest.fail("Toggle field not disabled successfully!")
        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_info_create_lead_of_mailchimp_subscriber(self):
        """
        Test case to get the info create a lead of MailChimp subscriber.

        This test case verifies t get the info create a lead of MailChimp subscriber.

        Parameters:
            - self: The instance of the test class.

        Returns:
            - None
        """
        info_text = self.sf_edit_config.get_info_text(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "txt_info_lead_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Info Text",
        )
        self.logger.info(info_text)
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
        )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_info_create_contact_of_mailchimp_subscriber(self):
        """
        Test case to get the info create a contact of MailChimp subscriber.

        This test case verifies t get the info create a contact of MailChimp subscriber.

        Parameters:
            - self: The instance of the test class.

        Returns:
            - None
        """
        info_text = self.sf_edit_config.get_info_text(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "txt_info_contact_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Info Text",
        )
        self.logger.info(info_text)
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
        )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_info_create_subscriber_only_when_email_matches(self):
        """
        Test case to get the info create MailChimp subscriber only when email matches.

        This test case verifies  get the info create MailChimp subscriber only when email matches.

        Parameters:
            - self: The instance of the test class.

        Returns:
            - None
        """
        info_text = self.sf_edit_config.get_info_text(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "txt_info_subscriber_only_email_match_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Info Text",
        )
        self.logger.info(info_text)
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
        )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_pop_up_static_text(self):
        """
        Test case to get the static text from the general setting.

        This test case verifies the retrieval of static text from the general setting.

        Parameters:
            - self: The instance of the test class.

        Returns:
            - None
        """
        # Get static text from the general setting
        static_text = self.sf_edit_config.get_text(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "txt_general_setting_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Static Text",
        )

        # Log the static text
        self.logger.info(static_text)
        assert (
            ConfigReader.dataReadConfig("general setting", "txt_general_setting")
            in static_text
        )
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
        )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_update_lead(self):
        """
        Test case to update the lead of MailChimp subscriber.

        This test case verifies that the lead is successfully updated.

        Parameters:
            - self: The instance of the test class.

        Returns:
            - None
        """
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"MailChimp Subscriber": "True"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Check box the field to update the lead of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_lead_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update lead": "True"},
            check_box_data="Update lead",
        )

        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )

        try:
            # Check if the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )

            # Click the "OK" button in the confirmation modal
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )

            # Fail the test if the lead was not created successfully
            pytest.fail(
                "Update a lead of MailChimp subscriber. not created successfully!"
            )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_update_contact(self):
        """
        Test case to update the contact of  MailChimp subscriber.

        This test case verifies that the lead is successfully updated.

        Parameters:
            - self: The instance of the test class.

        Returns:
            - None
        """
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"MailChimp Subscriber": "True"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Check box the field to update the contact of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_contact_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update contact": "True"},
            check_box_data="Update contact",
        )

        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )

        try:
            # Check if the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )

            # Click the "OK" button in the confirmation modal
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )

            # Fail the test if the lead was not created successfully
            pytest.fail(
                "Update a lead of MailChimp subscriber. not created successfully!"
            )
    # NOTE - If lead and contact both do not exist in Salesforce, then we will create a lead
    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_create_contact_and_create_lead_both_update(self):
        """
        Test case to create a contact of MailChimp subscriber.
        Test case to create a lead of MailChimp subscriber.
        This test case verifies that the contact is successfully created.
        condition is both contact and lead update is true.
        Parameters:
            - None

        Returns:
            - None
        """
        # Toggle the field for creating a lead of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"MailChimp Subscriber": "True"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Toggle the field for creating a contact of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Contact of MailChimp Subscriber :",
            conditions_dict={"Create Contact": "True"},
            toggle_field_data="Create Contact",
        )
        # Check box the field to update the lead of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_lead_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update lead": "False"},
            check_box_data="Update lead",
        )
        # Check box the field to update the contact of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_contact_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update contact": "False"},
            check_box_data="Update contact",
        )

        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            # Validation Section
            try:
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Redirect to Mailchimp Contacts Page ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button",
                )
                self.sf_mail_chimp_contact.modal_delete_options(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "inpt_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : Lead Button",
                )
                self.sf_mail_chimp_contact.modal_delete_options(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "inpt_contact_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : contact Button",
                )

                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Mass Import :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear  ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "txt_ess_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Create a Contacts of MailChimp subscriber. created successfully! : {list_text} "
                    )
                else:
                    pytest.fail(
                        "Create a Contacts of MailChimp subscriber. not created successfully!"
                    )

            except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
                pytest.fail(
                    "create a lead of MailChimp subscriber. not created successfully!"
                )

        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )
    # NOTE - If a lead exists but the contact does not exist in Salesforce, then we will update the lead
    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_create_contact_and_create_lead_but_lead_update(self):
        """
        Test case to create a contact of MailChimp subscriber.
        Test case to create a lead of MailChimp subscriber.
        This test case verifies that the contact is successfully created.
        condition is  lead update is true.
        Parameters:
            - None

        Returns:
            - None
        """
        # Toggle the field for creating a lead of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"MailChimp Subscriber": "True"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Toggle the field for creating a contact of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Contact of MailChimp Subscriber :",
            conditions_dict={"Create Contact": "True"},
            toggle_field_data="Create Contact",
        )
        # Check box the field to update the lead of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_lead_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update lead": "True"},
            check_box_data="Update lead",
        )
        # Check box the field to update the contact of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_contact_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update contact": "False"},
            check_box_data="Update contact",
        )
        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            # Validation Section
            try:
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Redirect to Mailchimp Contacts Page ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button",
                )
                self.sf_mail_chimp_contact.modal_delete_options(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "inpt_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : Lead Button",
                )
                self.sf_mail_chimp_contact.modal_delete_options(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "inpt_contact_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : contact Button",
                )

                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear  ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Mass Import :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear  ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "txt_ess_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Create a Contacts of MailChimp subscriber. created successfully! : {list_text} "
                    )
                else:
                    pytest.fail(
                        "Create a Contacts of MailChimp subscriber. not created successfully!"
                    )

            except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
                pytest.fail(
                    "create a lead of MailChimp subscriber. not created successfully!"
                )

        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )


    @pytest.mark.usefixtures("test_edit_configuration_setting")
    def test_create_contact_and_create_lead_but_contact_update(self):
        """
        Test case to create a contact of MailChimp subscriber.
        Test case to create a lead of MailChimp subscriber.
        This test case verifies that the contact is successfully created.
        condition is contact update is true.
        Parameters:
            - None

        Returns:
            - None
        """
        # Toggle the field for creating a lead of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_lead_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"MailChimp Subscriber": "True"},
            toggle_field_data="MailChimp Subscriber",
        )
        # Toggle the field for creating a contact of MailChimp subscriber
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators", "btn_contact_mailchimp_subscriber_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Contact of MailChimp Subscriber :",
            conditions_dict={"Create Contact": "True"},
            toggle_field_data="Create Contact",
        )
        # Check box the field to update the lead of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_lead_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Lead of MailChimp Subscriber :",
            conditions_dict={"Update lead": "False"},
            check_box_data="Update lead",
        )
        # Check box the field to update the contact of MailChimp subscriber
        self.sf_edit_config.check_box(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "general setting locators",
                    "chk_box_contact_mailchimp_subscriber_xpath",
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Create Contact of MailChimp Subscriber :",
            conditions_dict={"Update contact": "False"},
            check_box_data="Update contact",
        )

        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ",
        )
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Save Button",
        )
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Validation Message",
        )
        try:
            assert validation_txt.text == "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            # Validation Section
            try:
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Redirect to Mailchimp Contacts Page ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button",
                )
                # modal delete option for lead
                self.sf_mail_chimp_contact.modal_delete_options(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "inpt_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : Lead Button",
                )
                # modal delete option for contact
                self.sf_mail_chimp_contact.modal_delete_options(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "inpt_contact_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : contact Button",
                )

                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : RWait for loader to disappear  ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Mass Import :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Wait for loader to disappear  ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "txt_ess_lead_xpath"
                        )
                    ),
                    view="Test Case : Step : Side View : Mailchimp Contacts : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Create a Contacts of MailChimp subscriber. created successfully! : {list_text} "
                    )
                else:
                    pytest.fail(
                        "Create a Contacts of MailChimp subscriber. not created successfully!"
                    )

            except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
                pytest.fail(
                    "create a lead of MailChimp subscriber. not created successfully!"
                )

        except (NoSuchElementException, StaleElementReferenceException, TimeoutException , ElementClickInterceptedException):
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : General Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )

    # TODO:  Reason : we need to validate it from mailchimp account and right now we have login restriction on mailchimp account

    # TODO:  If a lead exists but the contact does not exist in Salesforce, then we will update the lead

    # TODO:  If a lead does not exist and contact exists in Salesforce, then we will update the contact

    # TODO: If lead and contact both exist in Salesforce but lead is not converted to contact, then we will update the lead

    # TODO: If lead and contact both exist in Salesforce but lead is converted to contact, then we will update the contact-

    # TODO: Create Subscriber Only When Email Matches: Need to validate it later


print(Test_EC_General_Setting.__doc__)