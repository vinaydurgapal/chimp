import pytest
from selenium.common import StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Log_Setting import Sf_Log_Setting
from TestCases.Setup_Methods.SF_Setup_Methods.SF_Configuration_Setup_Methods.SF_Log_Setting import (
    log_setting_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from TestCases.Teardown_Methods.SF_Configuration_Teardown_Methods.SF_Log_Setting import (
    log_setting_teardown_method
)
from Utilities import ConfigReader


class Test_EC_Log_Setting(SalesForceBaseTest):
    # SETUP METHODS
    def setup_method(self):
        """
        This method sets up the test case by calling the `log_setting_setup_method()`.

        This method is called before each test case is executed.
        """
        # Call the log_setting_setup_method() function
        log_setting_setup_method()
        self.sf_log_setting = Sf_Log_Setting(SalesForceBaseTest.driver)
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        # Initialize the necessary objects
        self.sf_log_setting = Sf_Log_Setting(SalesForceBaseTest.driver)
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # TEARDOWN METHODS
    @staticmethod
    def teardown_method(method):
        """
        Perform teardown work for the test case.

        Args:
            method (function): The test method that is being torn down.

        This method checks the name of the test method and performs teardown work
        specific to the test_select_webhook_events test case.

        """
        # Get the name of the test method
        test_name = method.__name__
        # __name__ variable is a built-in variable that holds the name of the current module.
        # It is used to determine whether a module is being run as the main module or being imported as a module
        # If the test method is test_select_webhook_events, perform teardown work
        if test_name == "test_select_webhook_events":
            log_setting_teardown_method()

    def test_log_setting_edit_icon(self):
        """
        This test case clicks on the edit icon of Log Setting and sets the number of days to 5.
        It then saves the configuration and checks if the validation message is "Success".
        If the validation message is not "Success", it closes the modal and fails the test.

        Args:
            None

        Returns:
            None
        """
        # Initialize the necessary objects

        # Click on the edit icon of Log Setting
        self.sf_log_setting.Log_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("log setting", "edit_icon_xpath")
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Edit Icon",
        )

        # Set the number of days to 5
        self.sf_log_setting.number_of_days(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("log setting", "inpt_nod_xpath")
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Number of Days :",
            send_text="5",
        )

        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Wait for loader to disappear ",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Validation Message",
        )

        try:
            # Check if the validation message is "Success"
            assert validation_txt.text == "Saved"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
            )
        except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
            # Close the modal and fail the test if the validation message is not "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Sure Ok Button",
            )
            pytest.fail(
                "create a lead of MailChimp subscriber. not created successfully!"
            )

    def test_select_webhook_events(self):
        """
        Test case to create a webhook log in the configuration settings.

        This test case creates a webhook log, saves the configuration, and validates the success message.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_edit_config.toggle_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "log setting", "toggle_create_webhook_log_xpath"
                )
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Create Webhook Log :",
            conditions_dict={"Create Webhook Log": "True"},
            toggle_field_data="Create Webhook Log",
        )
        # Wait for the loader to disappear after toggling the field
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Wait for loader to disappear ",
        )
        try:
            # Select the webhook events
            available_events = self.sf_log_setting.select_webhook_events(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "log setting", "list_available_webhook_list_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Select Webhook Events",
            )
            for event in available_events:
                event.click()
                self.sf_log_setting.move_from_available_to_selected(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "log setting", "btn_move_to_selected_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Move from Available to Selected",
                )

            # Save the configuration
            self.sf_edit_config.save_button(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_save_and_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Save Button",
            )

            # Get the validation message
            validation_txt = self.sf_edit_config.get_validation_message(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "txt_validation_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Validation Message",
            )
            try:
                # Check if the validation message is "Success"
                assert validation_txt.text == "Saved"

                # Close the modal
                self.sf_edit_config.close_modal(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_close_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
                )
                """
                This method is called after each test method in the class.
                It calls the `log_setting_teardown_method` function to perform any necessary cleanup or teardown operations.
    
                This method is used to perform any necessary cleanup or teardown operations after each test method in the class.
                It is typically used to reset the state of the class or release any resources that were acquired during the test.
    
                This method does not take any parameters and does not return any values.
                """
                # Call the teardown method for log settings

                # self.teardown_method()
            except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
                # Close the modal
                self.sf_edit_config.close_modal(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "edit config locators", "btn_close_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
                )
                """
                This method is called after each test method in the class.
                It calls the `log_setting_teardown_method` function to perform any necessary cleanup or teardown operations.

                This method is used to perform any necessary cleanup or teardown operations after each test method in the class.
                It is typically used to reset the state of the class or release any resources that were acquired during the test.

                This method does not take any parameters and does not return any values.
                """
                # Call the teardown method for log settings

                # self.teardown_method()
        except (StaleElementReferenceException, ElementClickInterceptedException, NoSuchElementException):
            self.sf_edit_config.save_button(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_save_and_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Save Button",
            )
            # Close the modal and fail the test if the validation message is not "Success"
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Side View : Configuration : Edit Configuration : Log Setting : Sure Ok Button",
            )

print(Test_EC_Log_Setting.__doc__)