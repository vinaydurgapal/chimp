import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import CF_Edit_Configuration
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Sync_Conditions import SF_Sync_Conditions
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_EC_Sync_Conditions(SalesForceBaseTest):

    def setup_method(self):
        """
        Setup method to verify the page view of Configuration.

        This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
        It waits for the loader to disappear, redirects to the campaign page,
        retrieves the page heading, and verifies if the page is opened successfully.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_config = SF_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Configuration class.
        This method creates a new instance of the Configuration class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_config.redirect_to_configuration_page(locator_strategy=By.XPATH,
                                                 locator_value=str(
                                                     ConfigReader.locatorsReadConfig("configuration locators",
                                                                                     "config_name_xpath")),
                                                 view="Side View : Configuration :")
        page_head = sf_cf_dash.return_page_heading(locator_strategy=By.XPATH,
                                                   locator_value=str(
                                                       ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                       "txt_heading_page_xpath"))
                                                   , view="")
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        if page_head.text == "Configuration":
            self.logger.info("Configuration Page Opened Successfully!")
            sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                              locator_value=str(
                                                  ConfigReader.locatorsReadConfig("edit config locators",
                                                                                  "btn_edit_config_xpath")),
                                              view="Side View : Configuration : Edit Configuration")
            sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                    locator_value=str(
                                                        ConfigReader.locatorsReadConfig("loader_locators",
                                                                                        "loader_xpath")),
                                                    view="Side view : Configuration : Wait for loader to disappear ")
        else:
            pytest.fail("Configuration Page not Opened Successfully!")
        toggle_data_list = [
            {"locator_strategy": By.XPATH, "locator_value": str(
                ConfigReader.locatorsReadConfig("general setting locators", "btn_lead_mailchimp_subscriber_xpath")),
             "view": "Side View : Configuration : Edit Configuration  : General Setting : Create Lead of MailChimp Subscriber : ",
             "conditions_dict": {"MailChimp Subscriber": "True"}, "toggle_field_data": "MailChimp Subscriber"},

            {"locator_strategy": By.XPATH, "locator_value": str(
                ConfigReader.locatorsReadConfig("general setting locators", "btn_contact_mailchimp_subscriber_xpath")),
             "view": "Side View : Configuration : Edit Configuration  : General Setting : Create a Contact of MailChimp Subscriber : ",
             "conditions_dict": {"Create Contact": "True"}, "toggle_field_data": "Create Contact"}]
        try:
            # Loop through the toggle data list and toggle each field
            for toggle_data in toggle_data_list:
                sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("loader_locators",
                                                                                            "loader_xpath")),
                                                        view="Side view : Configuration : Wait for loader to disappear ")
                sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("edit config locators",
                                                                                      "btn_edit_config_xpath")),
                                                  view="Side View : Configuration : Edit Configuration")
                sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("loader_locators",
                                                                                            "loader_xpath")),
                                                        view="Side view : Configuration : Wait for loader to disappear ")
                sf_edit_config.toggle_field(toggle_data["locator_strategy"], toggle_data["locator_value"],
                                            toggle_data["view"],
                                            toggle_data["conditions_dict"], toggle_data["toggle_field_data"])

                # Wait for the loader to disappear after toggling the field
                sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("loader_locators",
                                                                                            "loader_xpath")),
                                                        view="Side View : Configuration : Edit Configuration : General Setting : Wait for loader to disappear ")

                # Save the changes made
                sf_edit_config.save_button(locator_strategy=By.XPATH,
                                           locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                             "btn_save_and_close_xpath")),
                                           view="Side View : Configuration : Edit Configuration : General Setting : Save Button")

                # Get the validation message and check if it is 'Success'
                validation_txt = sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                       locator_value=str(
                                                                           ConfigReader.locatorsReadConfig(
                                                                               "edit config locators",
                                                                               "txt_validation_xpath")),
                                                                       view="Side View : Configuration : Edit Configuration : General Setting : Validation Message")
                try:
                    assert validation_txt.text == "Success"
                    sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_close_xpath")),
                                               view="Side View : Configuration : Edit Configuration : General Setting : Close Button")
                    sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                                      locator_value=str(
                                                          ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_edit_config_xpath")),
                                                      view="Side View : Configuration : Edit Configuration")
                    sf_sync.sync_conditions(locator_strategy=By.XPATH,locator_value=str(
                        ConfigReader.locatorsReadConfig("sync conditions", "lnk_sc_xpath")),
                                            view="Side View : Configuration : Edit Configuration : General Setting : Sync Button")

                except Exception as e:
                    # Close the modal after creating the lead of MailChimp subscriber
                    sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_close_xpath")),
                                               view="Side View : Configuration : Edit Configuration : General Setting : Close Button")
                    sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                      view="Side View : Configuration : Edit Configuration : General Setting :  Sure Ok Button"
                                      )
                    pytest.fail("Required Toggle field not Enabled successfully!")
        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                       locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                         "btn_close_xpath")),
                                       view="Side View : Configuration : Edit Configuration : General Setting : Close Button")
            sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                              view="Side View : Configuration : Edit Configuration : General Setting :  Sure Ok Button"
                              )
            pytest.fail("Required Toggle field not Enabled successfully!")

    # @pytest.mark.skip
    def test_segments(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

        self.logger.info("Sync Conditions Page Opened Successfully!")

    def test_mailchimp_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

        self.logger.info("Sync Conditions Page Opened Successfully!")


    def test_group(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

        self.logger.info("Sync Conditions Page Opened Successfully!")




    def test_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

        self.logger.info("Sync Conditions Page Opened Successfully!")




