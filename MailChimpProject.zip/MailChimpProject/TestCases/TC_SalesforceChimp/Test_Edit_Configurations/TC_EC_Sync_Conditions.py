import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Sync_Conditions import (
    SF_Sync_Conditions,
)
from TestCases.Setup_Methods.SF_Setup_Methods.SF_SM_Edit_Configuration.SF_Sync_Condition import (
    sync_condition_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from TestCases.Teardown_Methods.SF_Teardown_Methods.SF_SC_Teardown_Methods import (
    sync_condition_teardown_segments_method,
    sync_condition_teardown_mailchimp_contacts_method,
    sync_condition_teardown_contact_method,
    sync_condition_teardown_lead_method,
    sync_condition_teardown_group_method,
    sync_condition_stop_teardown_segments_method,
    sync_condition_stop_teardown_mailchimp_contacts_method,
    sync_condition_stop_teardown_contact_method,
    sync_condition_stop_teardown_lead_method,
    sync_condition_stop_teardown_group_method,
)
from Utilities import ConfigReader


class Test_EC_Sync_Conditions(SalesForceBaseTest):

    def setup_method(self):
        """
        Setup method to initialize classes and verify the page view of Configuration.

        This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
        It waits for the loader to disappear, redirects to the Sync Conditions page,
        retrieves the page heading, and verifies if the page is opened successfully.

        Parameters:
            - None

        Returns:
            - None
        """
        # Call the setup method for sync conditions
        sync_condition_setup_method()

        # Initialize SF_Configuration, CF_Dashboard_View, CF_Edit_Configuration, and SF_Sync_Conditions classes
        self.sf_config = SF_Configuration(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)

    def test_allow_segments(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Allow Record Creation : ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_sync.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    def test_allow_record_creation_segment_teardown(self):
        """
        Perform teardown operations after the test case.

        This method is responsible for cleaning up any resources used by the test case.
        It calls the `sync_condition_teardown_method` to ensure that all sync conditions
        are properly cleaned up.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        sync_condition_teardown_segments_method()

    def test_allow_mailchimp_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Allow Record Creation : ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.mailchimp_contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mailchimp_contact_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
        )
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
            value="N",
        )
        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    def test_allow_record_creation_mailchimp_contacts_teardown(self):
        """
        This method is used to perform teardown operations after the test case.

        It calls the `sync_condition_teardown_method` to clean up any resources.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        # The method is responsible for cleaning up resources related to sync conditions
        # It is called after the test case to ensure proper cleanup
        sync_condition_teardown_mailchimp_contacts_method()

    def test_allow_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Allow Record Creation : ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_contact_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Contact  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Last Name",
            value="Last",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Validation Failed"
            )

    def test_allow_record_creation_contact_teardown(self):
        """
        Teardown method to clean up resources after test case.

        This method calls the `sync_condition_teardown_method` to ensure that
        any resources used by the test case are properly cleaned up.

        Args:
            self (object): The instance of the class.

        Returns:
            None
        """

        # Call the teardown method for sync conditions
        sync_condition_teardown_contact_method()

    def test_allow_group(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Allow Record Creation : ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.groups(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_select_field_xpath")),
        #                           view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Select Field  ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Group Name",
            value="Group",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    def test_allow_record_creation_group_teardown(self):
        """
        Perform teardown operations after the test case.

        This method is responsible for cleaning up any resources used by the test case.
        It calls the `sync_condition_teardown_method` to ensure that all sync conditions
        are properly cleaned up.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        # The method is responsible for cleaning up resources related to sync conditions
        # It is called after the test case to ensure proper cleanup
        sync_condition_teardown_group_method()

    def test_allow_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Allow Record Creation : ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.lead(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_select_field_xpath")),
        #                           view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Select Field  ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Last Name",
            value="Last",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Validation Failed"
            )

    def test_allow_record_creation_lead_teardown(self):
        """
        Perform teardown operations after the test case.

        This method is responsible for cleaning up any resources used by the test case.
        It calls the `sync_condition_teardown_method` to ensure that all sync conditions
        are properly cleaned up.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        sync_condition_teardown_lead_method()

    def test_stop_segments(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Stop Record Creation  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_sync.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Segments  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    def test_stop_record_creation_segments_teardown(self):
        """
        Perform teardown operations after the test case.

        This method is responsible for cleaning up any resources used by the test case.
        It calls the `sync_condition_teardown_method` to ensure that all sync conditions
        are properly cleaned up.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        # The method is responsible for cleaning up resources related to sync conditions
        # It is called after the test case to ensure proper cleanup
        sync_condition_stop_teardown_segments_method()

    def test_stop_mailchimp_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Stop Record Creation  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact   : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.mailchimp_contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mailchimp_contact_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
        )
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
            value="Name",
        )
        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Mailchimp Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    def test_stop_record_creation_mailchimp_contacts_teardown(self):
        """
        Perform teardown operations after the test case.

        This method calls the `sync_condition_teardown_method` to clean up any resources
        used by the test case.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        # This method ensures that all sync conditions are properly cleaned up
        sync_condition_stop_teardown_mailchimp_contacts_method()

    def test_stop_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Stop Record Creation  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_contact_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Contact  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_c_select_field_xpath")),
        #                           view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Select Field  ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Last Name",
            value="Last Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Contact  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Contact : Validation Failed"
            )

    def test_stop_record_creation_contact_teardown(self):
        """
        Perform teardown operations after the test case.

        This method calls the `sync_condition_teardown_method` to clean up any resources.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        sync_condition_stop_teardown_contact_method()

    def test_stop_group(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Stop Record Creation  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.groups(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Groups ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_select_field_xpath")),
        #                           view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Select Field  ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Group Name",
            value="Group Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Groups  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    def test_stop_record_creation_group_teardown(self):
        """
        Perform teardown operations after the test case.

        This method is responsible for cleaning up any resources used by the test case.
        It calls the `sync_condition_teardown_method` to ensure that all sync conditions
        are properly cleaned up.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        # The method is responsible for cleaning up resources related to sync conditions
        # It is called after the test case to ensure proper cleanup
        sync_condition_stop_teardown_group_method()

    def test_stop_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Stop Record Creation  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.lead(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_select_field_xpath")),
        #                           view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Select Field  ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_field_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Select Field  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Last Name",
            value="Last Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_operator_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Select Operator  ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_enter_val_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Set Value  ",
            value="Test",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_add_icon_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Add Icon  ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Steps : Edit Configuration : Sync Conditions : Lead  : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead :  Sure Ok Button"
            #                            )
            # except Exception as e:
            #     pass

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Sync Conditions : Lead :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Steps : Edit Configuration : Sync Conditions : Lead : Validation Failed"
            )

    def test_stop_record_creation_lead_teardown(self):
        """
        This test method is used to perform teardown operations after the test case.
        It calls the `sync_condition_teardown_method` to clean up any resources.

        Args:
            self: The instance of the class.

        Returns:
            None
        """
        # Call the teardown method for sync conditions
        # This method is responsible for cleaning up resources related to sync conditions
        # It is called after the test case to ensure proper cleanup
        sync_condition_stop_teardown_lead_method()
