import pytest
from selenium.common import NoSuchElementException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import CF_Edit_Configuration
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Real_Time_Setting import SF_Real_Time_Setting
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_EC_Real_Time_Setting(SalesForceBaseTest):

    def setup_method(self):
        """
        Setup method to verify the page view of Configuration.

        This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
        It waits for the loader to disappear, redirects to the campaign page,
        retrieves the page heading, and verifies if the page is opened successfully.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_config = SF_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        sf_real_time = SF_Real_Time_Setting(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Configuration class.
        This method creates a new instance of the Configuration class and initializes it with the provided driver.
        """
        try:
            sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                    locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                      "loader_xpath")),
                                                    view="Side view : Configuration : Wait for loader to disappear ")
            sf_config.redirect_to_configuration_page(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("configuration locators",
                                                                                         "config_name_xpath")),
                                                     view="Side View : Configuration :")
            page_head = sf_cf_dash.return_page_heading(locator_strategy=By.XPATH,
                                                       locator_value=str(
                                                           ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                           "txt_heading_page_xpath"))
                                                       , view="")
            sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                    locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                      "loader_xpath")),
                                                    view="Side view : Configuration : Wait for loader to disappear ")
            if page_head.text == "Configuration":
                self.logger.info("Configuration Page Opened Successfully!")
                sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("edit config locators",
                                                                                      "btn_edit_config_xpath")),
                                                  view="Side View : Configuration : Edit Configuration")
                sf_real_time.real_time_setting(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("real time setting", "lnk_rts_xpath"))
                                               ,
                                               view="Side View : Configuration : Edit Configuration : Real Time Setting : ")
            else:
                pytest.fail("Configuration Page not Opened Successfully!")
        except NoSuchElementException:
            sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                       locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                         "btn_close_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Close Button")


    def test_real_site_selection(self):
        """
        Test case to edit the configuration setting.
        This test case verifies that the configuration setting is successfully edited real site selection.
        Parameters:
            - None
        Returns:
            - None
        """
        # Initialize CF_Edit_Configuration and CF_Dashboard_View instances
        sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

        # Wait for loader to disappear
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")

        # Open the dropdown for real-time setting
        sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("real time setting", "btn_rt_is_xpath")),
                                 view="Side View : Configuration : Edit Configuration : Real Time Setting : Drop Down")

        # Select the site 'ChimpConnect' from the dropdown
        sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("real time setting", "select_site_xpath"))
                                                ,
                                                view="Side View : Configuration : Edit Configuration : Real Time Setting : Site Selection Drop down",
                                                match_text="ChimpConnect")
        # Getting Error in ChimpConnect Real Time Site Selection Dropdown
        # 1 Permission
        # 2 Validation Error Enable at least one Webhook


        # Close the modal after site selection
        sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                     "btn_close_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Real Time Setting : Close Button")


    def test_webhook_list(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited webhook list.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize CF_Edit_Configuration and CF_Dashboard_View instances
        sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_real_time = SF_Real_Time_Setting(SalesForceBaseTest.driver)

        # Wait for loader to disappear
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")

        sf_real_time.webhook_list(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("real time setting", "btn_whl_xpath")),
                                  view="Side View : Configuration : Edit Configuration : Real Time Setting : Webhook List : ")
        sf_real_time.view_all_webhooks_toggle_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("real time setting", "toggle_whl_xpath")),view="Side View : Configuration : Edit Configuration : Real Time Setting : Webhook List : View All Webhooks Toggle Button")
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Real Time Setting : Wait for loader to disappear ")
        sf_edit_config.save_button(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                     "btn_save_and_close_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Real Time Setting : Save Button")
        # Can't validate on the bases of Validation  because right now validation is not displaying on the UI
        # Close the modal after site selection
        sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                     "btn_close_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Real Time Setting : Close Button")

    def test_real_time_export_setting(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited export setting.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize CF_Edit_Configuration and CF_Dashboard_View instances
        sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        sf_real_time = SF_Real_Time_Setting(SalesForceBaseTest.driver)

        # Wait for loader to disappear
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_real_time.realtime_export_setting(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("real time setting", "btn_rte_s_xpath")), view="Side View : Configuration : Edit Configuration : Real Time Setting : Real Time Export Setting : ")

        # Can't validate on the bases of Validation  because right now validation is not displaying on the UI
        # Close the modal after site selection
        sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                     "btn_close_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Real Time Setting : Close Button")
