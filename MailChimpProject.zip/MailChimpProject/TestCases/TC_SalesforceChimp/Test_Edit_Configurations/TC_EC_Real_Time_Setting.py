from selenium.common import NoSuchElementException, StaleElementReferenceException, TimeoutException, \
    ElementClickInterceptedException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Real_Time_Setting import (
    SF_Real_Time_Setting,
)
from TestCases.Setup_Methods.SF_Setup_Methods.SF_SM_Edit_Configuration.SF_Real_Time_Setting import (
    real_time_setting_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_EC_Real_Time_Setting(SalesForceBaseTest):

    def setup_method(self):
        """
        This method sets up the test case by calling the `real_time_setting_setup_method()`.

        This method is called before each test case is executed.
        """
        # Call the real_time_setting_setup_method() function
        real_time_setting_setup_method()
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        self.sf_real_time = SF_Real_Time_Setting(SalesForceBaseTest.driver)

    def test_real_site_selection(self):
        """
        Test case to edit the configuration setting.
        This test case verifies that the configuration setting is successfully edited real site selection.

        Parameters:
            - None

        Returns:
            - None
        """

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
        )

        # Open the dropdown for real-time setting
        self.sf_edit_config.drop_down(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("real time setting", "btn_rt_is_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Drop Down",
        )

        # Select the site 'ChimpConnect' from the dropdown
        self.sf_edit_config.dropdown_field_selection(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "real time setting", "select_site_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Site Selection Drop down",
            match_text="ChimpConnect",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
        )

        # Getting Error in ChimpConnect Real Time Site Selection Dropdown
        # 1 Provide Permission : Handled and covered

        try:
            self.sf_real_time.site_missing_permission(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "real time setting", "btn_site_permission_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Site Selection Drop down : Permission Missing :",
            )
            # Wait for loader to disappear
            self.sf_cf_dash.wait_for_loader_to_disappear(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                ),
                view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
            )
            self.sf_real_time.provide_permission(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "real time setting", "btn_provide_permission_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Permission Missing : Provide Permission ",
            )

            self.sf_edit_config.save_button(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_save_and_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Save Button",
            )

            # Close the modal after Provide Permission
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting  : Sure Ok Button :",
            )
        except (TimeoutException, StaleElementReferenceException ,NoSuchElementException,ElementClickInterceptedException):
            self.logger.info(
                "Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Site Selection Drop down : Permission Missing : Not Found :"
            )
            # Wait for loader to disappear
            self.sf_cf_dash.wait_for_loader_to_disappear(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                ),
                view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
            )

            # Close the modal after site selection
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Close Button",
            )

            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting  : Sure Ok Button :",
            )
            # 2 Validation Error Enable at least one Webhook , Need to handle this as well

    def test_webhook_list(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited webhook list.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize CF_Edit_Configuration and CF_Dashboard_View instances

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
        )

        self.sf_real_time.webhook_list(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("real time setting", "btn_whl_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Webhook List : ",
        )
        self.sf_real_time.view_all_webhooks_toggle_btn(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("real time setting", "toggle_whl_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Webhook List : View All Webhooks Toggle Button",
        )
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Wait for loader to disappear ",
        )
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Save Button",
        )
        # Can't validate on the bases of Validation  because right now validation is not displaying on the UI
        # Close the modal after site selection
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Close Button",
        )

    def test_real_time_export_setting(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited export setting.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize CF_Edit_Configuration and CF_Dashboard_View instances

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Wait for loader to disappear ",
        )
        self.sf_real_time.realtime_export_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("real time setting", "btn_rte_s_xpath")
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Real Time Export Setting : ",
        )

        # Can't validate on the bases of Validation  because right now validation is not displaying on the UI
        # Close the modal after site selection
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Case : Step : Side View : Configuration : Edit Configuration : Real Time Setting : Close Button",
        )

    # tear-down state is not needed for the setup of a specific page.
