import random

import pytest
from selenium.common import StaleElementReferenceException, NoSuchElementException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Groups import SF_Groups
from Pages.SalesforceChimp.SF_DashBoard.SF_MailchimpContacts import SF_MailChimpContacts
from Pages.SalesforceChimp.SF_DashBoard.SF_Segments import SF_Segments
from Pages.SalesforceChimp.SF_DashBoard.SF_Tags import SF_Tags
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Record_Type_Mapping import (
    SF_Record_Type_Mapping,
)
from TestCases.Setup_Methods.SF_Setup_Methods.SF_Configuration_Setup_Methods.SF_Record_Type_Mapping import (
    record_type_mapping_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_EC_Record_Type_Mapping(SalesForceBaseTest):
    # SETUP METHODS
    def setup_method(self):
        """
        This method sets up the test case by calling the `record_type_mapping_setup_method()`.
        This method is called before each test case is executed.
        """
        # Call the record_type_mapping_setup_method() function
        record_type_mapping_setup_method()
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_record_type = SF_Record_Type_Mapping(SalesForceBaseTest.driver)
        self.sf_segment = SF_Segments(SalesForceBaseTest.driver)
        self.sf_tag = SF_Tags(SalesForceBaseTest.driver)
        self.sf_group = SF_Groups(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        self.sf_mail_chimp_contact = SF_MailChimpContacts(SalesForceBaseTest.driver)

     
    # TODO: Currently Not in Use , Need to check Record Type Field in MailChimp Details Page
    def test_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["contact", "test_contact"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)

        # Select the Contact record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_contact_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Close Button",
            )

        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

     
    # TODO: Currently Not in Use , Need to check Record Type Field in MailChimp Details Page
    def test_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["Lead", "test_lead"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_lead_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Lead Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Close Button",
            )

        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

     
    def test_campaign_mailchimp(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["CampaignMailchimp", "test_campaign_mailchimp"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)
        # Select the  record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_camp_mail_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Close Button",
            )
            # Validation Section
            try:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Wait for loader to disappear ",
                )
                # Redirect to segment page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("mailchimp contact locators", "mailchimp_contact_name_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Mass Import :",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : {list_text}"
                    )
                    # self.sf_mail_chimp_contact.select_name_label(locator_strategy=By.XPATH, locator_value=str(
                    #     ConfigReader.locatorsReadConfig(
                    #         "record type mapping", "txt_name_label_xpath"
                    #     )),view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Name Label")
                    # # Get the text from the List
                    # record_type = self.sf_edit_config.get_text(
                    #     locator_strategy=By.XPATH,
                    #     locator_value=str(
                    #         ConfigReader.locatorsReadConfig(
                    #             "record type mapping", "txt_camp_record_type_xpath"
                    #         )
                    #     ),
                    #     view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Text",
                    # )
                    # if record_type == "test" or record_type == "Test":
                    #     self.logger.info(
                    #         f"Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : {record_type}"
                    #     )
                else:
                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except (StaleElementReferenceException, NoSuchElementException):
                pytest.fail(
                    "create Edit Configuration Failed"
                )

        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

     
    def test_subscriber(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["Subscribers", "test"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)
        # Select the  record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_subscriber_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Close Button",
            )
            # Validation Section
            try:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Wait for loader to disappear ",
                )
                # Redirect to segment page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("mailchimp contact locators", "mailchimp_contact_name_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Mass Import :",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : {list_text}"
                    )
                    self.sf_mail_chimp_contact.select_name_label(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )),view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Name Label")
                    # Get the text from the List
                    record_type = self.sf_edit_config.get_text(
                        locator_strategy=By.XPATH,
                        locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "txt_subs_record_type_xpath"
                            )
                        ),
                        view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Text",
                    )
                    if record_type == "test" or record_type == "Subscribers":
                        self.logger.info(
                            f"Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Record Type : {record_type}"
                        )
                        self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "btn_redirect_chimp_xpath"
                            )),
                                                                      view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    else:
                        self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "btn_redirect_chimp_xpath"
                            )),
                                                                      view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                        pytest.fail(
                           "Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Failed"
                        )

                else:
                    self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "btn_redirect_chimp_xpath"
                        )),view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except (StaleElementReferenceException, NoSuchElementException):
                pytest.fail(
                    "create Edit Configuration Failed"
                )

        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

     
    def test_Segment(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["Segment", "test_segment"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)
        # Select the  record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_segment_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Close Button",
            )
            # Validation Section
            try:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Wait for loader to disappear ",
                )
                # Redirect to segment page
                self.sf_segment.redirect_to_segment_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("segment locators", "segment_name_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Mass Import :",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Text",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment :  Wait for loader to disappear ",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : {list_text}"
                    )
                    self.sf_mail_chimp_contact.select_name_label(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )),
                                                                 view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Name Label")
                    # Get the text from the List
                    record_type = self.sf_edit_config.get_text(
                        locator_strategy=By.XPATH,
                        locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "txt_seg_record_type_xpath"
                            )
                        ),
                        view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Text",
                    )
                    if record_type == "test segment" or record_type == "Segment":
                        self.logger.info(
                            f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Record Type : {record_type}"
                        )
                        self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "btn_redirect_chimp_xpath"
                            )),
                                                                      view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    else:
                        self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "btn_redirect_chimp_xpath"
                            )),
                                                                      view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                        pytest.fail(
                            "Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Failed"
                        )
                else:
                    self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "btn_redirect_chimp_xpath"
                        )),
                                                                  view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except (StaleElementReferenceException, NoSuchElementException):
                self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "record type mapping", "btn_redirect_chimp_xpath"
                    )),
                                                              view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")
                pytest.fail(
                    "create Edit Configuration Failed"
                )

        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

     
    def test_Tag(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["Tags", "test_tag"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)
        # Select the Tag record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_tag_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Close Button",
            )
            # Validation Section
            try:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Tags : Wait for loader to disappear ",
                )

                # Redirect to tag page
                self.sf_tag.redirect_to_tag_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("tag locators", "tag_name_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Tags :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Tags : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Mass Import :",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Text",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags :  Wait for loader to disappear ",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : {list_text}"
                    )
                    # TODO: Get the text from the Record Type (Locators change dynamically)
                    # self.sf_mail_chimp_contact.select_name_label(locator_strategy=By.XPATH, locator_value=str(
                    #     ConfigReader.locatorsReadConfig(
                    #         "record type mapping", "txt_name_label_xpath"
                    #     )),
                    #                                              view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Name Label")
                    # # Get the text from the List
                    # record_type = self.sf_edit_config.get_text(
                    #     locator_strategy=By.XPATH,
                    #     locator_value=str(
                    #         ConfigReader.locatorsReadConfig(
                    #             "record type mapping", "txt_tag_record_type_xpath"
                    #         )
                    #     ),
                    #     view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Text",
                    # )
                    # if record_type == "test tag" or record_type == "Tags":
                    #     self.logger.info(
                    #         f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Record Type : {record_type}"
                    #     )
                    #     self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                    #         ConfigReader.locatorsReadConfig(
                    #             "record type mapping", "btn_redirect_chimp_xpath"
                    #         )),
                    #                                                   view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")
                    #
                    # else:
                    #     self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                    #         ConfigReader.locatorsReadConfig(
                    #             "record type mapping", "btn_redirect_chimp_xpath"
                    #         )),
                    #                                                   view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")
                    #
                    #     pytest.fail(
                    #         "Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Failed"
                    #     )
                else:
                    self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "btn_redirect_chimp_xpath"
                        )),
                                                                  view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except (StaleElementReferenceException, NoSuchElementException):
                pytest.fail(
                    "create Edit Configuration Failed"
                )
        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

     
    def test_groups(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Define valid match texts for the  record type
        valid_match_texts = ["Group", "test_group"]
        # Select a random match text from the valid match texts
        random_match_text = random.choice(valid_match_texts)
        # Select theGroups record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_group_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text=random_match_text,
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Close Button",
            )
            # Validation Section
            try:
                # Wait for the loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Groups : Wait for loader to disappear ",
                )

                # Redirect to the Groups page
                self.sf_group.redirect_to_groups_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("group locators", "group_name_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups :",
                )
                # Wait for the loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Mass Import :",
                )
                # self.sf_cf_dash.wait_for_loader_to_disappear(
                #     locator_strategy=By.XPATH,
                #     locator_value=str(
                #         ConfigReader.locatorsReadConfig(
                #             "loader_locators", "loader_xpath"
                #         )
                #     ),
                #     view="Test Case : Step : Side View : Mailchimp Contacts :  Wait for loader to disappear ",
                # )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Text",
                )
                # Wait for the loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Groups : Wait for loader to disappear ",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : {list_text}"
                    )
                    # TODO: Get the text from the Record Type (Locators change dynamically) : DONE
                    self.sf_mail_chimp_contact.select_name_label(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )),
                                                                 view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Name Label")
                    # Get the text from the List
                    record_type = self.sf_edit_config.get_text(
                        locator_strategy=By.XPATH,
                        locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "txt_group_record_type_xpath"
                            )
                        ),
                        view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Text",
                    )
                    if record_type == "group" or record_type == "test group":
                        self.logger.info(
                            f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Record Type :{record_type}"
                        )
                        self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "btn_redirect_chimp_xpath"
                            )),
                                                                      view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    else:
                        self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                            ConfigReader.locatorsReadConfig(
                                "record type mapping", "btn_redirect_chimp_xpath"
                            )),
                                                                      view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                        pytest.fail(
                            "Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Failed"
                        )
                else:
                    self.sf_edit_config.redirect_to_chimp_connect(locator_strategy=By.XPATH, locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "btn_redirect_chimp_xpath"
                        )),
                                                                  view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Chimp Connect")

                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except (StaleElementReferenceException, NoSuchElementException):
                pytest.fail(
                    "create Edit Configuration Failed"
                )
        except (StaleElementReferenceException, NoSuchElementException):
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

print(Test_EC_Record_Type_Mapping.__doc__)