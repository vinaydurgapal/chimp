from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import CF_Edit_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Record_Type_Mapping import SF_Record_Type_Mapping
from TestCases.Setup_Methods.SF_Setup_Methods.SF_SM_Edit_Configuration.SF_Record_Type_Mapping import record_type_mapping_setup_method
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_EC_Record_Type_Mapping(SalesForceBaseTest):

    def setup_method(self):
        """
        This method sets up the test case by calling the `record_type_mapping_setup_method()`.
        This method is called before each test case is executed.
        """
        # Call the record_type_mapping_setup_method() function
        record_type_mapping_setup_method()
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_record_type=SF_Record_Type_Mapping(SalesForceBaseTest.driver)
    def test_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """

        self.sf_record_type.record_type_drop_down(locator_strategy=By.XPATH,
                                                  locator_value=str(ConfigReader.locatorsReadConfig("record type mapping","btn_contact_xpath")),
                                                  view="Setup Method : Side view  : Configuration : Edit Configuration : Record Type Mapping : Contact : Record Type Drop Down")
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                     "btn_close_xpath")),
                                   view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")


    def test_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Currently not in Use
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_close_xpath")),
                                        view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")

    def test_campaign_mailchimp(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_record_type.record_type_drop_down(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("record type mapping",
                                                                                      "btn_camp_mail_xpath")),
                                                  view="Setup Method : Side view  : Configuration : Edit Configuration : Record Type Mapping : Campaign:Mailchimp : Record Type Drop Down")
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_close_xpath")),
                                        view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")


    def test_subscriber(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_record_type.record_type_drop_down(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("record type mapping",
                                                                                      "btn_subscriber_xpath")),
                                                  view="Setup Method : Side view  : Configuration : Edit Configuration : Record Type Mapping : Subscriber : Record Type Drop Down")
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_close_xpath")),
                                        view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")


    def test_Segment(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_record_type.record_type_drop_down(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("record type mapping",
                                                                                      "btn_segment_xpath")),
                                                  view="Setup Method : Side view  : Configuration : Edit Configuration : Record Type Mapping : Segment : Record Type Drop Down")
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_close_xpath")),
                                        view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")


    def test_Tag(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_record_type.record_type_drop_down(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("record type mapping",
                                                                                      "btn_tag_xpath")),
                                                  view="Setup Method : Side view  : Configuration : Edit Configuration : Record Type Mapping : Tag : Record Type Drop Down")
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_close_xpath")),
                                        view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")

    def test_groups(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_record_type.record_type_drop_down(locator_strategy=By.XPATH,
                                                  locator_value=str(
                                                      ConfigReader.locatorsReadConfig("record type mapping",
                                                                                      "btn_group_xpath")),
                                                  view="Setup Method : Side view  : Configuration : Edit Configuration : Record Type Mapping : Groups : Record Type Drop Down")
        self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_close_xpath")),
                                        view="Setup Method : Side view  : Configuration : Edit Configuration : Log Setting : Close Button")
