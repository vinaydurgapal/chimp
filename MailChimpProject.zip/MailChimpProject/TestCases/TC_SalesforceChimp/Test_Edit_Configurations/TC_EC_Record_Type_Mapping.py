import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Groups import SF_Groups
from Pages.SalesforceChimp.SF_DashBoard.SF_Segments import SF_Segments
from Pages.SalesforceChimp.SF_DashBoard.SF_Tags import SF_Tags
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Record_Type_Mapping import (
    SF_Record_Type_Mapping,
)
from TestCases.Setup_Methods.SF_Setup_Methods.SF_SM_Edit_Configuration.SF_Record_Type_Mapping import (
    record_type_mapping_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader




class Test_EC_Record_Type_Mapping(SalesForceBaseTest):

    def setup_method(self):
        """
        This method sets up the test case by calling the `record_type_mapping_setup_method()`.
        This method is called before each test case is executed.
        """
        # Call the record_type_mapping_setup_method() function
        record_type_mapping_setup_method()
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_record_type = SF_Record_Type_Mapping(SalesForceBaseTest.driver)
        self.sf_segment = SF_Segments(SalesForceBaseTest.driver)
        self.sf_tag = SF_Tags(SalesForceBaseTest.driver)
        self.sf_group = SF_Groups(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    def test_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """

        # Select the Contact record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_contact_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text="contact",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Close Button",
            )

        except Exception as e:
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Contact : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

    # TODO: Currently not in Use
    def test_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Currently not in Use
        self.sf_edit_config.close_modal(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_close_xpath"
                )
            ),
            view="Test Cases  : Steps  : Side view  : Configuration : Edit Configuration : Log Setting : Close Button",
        )

    def test_campaign_mailchimp(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Select the  record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_camp_mail_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text="CampaignMailchimp",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Close Button",
            )

        except Exception as e:
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : CampaignMailchimp : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

    def test_subscriber(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """

        # Select the  record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_subscriber_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text="Subscribers",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Close Button",
            )

        except Exception as e:
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Subscriber : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

    def test_Segment(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Select the  record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_segment_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text="Segment",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Close Button",
            )
            # Validation Section
            try:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Wait for loader to disappear ",
                )
                # Redirect to segment page
                self.sf_segment.redirect_to_segment_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("segment locators", "segment_name_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Mass Import : ",
                )
                # self.sf_cf_dash.wait_for_loader_to_disappear(
                #     locator_strategy=By.XPATH,
                #     locator_value=str(
                #         ConfigReader.locatorsReadConfig(
                #             "loader_locators", "loader_xpath"
                #         )
                #     ),
                #     view="Test Case : Step : Side View : Mailchimp Contacts :  Wait for loader to disappear ",
                # )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : {list_text}"
                    )
                else:
                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except Exception as e:
                pytest.fail(
                    "create Edit Configuration Failed"
                )

        except Exception as e:
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Segment : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

    def test_Tag(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Select the Tag record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_tag_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text="Tags",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Close Button",
            )
            # Validation Section
            try:
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Tags : Wait for loader to disappear ",
                )

                # Redirect to tag page
                self.sf_tag.redirect_to_tag_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("tag locators", "tag_name_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Tags :",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Tags : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Mass Import : ",
                )
                # self.sf_cf_dash.wait_for_loader_to_disappear(
                #     locator_strategy=By.XPATH,
                #     locator_value=str(
                #         ConfigReader.locatorsReadConfig(
                #             "loader_locators", "loader_xpath"
                #         )
                #     ),
                #     view="Test Case : Step : Side View : Mailchimp Contacts :  Wait for loader to disappear ",
                # )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Tags : {list_text}"
                    )
                else:
                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except Exception as e:
                pytest.fail(
                    "create Edit Configuration Failed"
                )
        except Exception as e:
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Tag : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )

    def test_groups(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Select theGroups record type drop-down
        self.sf_record_type.record_type_drop_downs(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "record type mapping", "btn_group_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Drop Down",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("record type mapping", "lst_dropdown_xpath")
            ),
            lst_view="Contact Record types",
            match_text="Group",
        )

        # Save the configuration
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Save Button",
        )

        # Get the validation message
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Validation Message",
        )

        try:
            # Assert that the validation message is "Success"
            assert validation_txt.text == "Success"

            # Close the modal
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Close Button",
            )
            # Validation Section
            try:
                # Wait for the loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps  : Side View : Groups : Wait for loader to disappear ",
                )

                # Redirect to the Groups page
                self.sf_group.redirect_to_groups_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("group locators", "group_name_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups :",
                )
                # Wait for the loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "lst_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Checkboxes",
                )
                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups :  Wait for loader to disappear ",
                )
                # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Mass Import : ",
                )
                # self.sf_cf_dash.wait_for_loader_to_disappear(
                #     locator_strategy=By.XPATH,
                #     locator_value=str(
                #         ConfigReader.locatorsReadConfig(
                #             "loader_locators", "loader_xpath"
                #         )
                #     ),
                #     view="Test Case : Step : Side View : Mailchimp Contacts :  Wait for loader to disappear ",
                # )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "progress_bar_xpath"
                        )
                    ),
                )
                # Get the text from the List
                list_text = self.sf_edit_config.get_text(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "record type mapping", "txt_name_label_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Text",
                )
                if list_text:
                    self.logger.info(
                        f"Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : {list_text}"
                    )
                else:
                    pytest.fail(
                        "create Edit Configuration Failed"
                    )

            except Exception as e:
                pytest.fail(
                    "create Edit Configuration Failed"
                )
        except Exception as e:
            # Close the modal and cancel the operation
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Steps : Edit Configuration : Record Type Mapping : Groups : Sure Ok Button",
            )
            pytest.fail(
                "Failed to create the configuration"
            )
