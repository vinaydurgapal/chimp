import pytest
from selenium.common import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import CF_Edit_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Merge_Field_Mapping import SF_Merge_Field_Mapping
from TestCases.Setup_Methods.SF_Setup_Methods.SF_Merge_Field_Mapping import merge_field_mapping_setup_method
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from TestCases.Teardown_Methods.SF_Teardown_Methods.SF_MF_Teardown_Methods import lead_mapping_teardown, \
    contact_mapping_teardown, dynamic_mapping_teardown
from Utilities import ConfigReader


class Test_EC_Merge_Field_Mapping(SalesForceBaseTest):

    def setup_method(self):
        """
        This method sets up the test case by calling the `merge_field_mapping_setup_method()`.

        This method is called before each test case is executed.
        """
        # Call the merge_field_mapping_setup_method() function
        merge_field_mapping_setup_method()
        self.sf_merge_mapping = SF_Merge_Field_Mapping(SalesForceBaseTest.driver)
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    # @pytest.mark.skip
    def test_lead_mapping_import_export_update_on(self):
        """
        Test case to edit the configuration setting for lead mapping.
        This test case verifies that the configuration setting for lead mapping is successfully edited.
        Parameters:
            - None
        Returns:
            - None
        """
        # Initialize necessary objects

        # Edit configuration settings for lead mapping
        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        # Perform merge field mapping
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side view : Configuration : Wait for loader to disappear ")
        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        # self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
        #                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")
            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Import Button ",
                                         conditions_dict={"Import": "True"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Export Button ",
                                         conditions_dict={"Export": "True"},
                                         toggle_field_data="Export")
        # Enable Update Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_update_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Update Button ",
                                         conditions_dict={"Update": "True"},
                                         toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Add Icon : ")
        # Wait for loader to disappear after lead mapping changes
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Wait for loader to disappear ")

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_save_and_close_xpath")),
                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Save Button")

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message")
        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )

        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
            pytest.fail("Merge Field Mapping : Lead Mapping failed", )

    # @pytest.mark.skip
    def test_lead_mapping_import_on(self):
        """
        Test case to edit the configuration setting for lead mapping.

        This test case verifies that the configuration setting for lead mapping is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize necessary objects
        # Edit configuration settings for lead mapping
        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        # Perform merge field mapping
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")

        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        # self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
        #                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")
            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Import Button ",
                                         conditions_dict={"Import": "True"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Export Button ",
                                         conditions_dict={"Export": "False"},
                                         toggle_field_data="Export")
        # Enable Update Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_update_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Update Button ",
                                         conditions_dict={"Update": "False"},
                                         toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Add Icon : ")
        # Wait for loader to disappear after lead mapping changes
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Wait for loader to disappear ")

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_save_and_close_xpath")),
                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Save Button")

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message")
        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
            pytest.fail("Merge Field Mapping : Lead Mapping failed", )

    # @pytest.mark.skip
    def test_lead_mapping_update_on(self):
        """
        Test case to edit the configuration setting for lead mapping.

        This test case verifies that the configuration setting for lead mapping is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize necessary objects

        # Edit configuration settings for lead mapping
        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        # Perform merge field mapping
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")

        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        # self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
        #                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")
            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Import Button ",
                                         conditions_dict={"Import": "False"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Export Button ",
                                         conditions_dict={"Export": "False"},
                                         toggle_field_data="Export")
        # Enable Update Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_update_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Update Button ",
                                         conditions_dict={"Update": "True"},
                                         toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Add Icon : ")
        # Wait for loader to disappear after lead mapping changes
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Wait for loader to disappear ")

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_save_and_close_xpath")),
                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Save Button")

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message")
        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
            pytest.fail("Merge Field Mapping : Lead Mapping failed", )

    # @pytest.mark.skip
    def test_lead_mapping_export_on(self):
        """
        Test case to edit the configuration setting for lead mapping.

        This test case verifies that the configuration setting for lead mapping is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize necessary objects

        # Edit configuration settings for lead mapping
        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        # Perform merge field mapping
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")

        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        # self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
        #                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")
            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Import Button ",
                                         conditions_dict={"Import": "True"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Export Button ",
                                         conditions_dict={"Export": "False"},
                                         toggle_field_data="Export")
        # Enable Update Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_update_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Update Button ",
                                         conditions_dict={"Update": "False"},
                                         toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Add Icon ")
        # Wait for loader to disappear after lead mapping changes
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Wait for loader to disappear ")

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_save_and_close_xpath")),
                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Save Button")

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message")
        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
            pytest.fail("Merge Field Mapping : Lead Mapping failed", )

    # @pytest.mark.skip
    def test_lead_mapping_import_export_update_off(self):
        """
        Test case to edit the configuration setting for lead mapping.

        This test case verifies that the configuration setting for lead mapping is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        # Initialize necessary objects

        # Edit configuration settings for lead mapping
        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        # Perform merge field mapping
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping ")

        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        # self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
        #                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Refresh Page Icon ")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")

        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")
            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One :")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down :",
                                                         match_text="Address")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_lsso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Address")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Import Button  ",
                                         conditions_dict={"Import": "False"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Export Button  ",
                                         conditions_dict={"Export": "False"},
                                         toggle_field_data="Export")
        # Enable Update Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_update_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Update Button  ",
                                         conditions_dict={"Update": "False"},
                                         toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Add Icon  ")
        # Wait for loader to disappear after lead mapping changes
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Wait for loader to disappear ")

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_save_and_close_xpath")),
                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Save Button")

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message")
        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
        except Exception as e:
            # Handle validation failure
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping :  Sure Ok Button"
                                   )
            pytest.fail("Merge Field Mapping : Lead Mapping failed", )

    # @pytest.mark.skip
    def test_lead_mapping_teardown(self):
        """
        This test case performs teardown actions after testing the lead mapping feature.
        It handles closing modals, deleting buttons, and checking validation messages.
        """
        # Call the lead_mapping_teardown function to perform the teardown actions
        lead_mapping_teardown()

    def test_contact_mapping_import_and_export(self):
        """
        Test case to edit the configuration setting.
        Test case to edit the configuration setting for contact mapping.
        This test case verifies that the configuration setting is successfully edited.
        Parameters:
            - None
        Returns:
            - None
        """

        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side view : Configuration : Wait for loader to disappear ")
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Import Button ",
                                         conditions_dict={"Import": "True"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Export Button ",
                                         conditions_dict={"Export": "True"},
                                         toggle_field_data="Export")
        # Right now Update toggle button is not working , So commenting the code
        # Enable Update Toggle Field
        # self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
        #                             locator_value=str(ConfigReader.locatorsReadConfig(
        #                                 "merge field mapping",
        #                                 "btn_lm_update_toggle_xpath")),
        #                             view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Update Button ",
        #                             conditions_dict={"Update": "True"},
        #                             toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Add Icon : ")
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                         locator_value=str(
                                                             ConfigReader.locatorsReadConfig("loader_locators",
                                                                                             "loader_xpath")),
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Wait for loader to disappear ")
            self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_save_and_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Save Button")
            validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                        locator_value=str(
                                                                            ConfigReader.locatorsReadConfig(
                                                                                "edit config locators",
                                                                                "txt_validation_xpath")),
                                                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

            self.logger.info(
                f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
            try:
                assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                    f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
            except Exception as e:
                # Close the modal after creating the lead of MailChimp subscriber
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
                pytest.fail("Merge Field Mapping : Contact Mapping failed", )
        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                   )
            self.logger.info(
                "Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Contact Mapping Field Already Exists",
            )

    # #@pytest.mark.skip(" Not yet implemented")
    def test_contact_mapping_import_on(self):
        """
        Test case to edit the configuration setting.
        Test case to edit the configuration setting for contact mapping.
        This test case verifies that the configuration setting is successfully edited.
        Parameters:
            - None
        Returns:
            - None
        """

        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side view : Configuration : Wait for loader to disappear ")
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Import Button ",
                                         conditions_dict={"Import": "True"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Export Button ",
                                         conditions_dict={"Export": "False"},
                                         toggle_field_data="Export")
        # Right now Update toggle button is not working , So commenting the code
        # Enable Update Toggle Field
        # self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
        #                             locator_value=str(ConfigReader.locatorsReadConfig(
        #                                 "merge field mapping",
        #                                 "btn_lm_update_toggle_xpath")),
        #                             view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Update Button ",
        #                             conditions_dict={"Update": "True"},
        #                             toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Add Icon : ")
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text == "Error"
            self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                         locator_value=str(
                                                             ConfigReader.locatorsReadConfig("loader_locators",
                                                                                             "loader_xpath")),
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Wait for loader to disappear ")
            self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_save_and_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Save Button")
            validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                        locator_value=str(
                                                                            ConfigReader.locatorsReadConfig(
                                                                                "edit config locators",
                                                                                "txt_validation_xpath")),
                                                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

            self.logger.info(
                f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
            try:
                assert validation_txt.text == "Error"
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
            except Exception as e:
                # Close the modal after creating the lead of MailChimp subscriber
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
                self.logger.info(
                    "Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Contact Mapping Field Already Exists",
                )
        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                   )
            pytest.fail("Merge Field Mapping : Contact Mapping failed", )

    # #@pytest.mark.skip(" Not yet implemented")
    def test_contact_mapping_import_export_on(self):
        """
        Test case to edit the configuration setting.
        Test case to edit the configuration setting for contact mapping.
        This test case verifies that the configuration setting is successfully edited.
        Parameters:
            - None
        Returns:
            - None
        """

        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side view : Configuration : Wait for loader to disappear ")
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Import Button ",
                                         conditions_dict={"Import": "False"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Export Button ",
                                         conditions_dict={"Export": "True"},
                                         toggle_field_data="Export")
        # Right now Update toggle button is not working , So commenting the code
        # Enable Update Toggle Field
        # self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
        #                             locator_value=str(ConfigReader.locatorsReadConfig(
        #                                 "merge field mapping",
        #                                 "btn_lm_update_toggle_xpath")),
        #                             view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Update Button ",
        #                             conditions_dict={"Update": "True"},
        #                             toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Add Icon : ")
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                         locator_value=str(
                                                             ConfigReader.locatorsReadConfig("loader_locators",
                                                                                             "loader_xpath")),
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Wait for loader to disappear ")
            self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_save_and_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Save Button")
            validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                        locator_value=str(
                                                                            ConfigReader.locatorsReadConfig(
                                                                                "edit config locators",
                                                                                "txt_validation_xpath")),
                                                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

            self.logger.info(
                f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
            try:
                assert validation_txt.text == "Error"
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
            except Exception as e:
                # Close the modal after creating the lead of MailChimp subscriber
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
                pytest.fail("Merge Field Mapping : Contact Mapping failed", )
        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                   )
            self.logger.info(
                "Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Contact Mapping Field Already Exists",
            )

    # #@pytest.mark.skip(" Not yet implemented")
    def test_contact_mapping_import_and_export_off(self):
        """
        Test case to edit the configuration setting.
        Test case to edit the configuration setting for contact mapping.
        This test case verifies that the configuration setting is successfully edited.
        Parameters:
            - None
        Returns:
            - None
        """

        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side view : Configuration : Wait for loader to disappear ")
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        # Select lead mapping drop down uncomment if required right now drop down is already opened no need to open it again
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_lm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Drop Down")
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Drop Down")
        self.sf_edit_config.refresh_page_icon(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_refresh_xpath")),
                                              view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Refresh Page Icon :")
        self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                               view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button")
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Wait for loader to disappear ")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmsc_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthday")
        try:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        except StaleElementReferenceException:
            self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "inpt_cmmso_xpath")),
                                          view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Salesforce Select One : ")

            self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                         ,
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Lead Mapping : Mailchimp Select One Drop down ",
                                                         match_text="Birthdate")
        # Enable Import Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_import_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Import Button ",
                                         conditions_dict={"Import": "False"},
                                         toggle_field_data="Import")
        # Enable Export Toggle Field
        self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig(
                                             "merge field mapping",
                                             "btn_lm_export_toggle_xpath")),
                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Export Button ",
                                         conditions_dict={"Export": "False"},
                                         toggle_field_data="Export")
        # Right now Update toggle button is not working , So commenting the code
        # Enable Update Toggle Field
        # self.sf_edit_config.toggle_field(locator_strategy=By.XPATH,
        #                             locator_value=str(ConfigReader.locatorsReadConfig(
        #                                 "merge field mapping",
        #                                 "btn_lm_update_toggle_xpath")),
        #                             view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Update Button ",
        #                             conditions_dict={"Update": "True"},
        #                             toggle_field_data="Update")
        # Add a new merge field
        self.sf_edit_config.add_icon(locator_strategy=By.XPATH,
                                     locator_value=str(
                                         ConfigReader.locatorsReadConfig("merge field mapping", "btn_cm_add_xpath")),
                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Add Icon : ")
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

        self.logger.info(
            f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                         locator_value=str(
                                                             ConfigReader.locatorsReadConfig("loader_locators",
                                                                                             "loader_xpath")),
                                                         view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Wait for loader to disappear ")
            self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_save_and_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Save Button")
            validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                        locator_value=str(
                                                                            ConfigReader.locatorsReadConfig(
                                                                                "edit config locators",
                                                                                "txt_validation_xpath")),
                                                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message")

            self.logger.info(
                f"Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Validation Message : {validation_txt.text}")
            try:
                assert validation_txt.text == "Error"
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
            except Exception as e:
                # Close the modal after creating the lead of MailChimp subscriber
                self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                                locator_value=str(
                                                    ConfigReader.locatorsReadConfig("edit config locators",
                                                                                    "btn_close_xpath")),
                                                view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
                self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                       view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                       )
                pytest.fail("Merge Field Mapping : Contact Mapping failed", )
        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping :  Sure Ok Button"
                                   )
            self.logger.info(
                "Side View : Configuration : Edit Configuration : Merge Field Mapping : Contact Mapping : Contact Mapping Field Already Exists",
            )

    def test_contact_mapping_teardown(self):
        """
        This test case performs teardown actions after testing the lead mapping feature.
        It handles closing modals, deleting buttons, and checking validation messages.
        """
        # Call the contact_mapping_teardown function to perform the teardown actions
        contact_mapping_teardown()

    # @pytest.mark.skip
    def test_dynamic_mapping(self):
        """
         Test case to edit the configuration setting.
         Test case to edit the configuration setting for dynamic mapping.
         This test case verifies that the configuration setting is successfully edited.
         Parameters:
             - None
         Returns:
             - None
         """
        self.sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                               locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                                 "btn_edit_config_xpath")),
                                               view="Side View : Configuration : Edit Configuration")
        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side view : Configuration : Wait for loader to disappear ")
        self.sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                                  view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_dm_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Dynamic Mapping : Drop Down")
        self.sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_dm_select_object_xpath")),
                                      view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Dynamic Mapping : Mailchimp Select Object :")

        self.sf_edit_config.dropdown_field_selection(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lst_dropdown_xpath"))
                                                     ,
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Dynamic Mapping : Mailchimp Select Object Drop down :",
                                                     match_text="Account")
        self.sf_merge_mapping.create_required_field(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_create_required_xpath")),
                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Dynamic Mapping : Create Required Field :")

        self.sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("loader_locators",
                                                                                         "loader_xpath")),
                                                     view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Wait for loader to disappear ")
        self.sf_edit_config.save_button(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                          "btn_save_and_close_xpath")),
                                        view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Save Button")
        validation_txt = self.sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                    locator_value=str(ConfigReader.locatorsReadConfig(
                                                                        "edit config locators",
                                                                        "txt_validation_xpath")),
                                                                    view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Validation Message")
        try:
            assert validation_txt.text.startswith("Success") or validation_txt.text.startswith("Error"), (
                f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'")
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Close Button")

            # tear down Method
            self.logger.info("Tear Down Method called For Dynamic Mapping")
            dynamic_mapping_teardown()


        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                              "btn_close_xpath")),
                                            view="Side View : Configuration : Edit Configuration : Merge Field Mapping : Close Button")
            self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                   view="Side View : Configuration : Edit Configuration : Merge Field Mapping :  Sure Ok Button"
                                   )
            pytest.fail("create a lead of MailChimp subscriber. not created successfully!")
