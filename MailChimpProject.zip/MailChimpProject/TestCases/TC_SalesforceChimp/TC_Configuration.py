from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Configuration import SF_Configuration
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Configuration(SalesForceBaseTest):

    def test_configuration_page(self):
        """Verifying the Page View Of Configuration
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_config = SF_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Configuration class.
        This method creates a new instance of the Configuration class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_config.redirect_to_configuration_page(locator_strategy=By.XPATH,
                                                 locator_value=str(
                                                     ConfigReader.locatorsReadConfig("configuration locators",
                                                                                     "config_name_xpath")),
                                                 view="Side View : Configuration :")
        self.logger.info("Configuration Page Opened Successfully!")

    def test_refresh_configuration_page(self):
        """Verifying the Refresh Button Of Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Configuration : Refresh : ")
        self.logger.info("Configuration Page Refreshed Successfully!")



