import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from TestCases.Setup_Methods.SF_Setup_Methods.SF_SM_Dashboards.SF_Configuration import (
    configuration_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Configuration(SalesForceBaseTest):
    # SETUP METHODS
    def setup_method(self):
        """
        Set up method to initialize configuration setup and CF Dashboard View.

        This method calls the configuration_setup_method to set up the configuration.
        Then it initializes the CF Dashboard View with the provided driver.
        """
        configuration_setup_method()
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    def test_refresh_configuration_page(self):
        """Verifying the Refresh Button Of Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Steps : Side View : Configuration : Wait for loader to disappear ",
        )
        self.sf_cf_dash.page_refresh(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_refresh_xpath"
                )
            ),
            view="Test Cases : Steps : Side View : Configuration : Refresh : ",
        )
        self.logger.info("Configuration Page Refreshed Successfully!")

    def test_search_bar(self):
        """Verifying the Configuration Search Bar
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Configuration class and initializes it with the provided driver.
        """
        elem = self.sf_cf_dash.search_bar(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "inpt_search_xpath"
                )
            ),
            view="Test Cases : Steps : Side View : Configuration : Search :",
            send_text=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "configuration_search"
            ),
            locator_strategy2=By.XPATH,
            locator_value2=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "list_td_element_xpath"
                )
            ),
            view2="Test Cases : Steps : Side View : Configuration : Search :",
            locator_strategy3=By.XPATH,
            locator_value3=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view3="Test Cases : Steps : Side View : Campaigns : Wait for loader to disappear ",
        )
        search_successful = False
        for element in elem:
            if (
                ConfigReader.dataReadConfig(
                    "mailchimp dashboard locators", "configuration_search"
                )
                in element.text
            ):
                self.logger.info("Configuration Search Successful! " + element.text)
                search_successful = True
                break
            else:
                self.logger.error("Configuration Search Failed!")
        if not search_successful:
            pytest.fail("Configuration Search Failed!")

print(Test_Configuration.__doc__)