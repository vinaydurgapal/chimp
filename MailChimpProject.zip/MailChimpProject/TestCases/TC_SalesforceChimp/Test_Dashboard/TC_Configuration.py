import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Configuration import SF_Configuration
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Configuration(SalesForceBaseTest):

    def setup(self):
        """
        Setup method to verify the page view of Configuration.

        This method initializes the SF_Configuration and CF_Dashboard_View classes with the driver.
        It waits for the loader to disappear, redirects to the campaign page,
        retrieves the page heading, and verifies if the page is opened successfully.

        Parameters:
            - None

        Returns:
            - None
        """
        sf_config = SF_Configuration(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Configuration class.
        This method creates a new instance of the Configuration class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_config.redirect_to_configuration_page(locator_strategy=By.XPATH,
                                                 locator_value=str(
                                                     ConfigReader.locatorsReadConfig("configuration locators",
                                                                                     "config_name_xpath")),
                                                 view="Side View : Configuration :")
        page_head = sf_cf_dash.return_page_heading(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                          "txt_heading_page_xpath"))
                                        , view="")
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        if page_head.text == "Configuration":
            self.logger.info("Configuration Page Opened Successfully!")
        else:
            pytest.fail("Configuration Page not Opened Successfully!")

    def test_refresh_configuration_page(self):
        """Verifying the Refresh Button Of Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Configuration : Refresh : ")
        self.logger.info("Configuration Page Refreshed Successfully!")

    def test_search_bar(self):
        """Verifying the Configuration Search Bar
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Configuration class and initializes it with the provided driver.
        """
        elem = sf_cf_dash.search_bar(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "inpt_search_xpath")),
                                     view="Side view : Configuration : Search :",
                                     send_text=ConfigReader.dataReadConfig("mailchimp dashboard locators",
                                                                           "configuration_search"),
                                     locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "list_td_element_xpath")),
                                     view2="Side view : Configuration : Search :",
                                     locator_strategy3=By.XPATH,
                                     locator_value3=str(
                                         ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")),
                                     view3="Side view : Campaigns : Wait for loader to disappear ")
        search_successful = False
        for element in elem:
            if ConfigReader.dataReadConfig("mailchimp dashboard locators", "configuration_search") in element.text:
                self.logger.info("Configuration Search Successful! " + element.text)
                search_successful = True
            else:
                self.logger.error("Configuration Search Failed!")
        if not search_successful:
            pytest.fail("Configuration Search Failed!")

