import pytest
from selenium.webdriver.common.by import By
from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from TestCases.Setup_Methods.SF_Setup_Methods.SF_SM_Dashboards.SF_Groups import (
    groups_setup_method,
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Groups(SalesForceBaseTest):

    def setup_method(self):
        """
        Setup method to verify the page view of Groups.

        This function sets up the Groups page view for verification.
        It initializes the SF_Groups and CF_Dashboard_View instances with the provided driver.
        It waits for the loader to disappear and redirects to the Groups page.

        Parameters:
        - Read From Utilities file by Readconfig function
        """
        # Call the groups_setup_method function to set up the page view
        groups_setup_method()

        # Initialize the CF_Dashboard_View instance with the provided driver
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)

    def test_refresh_groups_page(self):
        """Verifying the Refresh Button Of Page View Of groups
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the configuration class and initializes it with the provided driver.
        """
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Groups : Wait for loader to disappear ",
        )
        self.sf_cf_dash.page_refresh(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_refresh_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Refresh : ",
        )
        self.logger.info("Groups Page Refreshed Successfully!")

    # default_mailchimp_account : dmc
    def test_select_dmc_account(self):
        """Verifying the Select Default Groups
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Groups : Wait for loader to disappear ",
        )
        self.sf_cf_dash.select_mailchimp_account(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_default_account_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Select Mailchimp Account : ",
            locator_strategy2=By.XPATH,
            locator_value2=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "select_default_account_xpath"
                )
            ),
            view2="Test Case : Step : Side View : Groups : Select DMC Account : ",
        )
        element = self.sf_cf_dash.success_txt(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_default_account_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Select Mailchimp Account : Success Message",
        )
        validation_text = element.text
        if "Durgapalvinay32@gmail" in validation_text:
            self.logger.info(
                "Groups Page Mail Chimp Default Account Selected Successfully! validation text "
                + validation_text
            )
        else:
            self.logger.info("Groups Page Mail Chimp Default Account Selected Failed!")

    def test_select_audience_account(self):
        """Verifying the Select Default Audience Groups
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Mailchimp Contacts class and initializes it with the provided driver.
        """
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Groups : Wait for loader to disappear ",
        )
        self.sf_cf_dash.select_mailchimp_account(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_audience_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Select Mailchimp Account : ",
            locator_strategy2=By.XPATH,
            locator_value2=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "select_audience_xpath"
                )
            ),
            view2="Test Case : Step : Side View : Groups : Select Audience Account : ",
        )
        element = self.sf_cf_dash.success_txt(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_audience_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Select Mailchimp Account : Success Message",
        )
        validation_text = element.text
        if "Durgapalvinay32@gmail" in validation_text:
            self.logger.info(
                "Groups Page Mail  Audience Account Selected Successfully! validation text "
                + validation_text
            )
        else:
            self.logger.info("Groups Page Mail Chimp Default Account Selected Failed!")

    def test_mass_import(self):
        """Verifying the  Groups Mass Import
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Groups : Wait for loader to disappear ",
        )
        self.sf_cf_dash.mass_import(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_mass_import_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Mass Import : ",
        )
        self.sf_cf_dash.wait_for_progress_bar(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "progress_bar_xpath"
                )
            ),
            view="",
        )
        element = self.sf_cf_dash.success_txt(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "import_success_txt_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Mass Import : Success Message",
        )
        validation_text = element.text
        if "Success" in validation_text:
            self.logger.info("Audience Mass Import Successful! " + validation_text)
        else:
            self.logger.info("Audience Mass Import Failed!")

    def test_search_bar(self):
        """Verifying the  Groups Search Bar
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:

        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        elem = self.sf_cf_dash.search_bar(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "inpt_search_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Search :",
            send_text=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "group_search"
            ),
            locator_strategy2=By.XPATH,
            locator_value2=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "list_th_element_xpath"
                )
            ),
            view2="Test Case : Step : Side View : Groups : Search :",
            locator_strategy3=By.XPATH,
            locator_value3=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view3="Test Case : Step : Side View : Groups : Wait for loader to disappear ",
        )
        for element in elem:
            if (
                ConfigReader.dataReadConfig(
                    "mailchimp dashboard locators", "group_search"
                )
                in element.text
            ):
                self.logger.info("Groups Search Successful! " + element.text)
            else:
                pytest.info("Groups Search Failed!")

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Display Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_display_save(self):
        """Verifying the Groups, Utility Setting Selected Field to display and save
        Parameters:
        - Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.utility_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_setting_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Setting : Utility Setting",
        )

        self.sf_cf_dash.select_fields_move_from_available_to_visible(
            utility_setting_section=By.XPATH,
            utility_setting_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "lnk_items_xpath")
            ),
            utility_setting_view="Test Case : Step : Side View : Groups : Setting : Utility Setting ",
            available_selected_field_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_filed_to_display"
            ),
            select_fields_section=By.XPATH,
            select_fields_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_available_field_to_display"
                )
            ),
            select_fields_view="Test Case : Step : Side View : Groups : Setting : Utility Setting : Select Fields ",
            available_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_display_group_fields"
            ),
            move_button_section=By.XPATH,
            move_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_move_to_visible_xpath"
                )
            ),
            move_button_view="Test Case : Step : Side View : Groups : Setting : Select Field To Search : Move Selected To Visible",
            cancel_button_section=By.XPATH,
            cancel_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_pop_up_xpath"
                )
            ),
            cancel_button_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Display : Cancel Button",
            ok_sure_btn_section=By.XPATH,
            ok_sure_btn_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            ok_sure_btn_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Display : Sure Ok Button",
        )

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Display Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_display_cancel(self):
        """Verifying the  Groups , Utility Setting Selected Field to display and cancel
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.utility_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_setting_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Setting ",
        )
        self.sf_cf_dash.select_fields_move_from_available_to_visible(
            utility_setting_section=By.XPATH,
            utility_setting_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "lnk_items_xpath")
            ),
            utility_setting_view="Test Case : Step : Side View : Groups : Setting : Utility Setting ",
            available_selected_field_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_filed_to_display"
            ),
            select_fields_section=By.XPATH,
            select_fields_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_available_field_to_display"
                )
            ),
            select_fields_view="Test Case : Step : Side View : Groups : Setting : Utility Setting : Select Fields ",
            available_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_display_group_fields"
            ),
            move_button_section=By.XPATH,
            move_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_move_to_visible_xpath"
                )
            ),
            move_button_view="Test Case : Step : Side View : Groups : Setting : Select Field To Display : Move Selected To Visible",
            cancel_button_section=By.XPATH,
            cancel_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_pop_up_xpath"
                )
            ),
            cancel_button_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Display : Cancel Button",
            ok_sure_btn_section=By.XPATH,
            ok_sure_btn_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            ok_sure_btn_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Display : Sure Ok Button",
        )

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Search Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_search_cancel(self):
        """Verifying the  Groups , Utility Setting Selected Field to search and cancel
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.utility_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_setting_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Setting ",
        )
        self.sf_cf_dash.select_fields_move_from_available_to_visible(
            utility_setting_section=By.XPATH,
            utility_setting_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "lnk_items_xpath")
            ),
            utility_setting_view="Test Case : Step : Side View : Groups : Setting : Utility Setting ",
            available_selected_field_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_field_to_search"
            ),
            select_fields_section=By.XPATH,
            select_fields_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_available_field_to_display"
                )
            ),
            select_fields_view="Test Case : Step : Side View : Groups : Setting : Utility Setting : Select Fields ",
            available_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_search_group_fields"
            ),
            move_button_section=By.XPATH,
            move_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_move_selected_xpath"
                )
            ),
            move_button_view="Test Case : Step : Side View : Groups : Setting : Select Field To Search : Move Selected To Visible",
            cancel_button_section=By.XPATH,
            cancel_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_pop_up_xpath"
                )
            ),
            cancel_button_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Search : Cancel Button",
            ok_sure_btn_section=By.XPATH,
            ok_sure_btn_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            ok_sure_btn_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Display : Sure Ok Button",
        )

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Search Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_search_save(self):
        """Verifying the  Groups , Utility Setting Selected Field to search and save
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.utility_setting(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_setting_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Setting ",
        )
        self.sf_cf_dash.select_fields_move_from_available_to_visible(
            utility_setting_section=By.XPATH,
            utility_setting_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "lnk_items_xpath")
            ),
            utility_setting_view="Test Case : Step : Side View : Groups : Setting : Utility Setting ",
            available_selected_field_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_field_to_search"
            ),
            select_fields_section=By.XPATH,
            select_fields_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_available_field_to_display"
                )
            ),
            select_fields_view="Test Case : Step : Side View : Groups : Setting : Utility Setting : Select Fields ",
            available_data_config=ConfigReader.dataReadConfig(
                "mailchimp dashboard locators", "select_search_group_fields"
            ),
            move_button_section=By.XPATH,
            move_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_move_selected_xpath"
                )
            ),
            move_button_view="Test Case : Step : Side View : Groups : Setting : Select Field To Search : Move Selected To Visible",
            cancel_button_section=By.XPATH,
            cancel_button_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_pop_up_xpath"
                )
            ),
            cancel_button_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Search : Cancel Button",
            ok_sure_btn_section=By.XPATH,
            ok_sure_btn_key=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_sure_xpath"
                )
            ),
            ok_sure_btn_view="Test Case : Step : Side View : Groups : Setting : Selected Field To Display : Sure Ok Button",
        )

    def test_delete_field(self):
        """Verifying the  Groups , Delete Field
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        self.sf_cf_dash.checkboxes(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "lst_checkboxes_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Checkboxes",
        )
        self.sf_cf_dash.delete_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_delete_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Delete Button",
        )
        self.sf_cf_dash.ok_btn(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_ok_pop_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Delete Button : OK Button",
        )
        # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
        self.sf_cf_dash.mass_import(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_mass_import_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Mass Import : ",
        )
        self.sf_cf_dash.wait_for_progress_bar(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "progress_bar_xpath"
                )
            ),
            view="",
        )

    def test_filter_function(self):
        """Verifying the  Groups , Filter button functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        """

        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Groups class and initializes it with the provided driver.
        """
        self.sf_cf_dash.filter_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_filter_xpath"
                )
            ),
            view="Test Case : Step : Side View : Groups : Filter Button",
        )
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Case : Step : Side View : Groups : Wait for loader to disappear ",
        )

        self.sf_cf_dash.add_filter_pop_ups(
            sf_locator_strategy=By.XPATH,
            sf_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "inpt_select_field_xpath"
                )
            ),
            sf_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Select Field",
            sf_config_data=str(
                ConfigReader.dataReadConfig("Groups filter data", "select_field")
            ),
            sf_lst_locator_strategy=By.XPATH,
            sf_lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "select_filed_dropdown_list_xpath"
                )
            ),
            sf_lst_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Select Field Dropdown List",
            operator_locator_strategy=By.XPATH,
            operator_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_select_operator_xpath"
                )
            ),
            operator_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Select Operator",
            operator_lst_locator_strategy=By.XPATH,
            operator_lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "select_operator_dropdown_list_xpath"
                )
            ),
            operator_lst_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Select Operator Dropdown List",
            operator_config_data=str(
                ConfigReader.dataReadConfig("Groups filter data", "Operator")
            ),
            val_locator_strategy=By.XPATH,
            val_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "inpt_value_xpath"
                )
            ),
            val_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Value",
            val_config_data=str(
                ConfigReader.dataReadConfig("Groups filter data", "value")
            ),
            cancel_locator_strategy=By.XPATH,
            cancel_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_cancel_pop_up_xpath"
                )
            ),
            cancel_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Cancel Button",
            apply_locator_strategy=By.XPATH,
            apply_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "dashboard locators", "btn_apply_pop_up_xpath"
                )
            ),
            apply_view="Test Case : Step : Side View : Groups : Filter Button : Add Filter Pop Up : Apply Button",
            add_filter=False,
        )
