import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_CF_SetupPage import SF_CF_SetupPage
from Pages.SalesforceChimp.SF_Audience import SF_Audience
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Audience(SalesForceBaseTest):

    def test_audience_page(self):
        """Verifying the Page View Of Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf = SF_CF_SetupPage(SalesForceBaseTest.driver)
        sf_aud = SF_Audience(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Audience class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf.redirect_to_app_page()
        sf_aud.redirect_to_audience_page(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig("audience locators",
                                                                                           "audience_name_xpath")),
                                         view="Side view : Audience :")
        self.logger.info("Audience Page Refreshed Successfully!")
    @pytest.mark.skip
    def test_refresh_audience_page(self):
        """Verifying the Refresh Button Of Page View Of Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Audience : Refresh : ")
    @pytest.mark.skip
    # default_mailchimp_account : dmc
    def test_select_dmc_account(self):
        """Verifying the Select Default Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.select_mailchimp_account(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                            , view="Side view : Audience : Select Mailchimp Account : ",
                                            locator_strategy2=By.XPATH,
                                            locator_value2=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                               "select_default_account_xpath"))
                                            , view2="Side view : Audience : Select DMC Account : ")

        self.logger.info("Audience Page Mail Chimp Default Account Selected Successfully!")

    def test_mass_import(self):
        """Verifying the  Audience Mass Import
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        -Test Cases: Verifying the shop delete functionality
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.mass_import(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_mass_import_xpath")),
                               view="Side view : Audience : Mass Import : ")
        locator = ConfigReader.locatorsReadConfig("dashboard locators", "progress_bar_xpath")
        self.logger.info(f"{locator}")
        # sf_cf_dash.wait_for_progress_bar(locator_strategy=By.XPATH,
        #                                  locator_value=str(
        #                                      ConfigReader.locatorsReadConfig("dashboard locators",
        #                                                                      "progress_bar_xpath")), view="")
