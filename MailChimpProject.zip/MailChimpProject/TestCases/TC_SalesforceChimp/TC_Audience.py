import ast
import time

import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_CF_SetupPage import SF_CF_SetupPage
from Pages.SalesforceChimp.SF_Audience import SF_Audience
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Audience(SalesForceBaseTest):

    def test_audience_page(self):
        """Verifying the Page View Of Audience
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf = SF_CF_SetupPage(SalesForceBaseTest.driver)
        sf_aud = SF_Audience(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Audience class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf.redirect_to_app_page()
        sf_aud.redirect_to_audience_page(locator_strategy=By.XPATH,
                                         locator_value=str(ConfigReader.locatorsReadConfig("audience locators",
                                                                                           "audience_name_xpath")),
                                         view="Side view : Audience :")
        self.logger.info("Audience Page Refreshed Successfully!")

    @pytest.mark.skip
    def test_refresh_audience_page(self):
        """Verifying the Refresh Button Of Page View Of Audience
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Audience : Refresh : ")

    @pytest.mark.skip
    # default_mailchimp_account : dmc
    def test_select_dmc_account(self):
        """Verifying the Select Default Audience
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.select_mailchimp_account(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                            , view="Side view : Audience : Select Mailchimp Account : ",
                                            locator_strategy2=By.XPATH,
                                            locator_value2=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                               "select_default_account_xpath"))
                                            , view2="Side view : Audience : Select DMC Account : ")
        element = sf_cf_dash.success_txt(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                         , view="Side view : Audience : Select Mailchimp Account : Success Message")
        validation_text = element.text
        if "Durgapalvinay32@gmail" in validation_text:
            self.logger.info(
                "Audience Page Mail Chimp Default Account Selected Successfully! validation text " + validation_text)
        else:
            self.logger.info("Audience Mass Import Failed!")

    @pytest.mark.skip
    def test_mass_import(self):
        """Verifying the  Audience Mass Import
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.mass_import(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_mass_import_xpath")),
                               view="Side view : Audience : Mass Import : ")
        sf_cf_dash.wait_for_progress_bar(locator_strategy=By.XPATH,
                                         locator_value=str(
                                             ConfigReader.locatorsReadConfig("dashboard locators",
                                                                             "progress_bar_xpath")), view="")
        element = sf_cf_dash.success_txt(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "import_success_txt_xpath"))
                                         , view="Side view : Audience : Mass Import : Success Message")
        validation_text = element.text
        if "Success" in validation_text:
            self.logger.info("Audience Mass Import Successful! " + validation_text)
        else:
            self.logger.info("Audience Mass Import Failed!")

    @pytest.mark.skip
    def test_search_bar(self):
        """Verifying the  Audience Search Bar
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        elem = sf_cf_dash.search_bar(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "inpt_search_xpath")),
                                     view="Side view : Audience : Search :",
                                     send_text=ConfigReader.dataReadConfig("mailchimp dashboard locators",
                                                                           "audience_search"),
                                     locator_strategy2=By.XPATH,
                                     locator_value2=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                        "list_th_element_xpath")),
                                     view2="Side view : Audience : Search :",
                                     locator_strategy3=By.XPATH,
                                     locator_value3=str(
                                         ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")),
                                     view3="Side view : Audience : Wait for loader to disappear ")
        for element in elem:
            if ConfigReader.dataReadConfig("mailchimp dashboard locators", "audience_search") in element.text:
                self.logger.info("Audience Search Successful! " + element.text)
            else:
                pytest.info("Audience Search Failed!")

    @pytest.mark.skip
    def test_cancel_audience(self):
        """Verifying the  Audience , cancel Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Audience : Setting ")
        add_audience = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Audience : Setting ")
        for _ in add_audience:
            self.logger.info(f"element text {_.text}")
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_audience"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Audience : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"),
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_mc_id_xpath")),
                                                                         view4="Side view : Audience : Setting : Add Form : essMC_Mailchimp Audience ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"), condition=False)
                sf_cf_dash.cancel_form(locator_strategy=By.XPATH,
                                       locator_value=str(
                                           ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                       view="Side view : Audience : Setting : Add Form : Cancel Button")
                break

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Add Audience Properly , So For Now We are Performing Cancel Button F
    def test_save_audience(self):
        """Verifying the  Audience , Add Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Audience : Setting ")
        add_audience = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Audience : Setting ")
        for _ in add_audience:
            self.logger.info(f"element text {_.text}")
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_audience"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Audience : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"),
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_mc_id_xpath")),
                                                                         view4="Side view : Audience : Setting : Add Form : essMC_Mailchimp Audience ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"), condition=False)
                sf_cf_dash.cancel_form(locator_strategy=By.XPATH,
                                       locator_value=str(
                                           ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                       view="Side view : Audience : Setting : Add Form : Cancel Button")
                break

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Add Audience Properly , So For Now We are Performing Cancel Button F
    def test_save_new_audience(self):
        """Verifying the  Audience , Add Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Audience : Setting ")
        add_audience = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Audience : Setting ")
        for _ in add_audience:
            self.logger.info(f"element text {_.text}")
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_audience"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Audience : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"),
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_mc_id_xpath")),
                                                                         view4="Side view : Audience : Setting : Add Form : essMC_Mailchimp Audience ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"), condition=False)
                sf_cf_dash.cancel_form(locator_strategy=By.XPATH,
                                       locator_value=str(
                                           ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                       view="Side view : Audience : Setting : Add Form : Cancel Button")
                break

    def test_select_field_to_display(self):
        """Verifying the  Audience , Add Audience
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Audience : Setting ")
        select_filed_to_display = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                                   locator_value=str(
                                                                       ConfigReader.locatorsReadConfig(
                                                                           "dashboard locators",
                                                                           "lnk_items_xpath")),
                                                                   view="Side view : Audience : Setting ")
        for _ in select_filed_to_display:
            self.logger.info(f"element text {_.text}")
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "select_filed_to_display"):
                _.click()
                visible_fields = sf_cf_dash.selected_field_to_display_and_search(locator_strategy=By.XPATH,
                                                                                 locator_value=str(
                                                                                     ConfigReader.locatorsReadConfig(
                                                                                         "dashboard locators",
                                                                                         "lst_available_field_to_display")),
                                                                                 view="Side view : Audience : Setting ")
                for _ in visible_fields:
                    self.logger.info(f"element text {_.text}")
                sf_cf_dash.close_pop_up(locator_strategy=By.XPATH,
                                        locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                          "btn_close_pop_up_xpath")),
                                        view="Side view : Audience : Setting : Select Field To Display : Close Pop Up")
                break

    def test_select_field_to_search_and_cancel(self):
        """Verifying the  Audience , Utility Setting Selected Field to search and Cancel
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Audience : Setting ")
        select_field_to_search = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                                  locator_value=str(
                                                                      ConfigReader.locatorsReadConfig(
                                                                          "dashboard locators",
                                                                          "lnk_items_xpath")),
                                                                  view="Side view : Audience : Setting ")
        # Loop through select_field_to_search elements
        for _ in select_field_to_search:
            self.logger.info(f"element text {_.text}")

            # Check if the text of the element matches the expected value from configuration
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "select_field_to_search"):
                # Click on the element if it matches
                _.click()

                # Retrieve visible fields to display and search
                # visible_fields = sf_cf_dash.selected_field_to_display_and_search(
                #     locator_strategy=By.XPATH,
                #     locator_value=str(
                #         ConfigReader.locatorsReadConfig("dashboard locators", "lst_available_field_to_display")),
                #     view="Side view : Audience : Setting : Select Field To Search : Visible Fields"
                # )
                #
                # # Loop through visible_fields
                # for _ in visible_fields:
                #     self.logger.info(f"element text {_.text}")
                #
                #     # Check if the text of the field matches the expected visible data
                #     visible_data = ConfigReader.dataReadConfig("mailchimp dashboard locators",
                #                                                "select_search_available_fields")
                #
                #     # Right now we are using single text as visible data ,
                #     # this function is for multiple text , just need to change data in config file
                #     # and use ast.literal_eval to convert it to list
                #     if _.text == visible_data:
                #         # Click on the element if it matches
                #         _.click()
                #
                #         # Move selected item to visible field
                #         sf_cf_dash.move_selected_to_visible_field(
                #             locator_strategy=By.XPATH,
                #             locator_value=str(
                #                 ConfigReader.locatorsReadConfig("dashboard locators", "btn_move_selected_xpath")),
                #             view="Side view : Audience : Setting : Select Field To Search : Move Selected To Visible"
                #         )
                #         sf_cf_dash.cancel_form(locator_strategy=By.XPATH,
                #                                locator_value=str(
                #                                    ConfigReader.locatorsReadConfig("dashboard locators",
                #                                                                    "btn_cancel_xpath")),
                #                                view="Side view : Audience : Setting : Add Form : Cancel Button")
                #     else:
                #         self.logger.info("Side view : Audience : Setting : Select Field To Search : Visible Fields : No data found")

            else:
                # Close the pop-up if the condition is not met
                sf_cf_dash.close_pop_up(
                    locator_strategy=By.XPATH,
                    locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators", "btn_close_pop_up_xpath")),
                    view="Side view : Audience : Setting : Select Field To Search : Close Pop Up"
                )
    # On Demand we can use this , for now we are using cancel button in place of save button
    def test_select_field_to_search_and_save(self):
        """Verifying the  Audience , Utility Setting Selected Field to search and save
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Audience : Setting ")
        select_field_to_search = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                                  locator_value=str(
                                                                      ConfigReader.locatorsReadConfig(
                                                                          "dashboard locators",
                                                                          "lnk_items_xpath")),
                                                                  view="Side view : Audience : Setting ")
        # Loop through select_field_to_search elements
        for _ in select_field_to_search:
            self.logger.info(f"element text {_.text}")

            # Check if the text of the element matches the expected value from configuration
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "select_field_to_search"):
                # Click on the element if it matches
                _.click()

                # # Retrieve visible fields to display and search
                # visible_fields = sf_cf_dash.selected_field_to_display_and_search(
                #     locator_strategy=By.XPATH,
                #     locator_value=str(
                #         ConfigReader.locatorsReadConfig("dashboard locators", "lst_available_field_to_display")),
                #     view="Side view : Audience : Setting : Select Field To Search : Visible Fields"
                # )
                #
                # # Loop through visible_fields
                # for _ in visible_fields:
                #     self.logger.info(f"element text {_.text}")
                #
                #     # Check if the text of the field matches the expected visible data
                #     visible_data = ConfigReader.dataReadConfig("mailchimp dashboard locators",
                #                                                "select_search_available_fields")
                #
                #     # Right now we are using single text as visible data ,
                #     # this function is for multiple text , just need to change data in config file
                #     # and use ast.literal_eval to convert it to list
                #     if _.text == visible_data:
                #         # Click on the element if it matches
                #         _.click()
                #
                #         # Move selected item to visible field
                #         sf_cf_dash.move_selected_to_visible_field(
                #             locator_strategy=By.XPATH,
                #             locator_value=str(
                #                 ConfigReader.locatorsReadConfig("dashboard locators", "btn_move_selected_xpath")),
                #             view="Side view : Audience : Setting : Select Field To Search : Move Selected To Visible"
                #         )
                #         sf_cf_dash.cancel_form(locator_strategy=By.XPATH,
                #                                locator_value=str(
                #                                    ConfigReader.locatorsReadConfig("dashboard locators",
                #                                                                    "btn_cancel_xpath")),
                #                                view="Side view : Audience : Setting : Add Form : Cancel Button")
                #     else:
                #         self.logger.info("Side view : Audience : Setting : Select Field To Search : Visible Fields : No data found")


            else:
                # Close the pop-up if the condition is not met
                sf_cf_dash.close_pop_up(
                    locator_strategy=By.XPATH,
                    locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators", "btn_close_pop_up_xpath")),
                    view="Side view : Audience : Setting : Select Field To Search : Close Pop Up"
                )


