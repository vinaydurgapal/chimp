import time

import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Campaigns import SF_Campaigns
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Campaigns(SalesForceBaseTest):

    def test_campaign_page(self):
        """Verifying the Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        
        """
        sf_camp = SF_Campaigns(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Campaigns class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_camp.redirect_to_campaign_page(locator_strategy=By.XPATH,
                                          locator_value=str(ConfigReader.locatorsReadConfig("campaign locators",
                                                                                            "campaign_name_xpath")),
                                          view="Side view : Campaigns : ")
        self.logger.info("Campaigns Page Opened Successfully!")

    def test_refresh_campaign_page(self):
        """Verifying the Refresh Button Of Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Campaigns : Refresh : ")
        self.logger.info("Campaigns Page Refreshed Successfully!")

    # default_mailchimp_account : dmc
    def test_select_dmc_account(self):
        """Verifying the Select Default Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_cf_dash.select_mailchimp_account(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                            , view="Side view : Campaigns : Select Mailchimp Account : ",
                                            locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "select_default_account_xpath"))
                                            , view2="Side view : Campaigns : Select DMC Account : ")
        element = sf_cf_dash.success_txt(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                         , view="Side view : Campaigns : Select Mailchimp Account : Success Message")
        validation_text = element.text
        if "Durgapalvinay32@gmail" in validation_text:
            self.logger.info(
                "Campaigns Page Mail Chimp Default Account Selected Successfully! validation text " + validation_text)
        else:
            self.logger.info("Campaigns Page Mail Chimp Default Account Selected Failed!")

    def test_mass_import(self):
        """Verifying the  Campaigns Mass Import
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_cf_dash.mass_import(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_mass_import_xpath")),
                               view="Side view : Campaigns : Mass Import : ")
        sf_cf_dash.wait_for_progress_bar(locator_strategy=By.XPATH,
                                         locator_value=str(
                                             ConfigReader.locatorsReadConfig("dashboard locators",
                                                                             "progress_bar_xpath")), view="")
        element = sf_cf_dash.success_txt(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "import_success_txt_xpath"))
                                         , view="Side view : Campaigns : Mass Import : Success Message")
        validation_text = element.text
        if "Success" in validation_text:
            self.logger.info("Campaigns Mass Import Successful! " + validation_text)
        else:
            self.logger.info("Campaigns Mass Import Failed!")

    def test_search_bar(self):
        """Verifying the  Campaigns Search Bar
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        elem = sf_cf_dash.search_bar(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "inpt_search_xpath")),
                                     view="Side view : Campaigns : Search :",
                                     send_text=ConfigReader.dataReadConfig("mailchimp dashboard locators",
                                                                           "campaign_search"),
                                     locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "list_th_element_xpath")),
                                     view2="Side view : Campaigns : Search :",
                                     locator_strategy3=By.XPATH,
                                     locator_value3=str(
                                         ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")),
                                     view3="Side view : Campaigns : Wait for loader to disappear ")
        for element in elem:
            if ConfigReader.dataReadConfig("mailchimp dashboard locators", "campaign_search") in element.text:
                self.logger.info("Campaigns Search Successful! " + element.text)
            else:
                pytest.info("Campaigns Search Failed!")

    @pytest.mark.skip
    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Add Campaigns Properly , So For Now We are Performing Cancel Button F
    def test_save_campaign(self):
        """Verifying the  Campaigns , Add Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        add_campaign = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Campaigns : Setting ")
        for _ in add_campaign:
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_campaign"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Campaigns : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"),
                                                                         locator_strategy2=By.XPATH,
                                                                         locator_value2=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_name_xpath")),
                                                                         view2="Side view : Campaigns : Setting : Add Form : Default Account",
                                                                         locator_strategy3=By.XPATH,
                                                                         locator_value3=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "select_mailchimp_account_xpath")),
                                                                         view3="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Campaigns ",
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_mc_id_xpath")),
                                                                         view4="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Campaigns ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"), condition=True)
                sf_cf_dash.cancel_btn(locator_strategy=By.XPATH,
                                      locator_value=str(
                                          ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                      view="Side view : Campaigns : Setting : Add Form : Cancel Button")
                break

    @pytest.mark.skip
    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Add Campaigns Properly , So For Now We are Performing Cancel Button F
    def test_cancel_campaign(self):
        """Verifying the  Campaigns , Add Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        add_campaign = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Campaigns : Setting ")
        for _ in add_campaign:
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_campaign"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Campaigns : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"),
                                                                         locator_strategy2=By.XPATH,
                                                                         locator_value2=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_name_xpath")),
                                                                         view2="Side view : Campaigns : Setting : Add Form : Default Account",
                                                                         locator_strategy3=By.XPATH,
                                                                         locator_value3=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "select_mailchimp_account_xpath")),
                                                                         view3="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Campaigns ",
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_mc_id_xpath")),
                                                                         view4="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Campaigns ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"), condition=True)
                sf_cf_dash.cancel_btn(locator_strategy=By.XPATH,
                                      locator_value=str(
                                          ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                      view="Side view : Campaigns : Setting : Add Form : Cancel Button")
                break

    @pytest.mark.skip
    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Add Campaigns Properly , So For Now We are Performing Cancel Button F
    def test_save_new_campaign(self):
        """Verifying the  Campaigns , Add Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        add_campaign = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Campaigns : Setting ")
        for _ in add_campaign:
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_campaign"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Campaigns : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"),
                                                                         locator_strategy2=By.XPATH,
                                                                         locator_value2=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_name_xpath")),
                                                                         view2="Side view : Campaigns : Setting : Add Form : Default Account",
                                                                         locator_strategy3=By.XPATH,
                                                                         locator_value3=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "select_mailchimp_account_xpath")),
                                                                         view3="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Campaigns ",
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                                             ConfigReader.locatorsReadConfig(
                                                                                 "dashboard locators",
                                                                                 "inpt_mc_id_xpath")),
                                                                         view4="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Campaigns ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                                             "mailchimp dashboard locators",
                                                                             "info_name"), condition=True)
                sf_cf_dash.cancel_btn(locator_strategy=By.XPATH,
                                      locator_value=str(
                                          ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                      view="Side view : Campaigns : Setting : Add Form : Cancel Button")
                break

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Display Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_display_save(self):
        """Verifying the Campaigns, Utility Setting Selected Field to display and save
        Parameters:
        - Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting : Utility Setting")

        sf_cf_dash.select_fields_move_from_available_to_visible(utility_setting_section=By.XPATH,
                                                                utility_setting_key=str(
                                                                    ConfigReader.locatorsReadConfig(
                                                                        "dashboard locators",
                                                                        "lnk_items_xpath")),
                                                                utility_setting_view="Side view : Campaigns : Setting : Utility Setting ",
                                                                available_selected_field_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_filed_to_display"),
                                                                select_fields_section=By.XPATH,
                                                                select_fields_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators",
                                                                    "lst_available_field_to_display")),
                                                                select_fields_view="Side view : Campaigns : Setting : Utility Setting : Select Fields ",
                                                                available_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_display_camp_fields"),
                                                                move_button_section=By.XPATH, move_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_move_to_visible_xpath")),
                                                                move_button_view="Side view : Campaigns : Setting : Select Field To Search : Move Selected To Visible",
                                                                cancel_button_section=By.XPATH, cancel_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_pop_up_xpath")),
                                                                cancel_button_view="Side view : Campaigns : Setting : Selected Field To Display : Cancel Button",
                                                                ok_sure_btn_section=By.XPATH, ok_sure_btn_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                                                                ok_sure_btn_view="Side view : Campaigns : Setting : Selected Field To Display : Sure Ok Button"
                                                                )

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Display Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_display_cancel(self):
        """Verifying the  Campaigns , Utility Setting Selected Field to display and cancel
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        sf_cf_dash.select_fields_move_from_available_to_visible(utility_setting_section=By.XPATH,
                                                                utility_setting_key=str(
                                                                    ConfigReader.locatorsReadConfig(
                                                                        "dashboard locators",
                                                                        "lnk_items_xpath")),
                                                                utility_setting_view="Side view : Campaigns : Setting : Utility Setting ",
                                                                available_selected_field_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_filed_to_display"),
                                                                select_fields_section=By.XPATH,
                                                                select_fields_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators",
                                                                    "lst_available_field_to_display")),
                                                                select_fields_view="Side view : Campaigns : Setting : Utility Setting : Select Fields ",
                                                                available_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_display_camp_fields"),
                                                                move_button_section=By.XPATH, move_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_move_to_visible_xpath")),
                                                                move_button_view="Side view : Campaigns : Setting : Select Field To Display : Move Selected To Visible",
                                                                cancel_button_section=By.XPATH, cancel_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_pop_up_xpath")),
                                                                cancel_button_view="Side view : Campaigns : Setting : Selected Field To Display : Cancel Button",
                                                                ok_sure_btn_section=By.XPATH,
                                                                ok_sure_btn_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators", "btn_cancel_sure_xpath")),
                                                                ok_sure_btn_view="Side view : Campaigns : Setting : Selected Field To Display : Sure Ok Button"
                                                                )

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Search Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_search_cancel(self):
        """Verifying the  Campaigns , Utility Setting Selected Field to search and cancel
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        sf_cf_dash.select_fields_move_from_available_to_visible(utility_setting_section=By.XPATH,
                                                                utility_setting_key=str(
                                                                    ConfigReader.locatorsReadConfig(
                                                                        "dashboard locators",
                                                                        "lnk_items_xpath")),
                                                                utility_setting_view="Side view : Campaigns : Setting : Utility Setting ",
                                                                available_selected_field_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_field_to_search"),
                                                                select_fields_section=By.XPATH,
                                                                select_fields_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators",
                                                                    "lst_available_field_to_display")),
                                                                select_fields_view="Side view : Campaigns : Setting : Utility Setting : Select Fields ",
                                                                available_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_search_camp_fields"),
                                                                move_button_section=By.XPATH, move_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_move_selected_xpath")),
                                                                move_button_view="Side view : Campaigns : Setting : Select Field To Search : Move Selected To Visible",
                                                                cancel_button_section=By.XPATH, cancel_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_pop_up_xpath")),
                                                                cancel_button_view="Side view : Campaigns : Setting : Selected Field To Search : Cancel Button",
                                                                ok_sure_btn_section=By.XPATH,
                                                                ok_sure_btn_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators", "btn_cancel_sure_xpath")),
                                                                ok_sure_btn_view="Side view : Campaigns : Setting : Selected Field To Display : Sure Ok Button"
                                                                )

    # Right Now Due To MailChimp Account Not Connected To MailChimp We Can't Verify The Select Field To Search Properly , So For Now We are Performing Cancel Button F
    def test_select_field_to_search_save(self):
        """Verifying the  Campaigns , Utility Setting Selected Field to search and save
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        sf_cf_dash.select_fields_move_from_available_to_visible(utility_setting_section=By.XPATH,
                                                                utility_setting_key=str(
                                                                    ConfigReader.locatorsReadConfig(
                                                                        "dashboard locators",
                                                                        "lnk_items_xpath")),
                                                                utility_setting_view="Side view : Campaigns : Setting : Utility Setting ",
                                                                available_selected_field_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_field_to_search"),
                                                                select_fields_section=By.XPATH,
                                                                select_fields_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators",
                                                                    "lst_available_field_to_display")),
                                                                select_fields_view="Side view : Campaigns : Setting : Utility Setting : Select Fields ",
                                                                available_data_config=ConfigReader.dataReadConfig(
                                                                    "mailchimp dashboard locators",
                                                                    "select_search_camp_fields"),
                                                                move_button_section=By.XPATH, move_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_move_selected_xpath")),
                                                                move_button_view="Side view : Campaigns : Setting : Select Field To Search : Move Selected To Visible",
                                                                cancel_button_section=By.XPATH, cancel_button_key=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_pop_up_xpath")),
                                                                cancel_button_view="Side view : Campaigns : Setting : Selected Field To Search : Cancel Button",
                                                                ok_sure_btn_section=By.XPATH,
                                                                ok_sure_btn_key=str(ConfigReader.locatorsReadConfig(
                                                                    "dashboard locators", "btn_cancel_sure_xpath")),
                                                                ok_sure_btn_view="Side view : Campaigns : Setting : Selected Field To Display : Sure Ok Button"
                                                                )
    def test_delete_field(self):
        """Verifying the  Campaigns , Delete Field
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.checkboxes(locator_strategy=By.XPATH,
                              locator_value=str(
                                  ConfigReader.locatorsReadConfig("dashboard locators", "lst_checkboxes_xpath")),
                              view="Side view : Campaigns : Checkboxes")
        sf_cf_dash.delete_button(locator_strategy=By.XPATH
                                 , locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators", "btn_delete_xpath"))
                                 , view="Side view : Campaigns : Delete Button")
        sf_cf_dash.ok_btn(locator_strategy=By.XPATH
                          , locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators", "btn_ok_pop_xpath"))
                          , view="Side view : Campaigns : Delete Button : OK Button")
        # After Clicking on OK Button The Data Will be Deleted From The MailChimp Account So No Need To Import Again
        sf_cf_dash.mass_import(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_mass_import_xpath")),
                               view="Side view : Campaigns : Mass Import : ")
        sf_cf_dash.wait_for_progress_bar(locator_strategy=By.XPATH,
                                         locator_value=str(
                                             ConfigReader.locatorsReadConfig("dashboard locators",
                                                                             "progress_bar_xpath")), view="")


    def test_filter_function(self):
        """Verifying the  Audience , Filter button functionality
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Audience class and initializes it with the provided driver.
        """
        sf_cf_dash.filter_button(locator_strategy=By.XPATH,
                                 locator_value=str(
                                     ConfigReader.locatorsReadConfig("dashboard locators", "btn_filter_xpath")),
                                 view="Side view : Audience : Filter Button")
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Audience : Wait for loader to disappear ")

        sf_cf_dash.add_filter_pop_ups(sf_locator_strategy=By.XPATH,
                                      sf_locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                           "inpt_select_field_xpath")),
                                      sf_view="Side view : Audience : Filter Button : Add Filter Pop Up : Select Field"
                                      , sf_config_data=str(
                ConfigReader.dataReadConfig("audience filter data", "select_field")),
                                      sf_lst_locator_strategy=By.XPATH,
                                      sf_lst_locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                               "select_filed_dropdown_list_xpath")),
                                      sf_lst_view="Side view : Audience : Filter Button : Add Filter Pop Up : Select Field Dropdown List",
                                      operator_locator_strategy=By.XPATH,
                                      operator_locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                                 "btn_select_operator_xpath")),
                                      operator_view="Side view : Audience : Filter Button : Add Filter Pop Up : Select Operator",
                                      operator_lst_locator_strategy=By.XPATH,
                                      operator_lst_locator_value=str(
                                          ConfigReader.locatorsReadConfig("dashboard locators",
                                                                          "select_operator_dropdown_list_xpath")),
                                      operator_lst_view="Side view : Audience : Filter Button : Add Filter Pop Up : Select Operator Dropdown List",
                                      operator_config_data=str(
                                          ConfigReader.dataReadConfig("audience filter data", "Operator")),
                                      val_locator_strategy=By.XPATH,
                                      val_locator_value=str(
                                          ConfigReader.locatorsReadConfig("dashboard locators", "inpt_value_xpath")),
                                      val_view="Side view : Audience : Filter Button : Add Filter Pop Up : Value",
                                      val_config_data=str(ConfigReader.dataReadConfig("audience filter data", "value")),
                                      cancel_locator_strategy=By.XPATH,
                                      cancel_locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                               "btn_cancel_pop_up_xpath")),
                                      cancel_view="Side view : Audience : Filter Button : Add Filter Pop Up : Cancel Button",
                                      apply_locator_strategy=By.XPATH,
                                      apply_locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                              "btn_apply_pop_up_xpath")),
                                      apply_view="Side view : Audience : Filter Button : Add Filter Pop Up : Apply Button",
                                      add_filter=False

                                      )
        assert False