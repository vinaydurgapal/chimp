import time

import pytest
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_Campaigns import SF_Campaigns
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from Utilities import ConfigReader


class Test_Campaigns(SalesForceBaseTest):

    def test_campaign_page(self):
        """Verifying the Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        
        """
        sf_camp = SF_Campaigns(SalesForceBaseTest.driver)
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Campaigns class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_camp.redirect_to_campaign_page(locator_strategy=By.XPATH,
                                          locator_value=str(ConfigReader.locatorsReadConfig("campaign locators",
                                                                                            "campaign_name_xpath")),
                                          view="Side view : Campaigns : ")
        self.logger.info("Campaigns Page Opened Successfully!")

    def test_refresh_campaign_page(self):
        """Verifying the Refresh Button Of Page View Of Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_cf_dash.page_refresh(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_refresh_xpath"))
                                , view="Side view : Campaigns : Refresh : ")
        self.logger.info("Campaigns Page Refreshed Successfully!")

    # default_mailchimp_account : dmc
    def test_select_dmc_account(self):
        """Verifying the Select Default Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_cf_dash.select_mailchimp_account(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                            , view="Side view : Campaigns : Select Mailchimp Account : ",
                                            locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "select_default_account_xpath"))
                                            , view2="Side view : Campaigns : Select DMC Account : ")
        element = sf_cf_dash.success_txt(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_default_account_xpath"))
                                         , view="Side view : Campaigns : Select Mailchimp Account : Success Message")
        validation_text = element.text
        if "Durgapalvinay32@gmail" in validation_text:
            self.logger.info(
                "Campaigns Page Mail Chimp Default Account Selected Successfully! validation text " + validation_text)
        else:
            self.logger.info("Campaigns Page Mail Chimp Default Account Selected Failed!")

    def test_mass_import(self):
        """Verifying the  Campaigns Mass Import
        Parameters:
        -Read From Utilities file by Readconfig function
        Returns:
        
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Campaigns : Wait for loader to disappear ")
        sf_cf_dash.mass_import(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_mass_import_xpath")),
                               view="Side view : Campaigns : Mass Import : ")
        sf_cf_dash.wait_for_progress_bar(locator_strategy=By.XPATH,
                                         locator_value=str(
                                             ConfigReader.locatorsReadConfig("dashboard locators",
                                                                             "progress_bar_xpath")), view="")
        element = sf_cf_dash.success_txt(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "import_success_txt_xpath"))
                                         , view="Side view : Campaigns : Mass Import : Success Message")
        validation_text = element.text
        if "Success" in validation_text:
            self.logger.info("Campaigns Mass Import Successful! " + validation_text)
        else:
            self.logger.info("Campaigns Mass Import Failed!")

    def test_search_bar(self):
        """Verifying the  Campaigns Search Bar
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        elem = sf_cf_dash.search_bar(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "inpt_search_xpath")),
                                     view="Side view : Campaigns : Search :",
                                     send_text=ConfigReader.dataReadConfig("mailchimp dashboard locators",
                                                                           "campaign_search"),
                                     locator_strategy2=By.XPATH, locator_value2=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "list_th_element_xpath")),
                                     view2="Side view : Campaigns : Search :",
                                     locator_strategy3=By.XPATH,
                                     locator_value3=str(
                                         ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")),
                                     view3="Side view : Campaigns : Wait for loader to disappear ")
        for element in elem:
            if ConfigReader.dataReadConfig("mailchimp dashboard locators", "campaign_search") in element.text:
                self.logger.info("Campaigns Search Successful! " + element.text)
            else:
                pytest.info("Campaigns Search Failed!")

    # Existing Mail Chimp Audience Account
    def test_add_campaign(self):
        """Verifying the  Campaigns , Add Campaigns
        Parameters:
        -Read From Utilities file by Readconfig function

        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        add_campaign = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Campaigns : Setting ")
        for _ in add_campaign:
            if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "add_campaign"):
                _.click()
                sf_cf_dash.utility_setting_add_form_with_recent_audience(locator_strategy=By.XPATH, locator_value=str(
                    ConfigReader.locatorsReadConfig("dashboard locators", "inpt_name_xpath")),
                                                                         view="Side view : Campaigns : Setting : Add Form : Name",
                                                                         send_text=ConfigReader.dataReadConfig(
                                                        "mailchimp dashboard locators",
                                                        "info_name"),
                                                                         locator_strategy2=By.XPATH,
                                                                         locator_value2=str(
                                                        ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                        "inpt_audience_xpath")),
                                                                         view2="Side view : Campaigns : Setting : Add Form : Default Account",
                                                                         locator_strategy3=By.XPATH,
                                                                         locator_value3=str(
                                                        ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                        "select_mailchimp_account_xpath")),
                                                                         view3="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Audience ",
                                                                         locator_strategy4=By.XPATH,
                                                                         locator_value4=str(
                                                        ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                        "inpt_mc_id_xpath")),
                                                                         view4="Side view : Campaigns : Setting : Add Form : essMC_Mailchimp Audience ",

                                                                         send_text2=ConfigReader.dataReadConfig(
                                                        "mailchimp dashboard locators",
                                                        "info_name"), condition=True)
                sf_cf_dash.cancel_form(locator_strategy=By.XPATH,
                                       locator_value=str(
                                           ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_xpath")),
                                       view="Side view : Campaigns : Setting : Add Form : Cancel Button")
                break

    def test_select_field_to_display(self):
        """Verifying the  Campaigns , select field to display
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        select_filed_to_display = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Campaigns : Setting ")
        for _ in select_filed_to_display:
            self.logger.info(f"element text {_.text}")
            # if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "select_filed_to_display"):
            #     _.click()
            #     sf_cf_dash.close_pop_up(locator_strategy=By.XPATH,
            #                             locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
            #                                                                               "btn_close_pop_up_xpath")),
            #                             view="Side view : Campaigns : Setting : Select Field To Display : Close Pop Up")
            # break

    def test_select_field_to_search(self):
        """Verifying the  Campaigns , select field to search
        Parameters:
        -Read From Utilities file by Readconfig function
        """
        sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
        """
        Set up a new instance of the Common Dashboard View class.
        This method creates a new instance of the Campaigns class and initializes it with the provided driver.
        """
        sf_cf_dash.utility_setting(locator_strategy=By.XPATH,
                                   locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                     "btn_setting_xpath")),
                                   view="Side view : Campaigns : Setting ")
        select_field_to_search = sf_cf_dash.utility_setting_items(locator_strategy=By.XPATH,
                                                        locator_value=str(
                                                            ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                            "lnk_items_xpath")),
                                                        view="Side view : Campaigns : Setting ")
        for _ in select_field_to_search:
            self.logger.info(f"element text {_.text}")
            # if _.text == ConfigReader.dataReadConfig("mailchimp dashboard locators", "select_field_to_search"):
            #     _.click()
            #     sf_cf_dash.close_pop_up(locator_strategy=By.XPATH,
            #                             locator_value=str(ConfigReader.locatorsReadConfig("dashboard locators",
            #                                                                               "btn_close_pop_up_xpath")),
            #                             view="Side view : Campaigns : Setting : Select Field To Display : Close Pop Up")
            # break
