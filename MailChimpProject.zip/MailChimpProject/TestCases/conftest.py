import os
import time
from datetime import datetime
from selenium import webdriver
import pytest
from selenium.common import WebDriverException
from selenium import webdriver
from Utilities.LogUtil import LogGen


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    logger = LogGen.loggen()
    try:
        pytest_html = item.config.pluginmanager.getplugin("html")
        outcome = yield
        report = outcome.get_result()
        extra = getattr(report, "extra", [])
        if report.when == "call":
            feature_request = item.funcargs['request']
            driver = feature_request.getfixturevalue('setup_teardown_method')
            # always add url to report
            extra.append(
                pytest_html.extras.url("https://test.salesforce.com/"))
            xfail = hasattr(report, "wasxfail")
            if (report.skipped and xfail) or (report.failed and xfail) or report.outcome == "failed":
                # only add additional html on failure
                report_dir = os.path.dirname(item.config.option.htmlpath)
                file_name = str(int(round(time.time() * 1000))) + ".png"
                screenshot_repo = os.path.join("testcases", file_name)
                image_destination = os.path.join(report_dir, "testcases", file_name)
                driver.save_screenshot(image_destination)
                if file_name:
                    html = '<div><img src="%s" alt="screenshot" width="300" height="200" onclick="window.open(this.src)" align="right"/></div>' % \
                           screenshot_repo
                    extra.append(pytest_html.extras.html(html))
            report.extras = extra
    except Exception as e:
        # Handle any exception that may occur during the teardown (browser quit)
        logger.info(f"Exception occurred during browser teardown: {e}")


@pytest.fixture(scope="class", autouse=True)
def setup_teardown_method(request):
    options = webdriver.ChromeOptions()
    #driver = webdriver.Chrome()

    driver = webdriver.Remote(
        command_executor='http://127.0.0.1:4444/wd/hub',
        options=options
    )

    def setup():
        driver.maximize_window()
        options.page_load_strategy = 'normal'
        options.add_argument("disable-infobars")
        options.add_argument("--disable-cache")
        options.add_argument("--disable-extensions")
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-application-cache')
        options.add_argument('--disable-gpu')
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--homepage=about:blank")
        options.add_argument("--no-default-browser-check")
        options.add_argument("--no-first-run")
        options.add_argument("--disable-sync")
        options.add_argument("--disable-default-apps")
        options.add_argument("--disable-background-networking")
        options.add_argument("--incognito")
        driver.set_page_load_timeout(100)
        driver.set_script_timeout(100)
        driver.implicitly_wait(
            10)  # This will wait up to 10 seconds for elements to be found before throwing a NoSuchElementException

    def teardown():
        driver.quit()

    setup()
    yield driver
    teardown()


# exploring the how to invoke browser from conftest.py because right now getting an error of driver

# @pytest.fixture(scope="session")
# def setup_teardown_method(request):
#     def setup(browser):
#         if browser == "firefox":
#             options = webdriver.FirefoxOptions()
#             driver = webdriver.Remote(
#                 command_executor='http://127.0.0.1:4444/wd/hub',
#                 options=options
#             )
#             driver.maximize_window()
#             options.page_load_strategy = 'normal'
#             options.add_argument("disable-infobars")
#             options.add_argument("--disable-cache")
#             options.add_argument("--disable-extensions")
#             driver.set_page_load_timeout(30)
#             driver.set_script_timeout(30)
#         elif browser == "edge":
#             options = webdriver.EdgeOptions()
#             driver = webdriver.Remote(
#                 command_executor='http://127.0.0.1:4444/wd/hub',
#                 options=options
#             )
#             driver.maximize_window()
#             options.page_load_strategy = 'normal'
#             options.add_argument("disable-infobars")
#             options.add_argument("--disable-cache")
#             options.add_argument("--disable-extensions")
#             driver.set_page_load_timeout(30)
#             driver.set_script_timeout(30)
#         else:
#             options = webdriver.ChromeOptions()
#             driver = webdriver.Remote(
#                 command_executor='http://127.0.0.1:4444/wd/hub',
#                 options=options
#             )
#             driver.maximize_window()
#             options.page_load_strategy = 'normal'
#             options.add_argument("disable-infobars")
#             options.add_argument("--disable-cache")
#             options.add_argument("--disable-extensions")
#             options.add_argument('--no-sandbox')
#             options.add_argument('--disable-application-cache')
#             options.add_argument('--disable-gpu')
#             options.add_argument("--disable-dev-shm-usage")
#             options.add_argument("--homepage=about:blank")
#             options.add_argument("--no-default-browser-check")
#             options.add_argument("--no-first-run")
#             options.add_argument("--disable-sync")
#             options.add_argument("--disable-default-apps")
#             options.add_argument("--disable-background-networking")
#             options.add_argument("--incognito")
#             driver.set_page_load_timeout(30)
#             driver.set_script_timeout(30)
#         return driver
#
#     def teardown():
#         if driver is not None:
#             driver.quit()
#
#     setup(browser)
#     yield driver
#     teardown()
#
#
# def pytest_addoption(parser):  # This will get the value from CLI /hooks
#     parser.addoption("--browser")
#
#
# @pytest.fixture()
# def browser(request):  # This will return the Browser value to setup method
#     return request.config.getoption("--browser")
