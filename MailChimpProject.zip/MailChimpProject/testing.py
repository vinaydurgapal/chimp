def dynamic_mapping_teardown():
    sf_config = SF_Configuration(SalesForceBaseTest.driver)
    sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)
    sf_merge_mapping = SF_Merge_Field_Mapping(SalesForceBaseTest.driver)
    sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)
    sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                              "loader_xpath")),
                                            view="Side view : Configuration : Wait for loader to disappear ")
    sf_config.redirect_to_configuration_page(locator_strategy=By.XPATH,
                                             locator_value=str(
                                                 ConfigReader.locatorsReadConfig("configuration locators",
                                                                                 "config_name_xpath")),
                                             view="Side View : Configuration :")
    page_head = sf_cf_dash.return_page_heading(locator_strategy=By.XPATH,
                                               locator_value=str(
                                                   ConfigReader.locatorsReadConfig("dashboard locators",
                                                                                   "txt_heading_page_xpath"))
                                               , view="")
    sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                            locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                              "loader_xpath")),
                                            view="Side view : Configuration : Wait for loader to disappear ")
    if page_head.text == "Configuration":
        LogGen.logger.info("Configuration Page Opened Successfully!")
        sf_edit_config.edit_configuration(locator_strategy=By.XPATH,
                                          locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                            "btn_edit_config_xpath")),
                                          view="Side View : Configuration : Edit Configuration")
        sf_cf_dash.wait_for_loader_to_disappear(locator_strategy=By.XPATH,
                                                locator_value=str(ConfigReader.locatorsReadConfig("loader_locators",
                                                                                                  "loader_xpath")),
                                                view="Side view : Configuration : Wait for loader to disappear ")
        sf_merge_mapping.merge_field_mapping(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "lnk_mfm_xpath")),
                                             view="Side View : Configuration : Edit Configuration : Merge Field Mapping : ")
        sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_dm_xpath")),
                                 view="Side View : Configuration : Edit Configuration : Dynamic Mapping : Drop Down")
        sf_edit_config.drop_down(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("merge field mapping", "btn_dm_sub_drop_xpath")),
                                 view="Side View : Configuration : Edit Configuration : Dynamic Mapping : Sub Drop Down")
        sf_cf_dash.delete_button(locator_strategy=By.XPATH
                                 , locator_value=str(ConfigReader.locatorsReadConfig("merge field mapping", "btn_dm_delete_xpath"))
                                 , view="Side view : Campaigns : Delete Button")
        sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),view="Side view : Campaigns : Delete Button")

        # Get the validation message and check if it is 'Success'
        validation_txt = sf_edit_config.get_validation_message(locator_strategy=By.XPATH,
                                                                       locator_value=str(
                                                                           ConfigReader.locatorsReadConfig(
                                                                               "edit config locators",
                                                                               "txt_validation_xpath")),
                                                                       view="Side View : Configuration : Edit Configuration : General Setting : Validation Message")
        try:
            assert validation_txt.text == "Success"
            sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                       locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                         "btn_close_xpath")),
                                       view="Side View : Configuration : Edit Configuration : General Setting : Close Button")
        except Exception as e:
            # Close the modal after creating the lead of MailChimp subscriber
            sf_edit_config.close_modal(locator_strategy=By.XPATH,
                                       locator_value=str(ConfigReader.locatorsReadConfig("edit config locators",
                                                                                         "btn_close_xpath")),
                                       view="Side View : Configuration : Edit Configuration : General Setting : Close Button")
            sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
                ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
                              view="Side View : Configuration : Edit Configuration : General Setting :  Sure Ok Button"
                              )
            pytest.fail("Required Toggle field not Enabled successfully!")