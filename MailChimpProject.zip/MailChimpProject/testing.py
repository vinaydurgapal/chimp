from configparser import ConfigParser
import ast


def dataReadConfig(section, key):
    """
    To read static data present in config file
    Parameters:
    - section: Parsing the value from the section
    - key: Parsing key via a section

    Returns:
    - key value of the section
    """
    config = ConfigParser()
    config.read(
        "/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini")
    return config.get(section, key)


def test_loopfunction():
    data = dataReadConfig('setup prechecks', 'tag_mc_fields')
    print("data num", data)
    data_num = ast.literal_eval(data)
    for i in data_num:
        print("ini data ", i)


def test_loopfunctions():
    data = dataReadConfig('setup prechecks', 'tag_mc_fields')
    print("data num", data)
    data_num = eval(data)
    for i in data_num:
        print("ini data ", i)

#
# To achieve marking a message that prechecks are covered once they have passed and run at least once, you can introduce a tracking mechanism to store the status of each precheck function.
#
# Here is how you can modify your code:
#
# Introduce a dictionary to track the status of each precheck function. Initially, mark all functions as not covered.
# When a precheck function passes, update the status of that function to mark it as covered.
# Before running a precheck function, check if it has been marked as covered. If so, print a message indicating that the precheck is already covered.
# Here is an example of how you can implement this:
#
# Copy
# precheck_functions_status = {func: False for func in precheck_functions}
#
# # Inside the loop where precheck functions are executed
# for precheck_function in precheck_functions:
#     if precheck_functions_status[precheck_function]:
#         print(f"{precheck_function} is already covered.")
#         continue
#
#     if not prechecks_passed:
#         break
#
#     precheck_result = subprocess.run([...], capture_output=True)
#
#     if b'passed' in precheck_result.stdout.lower():
#         precheck_functions_status[precheck_function] = True
#         precheck_output.append(precheck_result.stdout)
#         print(f"{precheck_function} Passed. Details: {precheck_result.stdout.decode()}")
#     else:
#         # Retry logic remains the same
# By implementing this, you can track the coverage status of each precheck function and print a message if a precheck function is already covered.