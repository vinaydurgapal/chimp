import os
import configparser
import subprocess
import sys
import time


def check_docker_container(container_name):
    result = subprocess.run(['docker', 'ps', '-f', f'name={container_name}', '--format', '{{.Names}}'],
                            capture_output=True, text=True)
    return container_name in result.stdout.strip().split('\n')


def start_docker_container(container_name):
    subprocess.run(['docker', 'start', container_name])


def wait_for_docker_container(container_name, retries=5, delay=10):
    for i in range(retries):
        if check_docker_container(container_name):
            print(f"Docker container {container_name} is running.")
            return True
        print(f"Waiting for Docker container {container_name} to be ready...")
        time.sleep(delay)
    print(f"Failed to start Docker container {container_name} after {retries} retries.")
    return False


def ensure_docker_running(container_name):
    if not check_docker_container(container_name):
        print(f"Docker container {container_name} is not running. Starting the container...")
        start_docker_container(container_name)
        if not wait_for_docker_container(container_name):
            sys.exit(f"Failed to start Docker container {container_name}.")


def update_url_and_run_tests(sf_login_url):
    sf_login_url = f"{sf_login_url}"

    # Update the setup_url value in the ConfigurationData/data.ini file
    config = configparser.ConfigParser()
    config.read('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini')
    config.set('setup url', 'scratch_org_url', sf_login_url)

    with open('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini',
              'w') as configfile:
        config.write(configfile)

    os.system(f" --sf_login_url='{sf_login_url}'")


def run_scripts_in_order(config_file, container_name):
    config = configparser.ConfigParser()
    config.read(config_file)

    test_paths = [path for script, path in config['ExecutionOrder'].items()]
    print(test_paths)

    precheck_functions = [
        'test_pc_url_status',
    ]

    precheck_output = []
    prechecks_passed = True

    for precheck_function in precheck_functions:
        if not prechecks_passed:
            break

        ensure_docker_running(container_name)

        precheck_result = subprocess.run(
            ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
             '--html=Reports/reports.html', '--self-contained-html', '-k', precheck_function, test_paths[0]],
            capture_output=True)

        if b'passed' not in precheck_result.stdout.lower():
            retry_count = 0
            while retry_count < 1:
                ensure_docker_running(container_name)

                precheck_result = subprocess.run(
                    ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
                     '--html=Reports/reports.html', '--self-contained-html', '-k', precheck_function, test_paths[0]],
                    capture_output=True)
                if b'passed' in precheck_result.stdout.lower():
                    break
                retry_count += 1
                print(f"{precheck_function} Failed. Retrying...")
            if b'passed' not in precheck_result.stdout.lower():
                print(f"{precheck_function} Failed. Details: {precheck_result.stdout.decode()}")
                print(f"{precheck_function} Not Configured Correctly. Exiting.")
                prechecks_passed = False
        else:
            precheck_output.append(precheck_result.stdout)
            print(f"{precheck_function} Passed. Details: {precheck_result.stdout.decode()}")

    if prechecks_passed:
        test_paths = test_paths[1:]
        report_file = os.path.join('Reports', 'reports.html')
        with open(report_file, 'w') as f:
            f.write('<html><body>')
            f.write('<h1>Precheck Report</h1>')
            f.write('<ul>')
            for output in precheck_output:
                f.write(f'<li>{output.decode()}</li>')
            f.write('</ul>')
            f.write('<h2>All Tests Report</h2>')
        subprocess.call(
            ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
             '--html=Reports/reports.html', '--self-contained-html'] + test_paths)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python run.py <sf_login_url> <docker_container_name>")
        sys.exit(1)

    sf_login_url = sys.argv[1]
    container_name = sys.argv[2]

    update_url_and_run_tests(sf_login_url)
    run_scripts_in_order(
        '/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/script.ini',
        container_name)
