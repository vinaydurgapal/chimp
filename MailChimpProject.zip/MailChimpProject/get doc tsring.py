import inspect
import os

from TestCases.TC_SalesforceChimp.Test_Edit_Configurations.TC_EC_Real_Time_Setting import Test_EC_Real_Time_Setting


# import inspect
# import os
#
# def print_docstrings(directory):
#     for root, dirs, files in os.walk(directory):
#         for file in files:
#             if file.endswith('.py'):
#                 file_path = os.path.join(root, file)
#                 with open(file_path, 'r') as f:
#                     code = f.read()
#                     for name, obj in inspect.getmembers(
#                         compile(code, file_path, 'exec')):
#                         if inspect.isfunction(obj) or inspect.isclass(obj):
#                             docstring = inspect.getdoc(obj)
#                             if docstring:
#                                 print(f"{' ' * 4}{name}:")
#                                 print(f"{' ' * 8}{docstring.strip()}")
#
# # Usage example
# print_docstrings('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/TestCases')
#
# def generate_single_page_docstring(cls):
#     """
#     Generates a single page docstring for a class by concatenating the docstrings of its methods and attributes.
#
#     Parameters:
#         cls (type): The class for which to generate the docstring.
#
#     Returns:
#         str: The single page docstring.
#     """
#     docstring = cls.__doc__ + "\n\n"
#     for attr_name, attr_value in cls.__dict__.items():
#         if callable(attr_value):
#             docstring += f"{attr_name}\n{attr_value.__doc__}\n\n"
#     return docstring
#
# single_page_docstring = generate_single_page_docstring(Test_EC_Real_Time_Setting)
# print(single_page_docstring)