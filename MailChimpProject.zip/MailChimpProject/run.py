import os
import configparser
import subprocess
import sys
from colorama import Fore, Style

def update_url_and_run_tests(sf_login_url):
    """
    Update the setup_url value in the ConfigurationData/data.ini file.

    Args:
        sf_login_url (str): The Salesforce login URL to be updated.

    Returns:
        None
    """

    sf_login_url = f"{sf_login_url}"

    # Update the setup_url value in the ConfigurationData/data.ini file
    # For Now to run Recheck test case
    config = configparser.ConfigParser()
    config.read('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini')
    config.set('setup url', 'scratch_org_url', sf_login_url)

    with open('/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/data.ini',
              'w') as configfile:
        config.write(configfile)

    os.system(f" --sf_login_url='{sf_login_url}'")


def run_scripts_in_order(config_file):
    """
    Runs a series of test scripts in order based on a configuration file.

    :param config_file: The path to the configuration file.

    This function reads a configuration file and retrieves the paths to execute all tests. It then creates a list of precheck functions to be executed. The output of each precheck function is captured and stored in a list. If any precheck fails, the function breaks and prints the failure details. If all prechecks pass, the function creates an HTML report with the precheck output and runs the subsequent tests.

    The configuration file should be in the format of a ConfigParser object, with the 'ExecutionOrder' section containing the paths to execute all tests.

    The function uses the `subprocess` module to run the precheck functions and the subsequent tests.
    """
    # To the multiple test cases in the form of precheck functions
    # Create a ConfigParser object
    config = configparser.ConfigParser()
    # Read the configuration file
    config.read(config_file)

    # Get all paths to execute all tests
    test_paths = [path for script, path in config['ExecutionOrder'].items()]
    print(test_paths)
    # List of precheck functions
    precheck_functions = [
        'test_pc_url_status',
        #'test_pc_site_register',
        #'test_pc_site_enable',
        # 'test_pc_audience_mc',
        # 'test_pc_campaign_mc',
        # 'test_pc_segment_mc',
        # 'test_pc_tag_mc',
        # 'test_pc_group_mc'
        #
        # 'test_pc_contact_rt',
        # 'test_pc_campaign_rt',
        # 'test_pc_campaign_m_rt',
        # 'test_pc_tag_m_rt',
        # 'test_pc_segment_m_rt',
        # 'test_pc_group_m_rt',
        # 'test_pc_subscriber_m_rt'

    ]
    # Capture the output of the precheck functions
    precheck_output = []
    prechecks_passed = True  # Flag to track if all prechecks passed
    for precheck_function in precheck_functions:
        if not prechecks_passed:  # Skip prechecks if any previous precheck failed
            break

        precheck_result = subprocess.run(
            ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
             '--html=Reports/reports.html', '--self-contained-html', '-k', precheck_function, test_paths[0]],
            capture_output=True)
        # Reason : we used b 'passed ' in precheck_result.stdout.lower() because stdout of the subprocess is in bytes PASSED/
        if b'passed' not in precheck_result.stdout.lower():
            retry_count = 1
            while retry_count < 1:
                precheck_result = subprocess.run(
                    ['pytest', '--capture=sys', '-v', '--no-header', '--cache-clear', '--tb=short',
                     '--html=Reports/reports.html', '--self-contained-html', '-k', precheck_function,
                     test_paths[0]],
                    capture_output=True)
                if b'passed' in precheck_result.stdout.lower():
                    break
                retry_count += 1
                print(f"{precheck_function} Failed. Retrying...")
            print(f"{precheck_function} Failed. Details: {precheck_result.stdout.decode()}")
            print(f"{precheck_function} Not Configured Correctly. Exiting.")
            prechecks_passed = False
        else:
            precheck_output.append(precheck_result.stdout)
            print(f"{precheck_function} Passed. Details: {precheck_result.stdout.decode()}")

    if prechecks_passed:
        # If all precheck functions pass, run the subsequent tests
        test_paths = test_paths[1:]  # Skip the TC_Prechecks.py
        # Create the HTML report
        report_file = os.path.join('Reports', 'reports.html')
        with open(report_file, 'w') as f:
            f.write('<html><body>')
            f.write('<h1>Precheck Report</h1>')
            f.write('<ul>')
            for output in precheck_output:
                f.write(f'<li>{output}</li>')
            f.write('</ul>')
            f.write('<h2>All Tests Report</h2>')
        subprocess.call(
            ['pytest', '--capture=sys', '-v','--reruns=1', '--no-header', '--cache-clear', '--tb=short',
             '--html=Reports/reports.html', '--self-contained-html'] + test_paths)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("URL not provided !")
        sys.exit(1)

    sf_login_url = sys.argv[1]
    update_url_and_run_tests(sf_login_url)

    # Run the scripts in order
    run_scripts_in_order(
        '/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/ConfigurationData/script.ini')
