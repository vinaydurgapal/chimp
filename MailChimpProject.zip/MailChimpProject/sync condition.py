import pytest
from selenium.common import NoSuchElementException
from selenium.webdriver.common.by import By

from Pages.SalesforceChimp.SF_DashBoard.SF_CF_Dashboard_View import CF_Dashboard_View
from Pages.SalesforceChimp.SF_DashBoard.SF_Groups import SF_Groups
from Pages.SalesforceChimp.SF_DashBoard.SF_MailchimpContacts import SF_MailChimpContacts
from Pages.SalesforceChimp.SF_DashBoard.SF_Segments import SF_Segments
from Pages.SalesforceChimp.SF_DashBoard.SF_Tags import SF_Tags
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)
from Pages.SalesforceChimp.SF_DashBoard.SF_Configuration import SF_Configuration
from Pages.SalesforceChimp.SF_Edit_Configuration.SF_Sync_Conditions import (
    SF_Sync_Conditions,
)
from TestCases.Setup_Methods.SF_Setup_Methods.SF_Configuration_Setup_Methods.SF_Sync_Condition import (
    sync_condition_setup_method, sync_condition_contact_setup_method, sync_condition_lead_setup_method
)
from TestCases.TC_SalesforceChimp.BaseTest_SF import SalesForceBaseTest
from TestCases.Teardown_Methods.SF_Configuration_Teardown_Methods.SF_Sync_Condition import (
    sync_condition_teardown_segments_method,
    sync_condition_teardown_mailchimp_contacts_method,
    sync_condition_teardown_contact_method,
    sync_condition_teardown_lead_method,
    sync_condition_teardown_group_method,
    sync_condition_stop_teardown_segments_method,
    sync_condition_stop_teardown_mailchimp_contacts_method,
    sync_condition_stop_teardown_contact_method,
    sync_condition_stop_teardown_lead_method,
    sync_condition_stop_teardown_group_method,
)
from Utilities import ConfigReader


class Test_EC_Sync_Conditions(SalesForceBaseTest):

    # SETUP METHODS
    def setup_method(self, method):
        """
        Setup method to initialize classes and verify the page view of Configuration.

        This method initializes the SF_Configuration, CF_Dashboard_View, CF_Edit_Configuration,
        and SF_Sync_Conditions classes with the driver. It waits for the loader to disappear,
        redirects to the Sync Conditions page, retrieves the page heading, and verifies if the
        page is opened successfully.

        Parameters:
            method (function): The test method being executed.

        Returns:
            None
        """
        # Determine which setup method to call based on the test case
        contact_test_cases_ = ['test_stop_mailchimp_contact', 'test_stop_contact',
                               'test_allow_mailchimp_contact', 'test_allow_contact']
        lead_test_cases_ = ['test_stop_lead', 'test_allow_lead']
        test_case = method.__name__
        if test_case in contact_test_cases_:
            # Call the setup method specific to contact test cases
            sync_condition_contact_setup_method()
        elif test_case in lead_test_cases_:
            # Call the setup method specific to lead test cases
            sync_condition_lead_setup_method()
        else:
            # Call the generic setup method
            sync_condition_setup_method()

        # Initialize classes with the driver
        self.sf_config = SF_Configuration(SalesForceBaseTest.driver)  # Initialize SF_Configuration class
        self.sf_cf_dash = CF_Dashboard_View(SalesForceBaseTest.driver)  # Initialize CF_Dashboard_View class
        self.sf_edit_config = CF_Edit_Configuration(SalesForceBaseTest.driver)  # Initialize CF_Edit_Configuration class
        self.sf_sync = SF_Sync_Conditions(SalesForceBaseTest.driver)  # Initialize SF_Sync_Conditions class
        self.sf_segment = SF_Segments(SalesForceBaseTest.driver)  # Initialize SF_Segments class
        self.sf_mail_chimp_contact = SF_MailChimpContacts(SalesForceBaseTest.driver)  # Initialize SF_MailChimpContacts class
        self.sf_group = SF_Groups(SalesForceBaseTest.driver)  # Initialize SF_Groups class
        self.sf_tag = SF_Tags(SalesForceBaseTest.driver)  # Initialize SF_Tags class

    # TEARDOWN METHODS
    @staticmethod
    def teardown_method(method):
        """
        Perform teardown work for the test case.

        Args:
            method (function): The test method that is being torn down.

        This method checks the name of the test method and performs teardown work
        specific to the test_select_webhook_events test case.

        """
        # Get the name of the test method
        test_name = method.__name__
        # __name__ variable is a built-in variable that holds the name of the current module.
        # It is used to determine whether a module is being run as the main module or being imported as a module

        # If the test method is test_allow_segments, perform teardown work
        if test_name == "test_allow_segments":
            sync_condition_teardown_segments_method()

        # If the test method is test_allow_mailchimp_contact, perform teardown work
        elif test_name == "test_allow_mailchimp_contact":
            sync_condition_teardown_mailchimp_contacts_method()

        # If the test method is test_allow_contact, perform teardown work
        elif test_name == "test_allow_contact":
            sync_condition_teardown_contact_method()

        # If the test method is test_allow_group, perform teardown work
        elif test_name == "test_allow_group":
            sync_condition_teardown_group_method()

        # If the test method is test_allow_lead, perform teardown work
        elif test_name == "test_allow_lead":
            sync_condition_teardown_lead_method()

        # If the test method is test_stop_segments, perform teardown work
        elif test_name == "test_stop_segments":
            sync_condition_stop_teardown_segments_method()

        # If the test method is test_stop_mailchimp_contact, perform teardown work
        elif test_name == "test_stop_mailchimp_contact":
            sync_condition_stop_teardown_mailchimp_contacts_method()

        # If the test method is test_stop_contact, perform teardown work
        elif test_name == "test_stop_contact":
            sync_condition_stop_teardown_contact_method()

        # If the test method is test_stop_group, perform teardown work
        elif test_name == "test_stop_group":
            sync_condition_stop_teardown_group_method()

        # If the test method is test_stop_lead, perform teardown work
        elif test_name == "test_stop_lead":
            sync_condition_stop_teardown_lead_method()

     #@pytest.mark.skip
    def test_stop_segments(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Stop Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Set Value ",
            value="name segment",
        )

        # Add an icon
        self.sf_sync.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            try:
                # ------------------------------------------------
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments  : Wait for loader to disappear ",
                )
                self.sf_segment.redirect_to_segment_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("segment locators", "segment_name_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Segments ",
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_record_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments : Checkboxes",
                )

                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments :  RWait for loader to disappear ",
                )
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments : Mass Import ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments :  Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                self.sf_cf_dash.get_data_from_record(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig("segment locators",
                                                                                         "txt_name_label_list_xpath")),
                                                     view="Test Cases : Steps : Side View : Segments : Get Data From Record List"
                                                     , match_text="email segment")
            except (NoSuchElementException, NoSuchElementException):
                # Handle validation failure
                pytest.fail(
                    "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
                )
        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

     #@pytest.mark.skip
    # TODO: Validation Part is left due to conditional setup in the code
    def test_stop_mailchimp_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Stop Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.mailchimp_contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mailchimp_contact_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Wait for loader to disappear ",
        )
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
            value="Name",
        )
        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Set Value ",
            value="durgapalvinay4@gmail.com",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # try:
            #     # ------------------------------------------------
            #     # Wait for loader to disappear
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            #         ),
            #         view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
            #     )
            #     # Redirect to the Mailchimp Contacts page
            #     self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "mailchimp contact locators", "mailchimp_contact_name_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts :  Redirect to Mailchimp Contacts Page ",
            #     )
            #     # Wait for loader to disappear
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            #         ),
            #         view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
            #     )
            #     # Select Checkboxes
            #     self.sf_cf_dash.checkboxes(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_record_checkboxes_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Segments : Checkboxes",
            #     )
            #
            #     # Delete Button
            #     self.sf_cf_dash.delete_button(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_delete_xpath"
            #             )
            #         ),
            #         view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Delete Button",
            #     )
            #     # OK Button
            #     self.sf_cf_dash.ok_btn(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_ok_pop_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts : Delete Button : OK Button",
            #     )
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "loader_locators", "loader_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts :  RWait for loader to disappear ",
            #     )
            #     self.sf_cf_dash.mass_import(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_mass_import_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts : Mass Import ",
            #     )
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "loader_locators", "loader_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts :  Wait for loader to disappear ",
            #     )
            #     # Wait for Progress Bar
            #     self.sf_cf_dash.wait_for_progress_bar(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "progress_bar_xpath"
            #             )
            #         ),
            #     )
            #     self.sf_cf_dash.get_data_from_record_list(locator_strategy=By.XPATH,
            #                                               locator_value=str(
            #                                                   ConfigReader.locatorsReadConfig(
            #                                                       "mailchimp contact locators",
            #                                                       "txt_contact_label_list_xpath")),
            #                                               view="Test Cases : Steps : Side View : Mailchimp Contacts : Get Data From Record List"
            #                                               , match_text="durgapalvinay4@gmail.com")
            # except (NoSuchElementException, NoSuchElementException):
            #     # Handle validation failure
            #     pytest.fail(
            #         "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            #     )

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

     #@pytest.mark.skip
    # TODO: Validation Part is left due to conditional setup in the code
    def test_stop_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Stop Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_contact_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Contact ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_c_select_field_xpath")),
        #                           view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Select Field ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Email",
            value="Email",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Set Value ",
            value="durgapalvinay4@gmail.com",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # try:
            #     # ------------------------------------------------
            #     # Wait for loader to disappear
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            #         ),
            #         view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
            #     )
            #     # Redirect to the Mailchimp Contacts page
            #     self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "mailchimp contact locators", "mailchimp_contact_name_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts :  Redirect to Mailchimp Contacts Page ",
            #     )
            #     # Wait for loader to disappear
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            #         ),
            #         view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
            #     )
            #     # Select Checkboxes
            #     self.sf_cf_dash.checkboxes(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_record_checkboxes_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Segments : Checkboxes",
            #     )
            #
            #     # Delete Button
            #     self.sf_cf_dash.delete_button(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_delete_xpath"
            #             )
            #         ),
            #         view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Delete Button",
            #     )
            #     # OK Button
            #     self.sf_cf_dash.ok_btn(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_ok_pop_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts : Delete Button : OK Button",
            #     )
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "loader_locators", "loader_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts :  RWait for loader to disappear ",
            #     )
            #     self.sf_cf_dash.mass_import(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "btn_mass_import_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts : Mass Import ",
            #     )
            #     self.sf_cf_dash.wait_for_loader_to_disappear(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "loader_locators", "loader_xpath"
            #             )
            #         ),
            #         view="Test Cases : Steps : Side View : Mailchimp Contacts :  Wait for loader to disappear ",
            #     )
            #     # Wait for Progress Bar
            #     self.sf_cf_dash.wait_for_progress_bar(
            #         locator_strategy=By.XPATH,
            #         locator_value=str(
            #             ConfigReader.locatorsReadConfig(
            #                 "dashboard locators", "progress_bar_xpath"
            #             )
            #         ),
            #     )
            #     self.sf_cf_dash.get_data_from_record_list(locator_strategy=By.XPATH,
            #                                               locator_value=str(
            #                                                   ConfigReader.locatorsReadConfig(
            #                                                       "mailchimp contact locators",
            #                                                       "txt_contact_label_list_xpath")),
            #                                               view="Test Cases : Steps : Side View : Mailchimp Contacts : Get Data From Record List"
            #                                               , match_text="durgapalvinay4@gmail.com")
            # except (NoSuchElementException, NoSuchElementException):
            #     # Handle validation failure
            #     pytest.fail(
            #         "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            #     )

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Validation Failed"
            )

     #@pytest.mark.skip
    def test_stop_group(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Stop Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.groups(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Groups ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_select_field_xpath")),
        #                           view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Select Field ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Group Name",
            value="Group Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Set Value ",
            value="group category2",
        )
        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            try:
                # ------------------------------------------------
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
                )
                # Redirect to the Mailchimp Contacts page
                # Redirect to the Groups page
                self.sf_group.redirect_to_groups_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("group locators", "group_name_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Groups :",
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_record_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Checkboxes",
                )

                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups :  RWait for loader to disappear ",
                )
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Mass Import ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups :  Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                self.sf_cf_dash.get_data_from_record(locator_strategy=By.XPATH,
                                                     locator_value=str(
                                                         ConfigReader.locatorsReadConfig(
                                                             "segment locators",
                                                             "txt_name_label_list_xpath")),
                                                     view="Test Cases : Steps : Side View : Group : Get Data From Record List"
                                                     , match_text="group category1" or "group category2")
            except (NoSuchElementException, NoSuchElementException):
                # Handle validation failure
                pytest.fail(
                    "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
                )
        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

     #@pytest.mark.skip
    def test_stop_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.stop_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_stop_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Stop Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.lead(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_select_field_xpath")),
        #                           view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Select Field ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Email",
            value="Email",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Set Value ",
            value="durgapalvinay3@gmail.com",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            try:
                # ------------------------------------------------
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
                )
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Mailchimp Contacts :  Redirect to Mailchimp Contacts Page ",
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead  : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_record_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead : Checkboxes",
                )

                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead  : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead :  RWait for loader to disappear ",
                )
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead : Mass Import ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead :  Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                self.sf_cf_dash.get_data_from_record_list(locator_strategy=By.XPATH,
                                                          locator_value=str(
                                                              ConfigReader.locatorsReadConfig(
                                                                  "mailchimp contact locators",
                                                                  "txt_lead_label_list_xpath")),
                                                          view="Test Cases : Steps : Side View : Lead : Get Data From Record List"
                                                          , match_text="durgapalvinay3@gmail.com")
            except (NoSuchElementException, NoSuchElementException):
                # Handle validation failure
                pytest.fail(
                    "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Failed"
                )

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Failed"
            )

     #@pytest.mark.skip
    def test_allow_segments(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Allow Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Set Value ",
            value="name segment",
        )

        # Add an icon
        self.sf_sync.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_seg_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            try:
                # ------------------------------------------------
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments  : Wait for loader to disappear ",
                )
                self.sf_segment.redirect_to_segment_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("segment locators", "segment_name_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Segments ",
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_record_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments : Checkboxes",
                )

                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments :  RWait for loader to disappear ",
                )
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments : Mass Import ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Segments :  Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                self.sf_cf_dash.get_match_data_from_record_list(locator_strategy=By.XPATH,
                                                                locator_value=str(
                                                                    ConfigReader.locatorsReadConfig("segment locators",
                                                                                                    "txt_name_label_list_xpath")),
                                                                view="Test Cases : Steps : Side View : Segments : Get Data From Record List"
                                                                , match_text="name segment")
            except (NoSuchElementException, NoSuchElementException):
                # Handle validation failure
                pytest.fail(
                    "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
                )

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

     #@pytest.mark.skip
    # TODO: Validation Part is left due to conditional setup in the code
    def test_allow_mailchimp_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Allow Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.mailchimp_contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mailchimp_contact_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Wait for loader to disappear ",
        )
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Name",
            value="N",
        )
        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Set Value ",
            value="durgapalvinay4@gmail.com",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_mc_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button"
            #                            )
            # except (NoSuchElementException, NoSuchElementException):
            #     pass

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    # TODO: Validation Part is left due to conditional setup
     #@pytest.mark.skip
    def test_allow_contact(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Allow Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.contact(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_contact_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Contact ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )
        # Reason behind use this method select field is not directly accessible for that we have to hover on it
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Email",
            value="Email",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Set Value ",
            value="durgapalvinay4@gmail.com",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_c_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            # Marked Comment Because right now we do not need to close pop up modal , due to click on save  closes the pop up
            # If We need then only we will uncomment it
            # try:
            #     self.sf_edit_config.close_modal(locator_strategy=By.XPATH,
            #                                     locator_value=str(
            #                                         ConfigReader.locatorsReadConfig("edit config locators",
            #                                                                         "btn_close_xpath")),
            #                                     view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Close Button")
            #     self.sf_cf_dash.ok_btn(locator_strategy=By.XPATH, locator_value=str(
            #         ConfigReader.locatorsReadConfig("dashboard locators", "btn_cancel_sure_xpath")),
            #                            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button"
            #                            )
            # except (NoSuchElementException, NoSuchElementException):
            #     pass

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Contact : Validation Failed"
            )

     #@pytest.mark.skip
    def test_allow_group(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Allow Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.groups(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_groups_select_field_xpath")),
        #                           view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Select Field ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Group Name",
            value="Group",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Set Value ",
            value="group category2",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_groups_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            try:
                # ------------------------------------------------
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
                )
                # Redirect to the Mailchimp Contacts page
                # Redirect to the Groups page
                self.sf_group.redirect_to_groups_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("group locators", "group_name_xpath")
                    ),
                    view="Test Cases : Steps : Side View : Groups :",
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Groups  : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_record_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Checkboxes",
                )

                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups :  RWait for loader to disappear ",
                )
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups : Mass Import ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Groups :  Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                self.sf_cf_dash.get_match_data_from_record_list(locator_strategy=By.XPATH,
                                                                locator_value=str(
                                                                    ConfigReader.locatorsReadConfig(
                                                                        "segment locators",
                                                                        "txt_name_label_list_xpath")),
                                                                view="Test Cases : Steps : Side View : Group : Get Data From Record List"
                                                                , match_text="group category2" or "group category1")
            except (NoSuchElementException, NoSuchElementException):
                # Handle validation failure
                pytest.fail(
                    "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
                )

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Segments : Validation Failed"
            )

    #  #@pytest.mark.skip
    def test_allow_lead(self):
        """
        Test case to edit the configuration setting.

        This test case verifies that the configuration setting is successfully edited.

        Parameters:
            - None

        Returns:
            - None
        """
        self.sf_sync.allow_record_creation(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_allow_record_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Allow Record Creation ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )
        # Select the field
        self.sf_sync.lead(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead ",
        )
        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )
        # self.sf_sync.select_field(locator_strategy=By.XPATH, locator_value=str(
        #     ConfigReader.locatorsReadConfig("sync conditions", "btn_leads_select_field_xpath")),
        #                           view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Select Field ",
        #                           lst_locator_strategy=By.XPATH, lst_locator_value=str(
        #         ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")),
        #                           lst_view="Sync Conditions", match_text="Name")
        self.sf_sync.hover_and_select_field(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_field_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Select Field ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig("sync conditions", "lst_dropdown_xpath")
            ),
            lst_view="Sync Conditions",
            match_text="Email",
            value="Email",
        )

        # Select the operator
        self.sf_sync.select_operator(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_select_operator_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Select Operator ",
            lst_locator_strategy=By.XPATH,
            lst_locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "lst_select_operator_xpath"
                )
            ),
            lst_view="Sync Conditions",
            match_text="Equals",
        )

        # Set the value
        self.sf_sync.set_value(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_enter_val_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Set Value ",
            value="durgapalvinay4@gmail.com",
        )

        # Add an icon
        self.sf_edit_config.add_icon(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "sync conditions", "btn_leads_add_icon_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Add Icon ",
        )

        # Wait for loader to disappear
        self.sf_cf_dash.wait_for_loader_to_disappear(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Wait for loader to disappear ",
        )

        # Save the changes for lead mapping
        self.sf_edit_config.save_button(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "btn_save_and_close_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Save Button",
        )

        # Validate if the changes were successful
        validation_txt = self.sf_edit_config.get_validation_message(
            locator_strategy=By.XPATH,
            locator_value=str(
                ConfigReader.locatorsReadConfig(
                    "edit config locators", "txt_validation_xpath"
                )
            ),
            view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Message",
        )
        self.logger.info(
            f"Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Message : {validation_txt.text}"
        )
        try:
            assert validation_txt.text.startswith(
                "Success"
            ) or validation_txt.text.startswith(
                "Error"
            ) or validation_txt.text.startswith(
                "Duplicacy"
            ), f"Validation text '{validation_txt.text}' should start with 'Success' or 'Error'"
            try:
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Mailchimp Contact  : Wait for loader to disappear ",
                )
                # Redirect to the Mailchimp Contacts page
                self.sf_mail_chimp_contact.redirect_to_mailchimp_contacts_page(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "mailchimp contact locators", "mailchimp_contact_name_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Mailchimp Contacts :  Redirect to Mailchimp Contacts Page ",
                )
                # Wait for loader to disappear
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig("loader_locators", "loader_xpath")
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead  : Wait for loader to disappear ",
                )
                # Select Checkboxes
                self.sf_cf_dash.checkboxes(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_record_checkboxes_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead : Checkboxes",
                )

                # Delete Button
                self.sf_cf_dash.delete_button(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_delete_xpath"
                        )
                    ),
                    view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead  : Delete Button",
                )
                # OK Button
                self.sf_cf_dash.ok_btn(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_ok_pop_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead : Delete Button : OK Button",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead :  RWait for loader to disappear ",
                )
                self.sf_cf_dash.mass_import(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "btn_mass_import_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead : Mass Import ",
                )
                self.sf_cf_dash.wait_for_loader_to_disappear(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "loader_locators", "loader_xpath"
                        )
                    ),
                    view="Test Cases : Steps : Side View : Lead :  Wait for loader to disappear ",
                )
                # Wait for Progress Bar
                self.sf_cf_dash.wait_for_progress_bar(
                    locator_strategy=By.XPATH,
                    locator_value=str(
                        ConfigReader.locatorsReadConfig(
                            "dashboard locators", "progress_bar_xpath"
                        )
                    ),
                )
                self.sf_cf_dash.get_match_data_from_record_list(locator_strategy=By.XPATH,
                                                                locator_value=str(
                                                                    ConfigReader.locatorsReadConfig(
                                                                        "mailchimp contact locators",
                                                                        "txt_lead_label_list_xpath")),
                                                                view="Test Cases : Steps : Side View : Lead : Get Data From Record List"
                                                                ,
                                                                match_text="durgapalvinay4@gmail.com")
            except (NoSuchElementException, NoSuchElementException):
                # Handle validation failure
                pytest.fail(
                    "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Failed"
                )

        except (NoSuchElementException, NoSuchElementException):
            # Handle validation failure
            self.sf_edit_config.close_modal(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "edit config locators", "btn_close_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Close Button",
            )
            self.sf_cf_dash.ok_btn(
                locator_strategy=By.XPATH,
                locator_value=str(
                    ConfigReader.locatorsReadConfig(
                        "dashboard locators", "btn_cancel_sure_xpath"
                    )
                ),
                view="Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead :  Sure Ok Button",
            )
            pytest.fail(
                "Test Cases : Side View : Configuration : Edit Configuration : Sync Conditions : Lead : Validation Failed"
            )


print(Test_EC_Sync_Conditions.__doc__)