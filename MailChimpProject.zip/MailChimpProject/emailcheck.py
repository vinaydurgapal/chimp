import base64
import re
import requests

from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']


def authenticate(username, password,
                 client_secrets_file='/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/client_secrets_file.json'):
    flow = InstalledAppFlow.from_client_secrets_file(client_secrets_file, SCOPES)
    flow.run_local_server(port=8000)
    creds = flow.credentials
    creds.refresh(requests.Request())
    creds.token = (creds.token, password)
    return creds


def get_verification_codes(username, password):
    creds = authenticate(username, password)
    service = build('gmail', 'v1', credentials=creds)

    results = service.users().messages().list(userId='me', q='subject:"Your Verification Code"').execute()
    messages = results.get('messages', [])

    verification_codes = []

    if messages:
        for message in messages:
            message = service.users().messages().get(userId='me', id=message['id']).execute()
            message_body = message['payload']['body']['data']
            message_body = base64.urlsafe_b64decode(message_body.encode('ASCII')).decode('utf-8')
            verification_code = re.search(r'Your Verification Code is (\d+)', message_body)
            if verification_code:
                verification_codes.append(verification_code.group(1))
    return verification_codes

username = 'durgapalvinay32@gmail.com'
password = 'vinay@1234'

verification_codes = get_verification_codes(username, password)
print(verification_codes)