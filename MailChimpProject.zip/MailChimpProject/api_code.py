import base64
import re
import requests

from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']


def authenticate(username, password,
                 client_secrets_file='/home/users/vinay.durgapal/Documents/chimpConnector/MailChimpProject/client_secrets_file.json'):
    flow = InstalledAppFlow.from_client_secrets_file(client_secrets_file, SCOPES)
    flow.run_local_server(port=8000)
    creds = flow.credentials
    creds.refresh(requests.Request())
    creds.token = (creds.token, password)
    return creds


def get_verification_codes(username, password):
    creds = authenticate(username, password)
    service = build('gmail', 'v1', credentials=creds)

    results = service.users().messages().list(userId='me', q='subject:"Your Verification Code"').execute()
    messages = results.get('messages', [])

    verification_codes = []

    if messages:
        for message in messages:
            msg_id = message['id']
            msg_data = service.users().messages().get(userId='me', id=msg_id).execute()
            payload_headers_data_list = msg_data['payload']['headers']

            # Extracting verification code from email body or subject line based on email format

            # If verification code is present in email body text/plain format
            if msg_data['payload']['mimeType'] == 'text/plain':
                body_data_raw = msg_data['payload']['body']['data']
                _encoded_bytes = base64.urlsafe_b64decode(body_data_raw.encode("UTF8"))
                _decoded_text = _encoded_bytes.decode("UTF8")

                # Extracting numbers from decoded text assuming length of code is 6 digits
                numbers = re.findall(r'[0-9]{6}', _decoded_text)

                if numbers:
                    verification_codes.extend(numbers)

            # If verification code is present in email subject line text/html format
            elif msg_data['payload']['mimeType'] == 'text/html':
                subject_line = ''
                for i in payload_headers_data_list:
                    name = i['name']
                    value = i.get('value')

                    if name.lower() == 'subject':
                        subject_line = value
                        numbers = re.findall(r'[0-9]{6}', subject_line)

                        if numbers:
                            verification_codes.extend(numbers)

    return verification_codes


username = 'durgapalvinay32@gmail.com'
password = 'Vinay@1234'

verification_codes = get_verification_codes(username, password)
print(verification_codes)
