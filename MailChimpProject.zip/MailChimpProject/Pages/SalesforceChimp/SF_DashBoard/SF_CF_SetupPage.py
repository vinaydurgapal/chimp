import time

from selenium.webdriver.common.by import By
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from Utilities import ConfigReader


class SF_CF_SetupPage(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        super().__init__(driver)

    # common function to redirect to app page that's why we are  passing there locator strategy and locator value
    def redirect_to_app_page(self):
        """
        Redirects to the app page  from setup page by clicking on the nine dots icon and searching for "ChimpConnect".

        This function performs the following steps:
        1. Clicks on the nine dots icon using the XPATH locator strategy and the value obtained from the config file.
        2. Sends the text "ChimpConnect" to the search box using the XPATH locator strategy and the value obtained from the config file.
        3. Clicks on the "ChimpConnect" app name using the CSS locator strategy and the value obtained from the config file.

        Parameters:
        - self: The instance of the SF_Common_Function class.

        Returns:
        - None
        """
        time.sleep(5)  # Sleep for 5 seconds to wait for the page to load
        self.js_click_on_elm(
            locator_strategys=By.XPATH,
            locator_values=ConfigReader.locatorsReadConfig(
                "app common locators", "nine_dots_css"
            ),
            views="Home : Setup Page : ",
        )
        self.js_send_txt_to_elm(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "app common locators", "inpt_search_box_xpath"
            ),
            send_text="ChimpConnect",
            view="Home : Setup Page :  Search  ",
        )
        self.js_click_on_elm(
            locator_strategys=By.XPATH,
            locator_values=ConfigReader.locatorsReadConfig(
                "app common locators", "app_name_css"
            ),
            views="Home : Setup Page : Search : ChimpConnect : ",
        )

    # MailChimp is defined in this function as mc
    def add_mc_account(self):
        """
        Adds a MailChimp account.

        This function attempts to add a MailChimp account by clicking on a button located by its XPath.
        The XPath is obtained from the configuration file using the `locatorsReadConfig` method of the `ConfigReader` class.

        If the button is found and clicked successfully, the function logs a message indicating that the MailChimp account was added.
        If the button is not found, the function logs a message indicating that the MailChimp account is already added.

        """
        elem = self.sm_return_elm(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "app common locators", "btn_app_cred_xpath"
            ),
            view="ChimpConnect : Add Mail Chimp Account : ",
        )
        if elem:
            self.js_click_on_elm(
                locator_strategys=By.XPATH,
                locator_values=ConfigReader.locatorsReadConfig(
                    "app common locators", "btn_app_cred_xpath"
                ),
                views="ChimpConnect : Add Mail Chimp Account : ",
            )
        else:
            self.logger.info("Mail Chimp Account is already added !")

    def credentials_pop_up(self):
        """
        Clicks on the "Copy URI" button in the "Credentials pop up" section of the "Add Mail Chimp Account" view.

        This function uses the `js_click_on_elm` method to perform the click action. It takes the following parameters:
        - `locator_strategys`: The locator strategy to use for finding the element. In this case, it uses XPath.
        - `locator_values`: The locator value to find the element. It reads the value from the configuration file using the `ConfigReader.locatorsReadConfig` method.
        - `views`: The name of the view where the element is located. In this case, it is "ChimpConnect : Add Mail Chimp Account : Credentials pop up : Copy URI".

        This function does not return any value.
        """
        self.js_click_on_elm(
            locator_strategys=By.XPATH,
            locator_values=ConfigReader.locatorsReadConfig(
                "app common locators", "btn_app_cred_xpath"
            ),
            views="ChimpConnect : Add Mail Chimp Account : Credentials pop up : Copy URI",
        )
