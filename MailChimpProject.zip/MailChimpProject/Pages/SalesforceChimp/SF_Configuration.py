

from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium


class SF_Configuration(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce Configuration.
    This class inherits from `SalesForceBaseTest` and provides
    additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        super().__init__(driver)

    def redirect_to_configuration_page(self, locator_strategy, locator_value, view):
        """
        Clicks on an element on the Salesforce configuration page.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        Notes:
            - This method uses JavaScript to click on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
