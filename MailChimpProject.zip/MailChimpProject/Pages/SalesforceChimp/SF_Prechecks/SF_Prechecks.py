import ast
import time

import pytest
import requests
from selenium.common import StaleElementReferenceException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from Utilities import ConfigReader


class SF_Prechecks(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    def __init__(self, driver):
        super().__init__(driver)

    def check_url_status(self):
        """
        Check the status of a URL by sending a GET request and logging the result.

        Returns:
            bool: True if the URL is active (status code 200), False otherwise.
        """
        try:
            response = requests.get(
                ConfigReader.dataReadConfig("setup url", "scratch_org_url")
            )
            if response.status_code == 200:
                self.logger.info(f"URL is  active. Status code: {response.status_code}")
                return True
            else:
                pytest.fail(f"URL is not active. Status code: {response.status_code}")

        except Exception as e:
            self.logger.error(f"An error occurred while checking URL: {e}")
            return False

    # Common Function
    def quick_find(self, send_text, view):
        """
        Send text to the quick find element on the specified view.

        Args:
            send_text (str): The text to send to the quick find element.
            view (str): The view on which to perform the quick find.

        Returns:
            None
        """
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_send_txt_to_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "salesforce prechecks locators", "quick_find_css"
            ),
            send_text=send_text,
            view=view,
        )

    def site_select_and_register(self):
        """
        Register a site by performing the necessary steps in the site setup process.

        This function clicks on elements, switches to iframes, interacts with checkboxes,
        and validates the registration process.

        Returns:
            None
        """
        # Implementation of the site selection and registration process
        # Objective : Registering the site
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_click_on_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "setup_site_css"
            ),
            view="Home : Site : ",
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "setup_site_iframe_css"
            ),
            view="Home : Site : Site Setup : Iframe : ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "setup_site_iframe_css"
            ),
            view="Home : Site : Site Setup : Iframe : ",
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        element_presence = self.return_elm_from_root_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "site_setup_form_css"
            ),
            view="Home : Site : Site Setup : Form:  ",
            elm_locator_strategy=By.CSS_SELECTOR,
            elm_locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "site_terms_use_css"
            ),
            elm_view="Home : Site : Site Setup : Form : Terms of Use Checkbox",
        )
        if element_presence is not None:
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_get_the_elm_from_the_root_and_clk(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "site_setup_form_css"
                ),
                view="Home : Site : Site Setup : Form:  ",
                elm_locator_strategy=By.CSS_SELECTOR,
                elm_locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "site_terms_use_css"
                ),
                elm_view="Home : Site : Site Setup : Terms of Use Checkbox",
            )
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_get_the_elm_from_the_root_and_clk(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "site_setup_form_css"
                ),
                view="Home : Site : Site Setup : Form : ",
                elm_locator_strategy=By.CSS_SELECTOR,
                elm_locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "site_register_btn_css"
                ),
                elm_view="Home : Site : Site Setup : Site Register",
            )
            validation_text = self.sm_alerts_acceptance()
            self.logger.info(
                f"Home : Site : Site Setup : Form : Validation Text : {validation_text}"
            )
            if (
                "Once you register, you will not be able to modify your Salesforce site domain name. Are you sure?"
                in validation_text
            ):
                self.logger.info("Home : Site : Site Setup : Form : Site is registered")
            else:
                pytest.fail("Home : Site : Site Setup : Form : Site is not registered")
        else:
            self.logger.info(
                "Home : Site : Site Setup : Form : Site is already registered"
            )

    def site_select_and_enable(self):
        """
        Enables the site by performing the following steps:
        1. Clicks on the setup site element.
        2. Switches to the iframe.
        3. Switches back to the default content.
        4. Switches to the iframe again.
        5. Checks if the site is already enabled.
        6. If not enabled, performs the following steps:
            a. Clicks on the new form button.
            b. Switches back to the default content.
            c. Switches to the iframe.
            d. Sends text to the site label input field.
            e. Clicks on the site name input field.
            f. Checks the active checkbox.
            g. Sends text to the active site page input field.
            h. Clicks on the save button.
            i. Switches back to the default content.
            j. Switches to the iframe again.
            k. Waits for the validation text to appear.
            l. Returns the validation text.
        7. If the site is already enabled, logs a message and returns a string indicating that.
        """
        # Objective : Enabling the site
        self.sm_click_on_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "setup_site_css"
            ),
            view="Home : Site : ",
        )
        #         # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "setup_site_iframe_css"
            ),
            view="Home : Site : Site Setup : Iframe : ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "setup_site_iframe_css"
            ),
            view="Home : Site : Site Setup : Iframe : ",
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        elm_attribute = self.sm_elm_attribute(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "site enable locators", "site_active_css"
            ),
            view="Home : Site : Site Setup : Form: ",
            attribute_value="alt",
        )
        # self.logger.info("elm_attribute :" + elm_attribute)  # only string is concatenated none not
        self.logger.info(f"Attribute of the element : {elm_attribute}")
        if elm_attribute is None:
            time.sleep(
                5
            )  # for now using time sleep Reason: need to hold the page to load the frame completely
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_get_the_elm_from_the_root_and_clk(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "btn_new_form_css"
                ),
                view="Home : Site : Site Setup : Form: ",
                elm_locator_strategy=By.CSS_SELECTOR,
                elm_locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "btn_new_css"
                ),
                elm_view="Home : Site : Site Setup : Form : New :",
            )

            self.driver.switch_to.default_content()
            time.sleep(
                5
            )  # for now using time sleep Reason: need to hold the page to load the frame completely
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_switch_to_iframe(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "setup_site_iframe_css"
                ),
                view="Home : Site : Site Setup : Iframe : ",
            )
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_send_txt_to_elm(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "txt_site_label_css"
                ),
                send_text=ConfigReader.dataReadConfig(
                    "setup prechecks", "site_label_txt"
                ),
                view="Home : Site : Site Setup : Form : New : Site Edit : site label",
            )
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_click_on_elm(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "txt_site_name_css"
                ),
                view="Home : Site : Site Setup : Form : New : Site Edit : site name",
            )
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_click_on_elm(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "cb_tive_site_css"
                ),
                view="Home : Site : Site Setup : Form : New : Site Edit : active checkbox",
            )
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_send_txt_to_elm(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "txt_active_site_page_css"
                ),
                send_text=ConfigReader.dataReadConfig(
                    "setup prechecks", "active_site_home_page"
                ),
                view="Home : Site : Site Setup : Form : New : Site Edit : site label",
            )
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_click_on_elm(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "save_btn_css"
                ),
                view="Home : Site : Site Setup : Form : New : Site Edit : Save :",
            )
            self.driver.switch_to.default_content()
            time.sleep(
                5
            )  # for now using time sleep Reason: need to hold the page to load the frame completely
            # For Common locators here I didn't pass any locator strategy and value from test case file
            self.sm_switch_to_iframe(
                locator_strategy=By.XPATH,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "setup_site_iframe_css"
                ),
                view="Home : Site : Site Setup : Iframe : ",
            )
            time.sleep(
                5
            )  # for now using time sleep Reason: need to hold the page to load the frame completely
            # For Common locators here I didn't pass any locator strategy and value from test case file
            elm_verification = self.js_get_vld_txt(
                locator_strategy=By.CSS_SELECTOR,
                locator_value=ConfigReader.locatorsReadConfig(
                    "site enable locators", "txt_site_vld_css"
                ),
                view="Home : Site : Site Setup : Form : New : Site Edit : Validation :",
            )
            return elm_verification

        else:
            self.logger.info("Site is already enabled")
            return "Site is already enabled"

    # Object Related Precheck
    # Common Function
    def select_object_manager(self, send_text=None, view=None):
        """The select_object_manager function seems to be interacting with elements on a web page.
        It uses the js_click_on_elm and sm_send_txt_to_elm methods to perform actions like clicking
        and sending text to specific elements on the page. The function takes optional parameters
        send_text and view. The locator_value for these actions is retrieved from a config file using
        ConfigReader.locatorsReadConfig.
        """
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.js_click_on_elm(
            locator_strategys=By.CSS_SELECTOR,
            locator_values=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "lnk_object_manager_css"
            ),
            views="Home : Page Layout : Object Manager : ",
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_send_txt_to_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "txt_quick_find_css"
            ),
            send_text=send_text,
            view=view,
        )

    # Element name should be defined as such:
    # page_layout as pl
    def switch_iframe_functionality(self, locator_strategy, locator_value, view):
        """The objective of the switch_iframe_functionality function is to switch the focus of the Selenium WebDriver to
        an iframe based on the provided locator strategy, locator value, and view. It achieves this by calling
         the sm_switch_to_iframe method with the provided parameters."""
        self.sm_switch_to_iframe(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def setup_object_manager_functionality(
        self, locator_strategy, locator_values, view, required_text=None
    ):
        """
        The setup_object_manager_functionality function is designed to repeatedly attempt to click on list items until finding the one with
        the required text.
        It uses a maximum of 5 retries with a 2-second interval between retries. If the required text is found in the list item text,
        it logs a success message and clicks on the item. It handles StaleElementReferenceException exceptions by retrying the process.
        Additionally, if after 5 retries the element is still not found, it logs a message indicating that the element was not stored successfully.
        """
        # aggressively click on the list items for that we need to hold the page until the list is loaded completely otherwise it gives an error
        max_retries = 5
        retry_interval = 2

        for _ in range(max_retries):
            time.sleep(retry_interval)
            storing_list = self.sm_return_list_of_elms(
                locator_strategy=locator_strategy,
                locator_value=locator_values,
                view=view,
            )

            for storing_elm in storing_list:
                try:
                    if str(required_text) == storing_elm.text:
                        self.logger.info(
                            f"{view} : {storing_elm.text} : Clicked Successfully"
                        )
                        storing_elm.click()
                        break
                except StaleElementReferenceException:
                    storing_list = self.sm_return_list_of_elms(
                        locator_strategy=locator_strategy,
                        locator_value=locator_values,
                        view=view,
                    )
                    for storing_elms in storing_list:
                        try:
                            if str(required_text) in storing_elm.text:
                                self.logger.info(
                                    f"{view} : {storing_elms.text} : Clicked Successfully"
                                )
                                storing_elms.click()
                                break
                        except StaleElementReferenceException:
                            pass
            else:
                continue

            # Break out of the outer loop if an element is successfully stored
            break
        else:
            self.logger.info("Element not stored after 5 retries..............")

    # Not in use yet but latter I will use it
    def audience_mailchimp_pc_root_elm(
        self,
        locator_strategy,
        locator_values,
        view,
        elm_locator_strategy,
        elm_locator_value,
        elm_view,
        required_text=None,
    ):
        # Objective: Audience:Mailchimp Custom Object
        # Verify the Audience:Mailchimp page layout functionality
        # Verify the Audience:Mailchimp related list
        """Verify the Audience:Mailchimp page layout functionality and related list.

        Args:
            elm_view:  The view where the action is taking place.
            elm_locator_value: The strategy to locate the element.
            elm_locator_strategy:
            locator_values:
            locator_strategy (str): The strategy to locate the element.
            view (str): The view where the action is taking place.
            required_text (str, optional): The text required for verification. Defaults to None.
        """
        self.wait_for_page_load()
        storing_list = self.return_elms_from_root_elm(
            locator_strategy=locator_strategy,
            locator_value=locator_values,
            view=view,
            elm_locator_strategy=elm_locator_strategy,
            elm_locator_value=elm_locator_value,
            elm_view=elm_view,
        )
        for storing_elm in storing_list:
            try:
                if str(required_text) in storing_elm.text:
                    self.driver.execute_script("arguments[0].click();", storing_elm)
                    self.logger.info(
                        f"{view} : {storing_elm.text} : Clicked Successfully"
                    )
                    break
            except StaleElementReferenceException:
                try:
                    if str(required_text) in storing_elm.text:
                        self.driver.execute_script("arguments[0].click();", storing_elm)
                        self.logger.info(
                            f"{view} : {storing_elm.text} : Clicked Successfully"
                        )
                        break
                except StaleElementReferenceException:
                    pass

    def audience_mailchimp_pcs(self, locator_strategy, locator_value, view):
        """ " """
        time.sleep(5)
        max_retries = 3
        retry_count = 0
        while retry_count < max_retries:
            try:
                self.sm_click_on_elm(locator_strategy, locator_value, view)
                break  # Exit the loop if successful
            except StaleElementReferenceException:
                retry_count += 1
                if retry_count == max_retries:
                    # Log an error or handle the exception after max retries
                    print("Max retries reached. Unable to click on the element.")
                else:
                    # Retry the action
                    print("Retrying to click on the element...")

    def audience_mailchimp_fields(self, locator_strategy, locator_value, view):
        """
        The objective of the audience_mailchimp_fields method is to retrieve the
         text from elements identified by the provided locator_strategy and
         locator_value and store this text in a list named fields_level_data.
          Finally, it returns this list of text data.

        """
        fields_level_data = []
        storing_list = self.sm_return_list_of_elms(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        for storing_elm in storing_list:
            field_txt = storing_elm.text
            fields_level_data.append(field_txt)
        return fields_level_data

    def drag_and_drop_functionality(
        self,
        locator_strategy,
        locator_value,
        view,
        s_locator_strategy,
        s_locator_value,
        s_view,
        c_locator_strategy,
        c_locator_value,
        c_view,
        qb_locator_strategy,
        qb_locator_value,
        qb_view,
        expected_data=None,
    ):
        """The objective of the drag_and_drop_functionality function is to perform a drag-and-drop action on a web page.
        It switches to the default content of the webpage, retrieves elements based on provided locators, scrolls the page,
        and then simulates a drag and drop action from a source element to a target element. The function also handles exceptions
        like StaleElementReferenceException during the drag and drop operation.
        :param
            locator_strategy: The strategy to locate the element.
            locator_value: The value of the locator.
            view: The view where the action is taking place.
            s_locator_strategy: The strategy to locate the source element.
            s_locator_value: The value of the source locator.
            s_view: The view where the source element is located.
            c_locator_strategy: The strategy to locate the target element.
            c_locator_value: The value of the target locator.
            c_view: The view where the target element is located.
            expected_data: The expected data to be stored in the target element.
        """
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Audience:Mailchimp : Page Layout : ",
        )
        target_element = self.sm_return_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        x_offset = target_element.location_once_scrolled_into_view["x"]
        y_offset = target_element.location_once_scrolled_into_view["y"]
        expected_list = expected_data
        ini_data = ast.literal_eval(expected_list)
        for expected_title in ini_data:
            try:
                source_elements = self.sm_return_list_of_elms(
                    locator_strategy=s_locator_strategy,
                    locator_value=s_locator_value,
                    view=s_view,
                )
                for source_element in source_elements:
                    actual_title = source_element.text
                    if actual_title == expected_title:
                        self.logger.info(f"Trying to drag the element: {actual_title}")
                        container = self.sm_return_list_of_elms(
                            locator_strategy=c_locator_strategy,
                            locator_value=c_locator_value,
                            view=c_view,
                        )
                        scroll_amount = 1000
                        self.driver.execute_script(
                            f"arguments[0].scrollLeft += {scroll_amount};", container
                        )
                        try:
                            actions = ActionChains(self.driver)
                            actions.key_down(Keys.SHIFT)
                            actions.click(source_element)
                            actions.key_up(Keys.SHIFT)
                            actions.click_and_hold(source_element)
                            actions.move_by_offset(x_offset, y_offset)
                            actions.release(target_element)
                            actions.perform()
                        except StaleElementReferenceException:
                            self.logger.info(
                                "Stale element reference encountered during drag and drop. Retrying..."
                            )
                            continue
            except StaleElementReferenceException:
                self.logger.info(
                    "Stale element reference encountered. Continuing with the loop."
                )
                continue
            self.sm_move_and_click_on_elm(
                locator_strategy=qb_locator_strategy,
                locator_value=qb_locator_value,
                view=qb_view,
            )
        self.sm_move_and_click_on_elm(
            locator_strategy=qb_locator_strategy,
            locator_value=qb_locator_value,
            view=qb_view,
        )

    # Elements define here
    # Lable_: l_locator_value, l_view , l_locator_strategy , l_send_text
    # Name_ : n_locator_value, n_view , n_locator_strategy , n_send_text
    # Next_ : nx_locator_value, nx_view , nx_locator_strategy
    # Select Record Type : srt_locator_value, srt_view , srt_locator_strategy , srt_send_text
    def custome_record_types_enabled(
        self,
        locator_strategy,
        locator_value,
        view,
        l_locator_strategy,
        l_locator_value,
        l_view,
        l_send_text=None,
        n_locator_strategy=None,
        n_locator_value=None,
        n_view=None,
        n_send_text=None,
        nx_locator_strategy=None,
        nx_locator_value=None,
        nx_view=None,
        srt_locator_strategy=None,
        srt_locator_value=None,
        srt_view=None,
        srt_send_text=None,
    ):
        """
        The objective of the record_types_enabled function is to interact with various elements on a webpage related to record types.
        This includes clicking on elements, switching to iframes, sending text to elements, and selecting record types based on the provided
         parameters. The function also involves logging information about the actions performed.

        :param locator_strategy: The locator strategy used to locate an element on the webpage.
        :param locator_value: The value of the locator used to locate an element on the webpage.
        :param view: The view in which the element is located on the webpage.
        :param l_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param l_locator_value: The value of the locator used to locate an element on the webpage.
        :param l_view: The view in which the element is located on the webpage.
        :param l_send_text: The text to be sent to the element.
        :param n_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param n_locator_value: The value of the locator used to locate an element on the webpage.
        :param n_view: The view in which the element is located on the webpage.
        :param n_send_text: The text to be sent to the element.
        :param nx_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param nx_locator_value: The value of the locator used to locate an element on the webpage.
        :param nx_view: The view in which the element is located on the webpage.
        :param srt_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param srt_locator_value: The value of the locator used to locate an element on the webpage.
        :param srt_view: The view in which the element is located on the webpage.
        :param srt_send_text: The text to be sent to the element.
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.sm_send_txt_to_elm(
            locator_strategy=l_locator_strategy,
            locator_value=l_locator_value,
            view=l_view,
            send_text=l_send_text,
        )
        self.sm_send_txt_to_elm(
            locator_strategy=n_locator_strategy,
            locator_value=n_locator_value,
            view=n_view,
            send_text=n_send_text,
        )
        self.sm_click_on_elm(
            locator_strategy=nx_locator_strategy,
            locator_value=nx_locator_value,
            view=nx_view,
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        select_record_type_layout = Select(
            self.sm_return_elm(
                locator_strategy=srt_locator_strategy,
                locator_value=srt_locator_value,
                view=srt_view,
            )
        )
        select_record_type_layout.select_by_visible_text(srt_send_text)
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_click_on_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "btn_save_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager : Record Types : New : Select Record Type : Save Button ",
        )
        # # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        record_type_name = self.sm_return_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "validation_msg_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager : Record Types : New : Select Record Type : Save Button : Page Description ",
        )
        # get the record type name from data ini file
        expected_record_type = ConfigReader.dataReadConfig(
            "setup prechecks", "listed_record_type"
        )
        ini_data = ast.literal_eval(expected_record_type)
        self.logger.info(f"data info from ini file :{ini_data}")
        self.logger.info(f"record type name from ini file :{record_type_name.text}")
        # if str(ini_data) in record_type_name.text:
        #     self.logger.info(f"{srt_send_text}Record type is created successfully")
        # else:
        #     pytest.fail("Record type is not created successfully")

    def standard_record_types_enabled(
        self,
        locator_strategy,
        locator_value,
        view,
        l_locator_strategy,
        l_locator_value,
        l_view,
        l_send_text=None,
        n_locator_strategy=None,
        n_locator_value=None,
        n_view=None,
        n_send_text=None,
        nx_locator_strategy=None,
        nx_locator_value=None,
        nx_view=None,
        srt_locator_strategy=None,
        srt_locator_value=None,
        srt_view=None,
        srt_send_text=None,
    ):
        """
        The objective of the record_types_enabled function is to interact with various elements on a webpage related to record types.
        This includes clicking on elements, switching to iframes, sending text to elements, and selecting record types based on the provided
         parameters. The function also involves logging information about the actions performed.

        :param locator_strategy: The locator strategy used to locate an element on the webpage.
        :param locator_value: The value of the locator used to locate an element on the webpage.
        :param view: The view in which the element is located on the webpage.
        :param l_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param l_locator_value: The value of the locator used to locate an element on the webpage.
        :param l_view: The view in which the element is located on the webpage.
        :param l_send_text: The text to be sent to the element.
        :param n_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param n_locator_value: The value of the locator used to locate an element on the webpage.
        :param n_view: The view in which the element is located on the webpage.
        :param n_send_text: The text to be sent to the element.
        :param nx_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param nx_locator_value: The value of the locator used to locate an element on the webpage.
        :param nx_view: The view in which the element is located on the webpage.
        :param srt_locator_strategy: The locator strategy used to locate an element on the webpage.
        :param srt_locator_value: The value of the locator used to locate an element on the webpage.
        :param srt_view: The view in which the element is located on the webpage.
        :param srt_send_text: The text to be sent to the element.
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.sm_send_txt_to_elm(
            locator_strategy=l_locator_strategy,
            locator_value=l_locator_value,
            view=l_view,
            send_text=l_send_text,
        )
        self.sm_send_txt_to_elm(
            locator_strategy=n_locator_strategy,
            locator_value=n_locator_value,
            view=n_view,
            send_text=n_send_text,
        )
        self.sm_click_on_elm(
            locator_strategy=nx_locator_strategy,
            locator_value=nx_locator_value,
            view=nx_view,
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        select_record_type_layout = Select(
            self.sm_return_elm(
                locator_strategy=srt_locator_strategy,
                locator_value=srt_locator_value,
                view=srt_view,
            )
        )
        select_record_type_layout.select_by_visible_text(srt_send_text)
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_click_on_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "btn_save_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager : Record Types : New : Select Record Type : Save Button ",
        )

        # # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        # For Common locators here I didn't pass any locator strategy and value from test case file
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        self.driver.switch_to.default_content()
        self.logger.info(
            "function is used to switch back to the default content of the webpage"
        )
        self.sm_switch_to_iframe(
            locator_strategy=By.XPATH,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "iframe_layout_xpath"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager: Iframe ",
        )
        record_type_name = self.sm_return_elm(
            locator_strategy=By.CSS_SELECTOR,
            locator_value=ConfigReader.locatorsReadConfig(
                "Object manager page layout locators", "validation_msg_css"
            ),
            view="Home : Page Layout : Object Manager : Setup: Object Manager : Record Types : New : Select Record Type : Save Button : Page Description ",
        )
        # get the record type name from data ini file
        expected_record_type = ConfigReader.dataReadConfig(
            "setup prechecks", "listed_record_type"
        )
        ini_data = ast.literal_eval(expected_record_type)
        self.logger.info(f"data info from ini file :{ini_data}")
        self.logger.info(f"record type name from ini file :{record_type_name.text}")
        # if str(ini_data) in record_type_name.text:
        #     self.logger.info(f"{srt_send_text}Record type is created successfully")
        # else:
        #     pytest.fail("Record type is not created successfully")
