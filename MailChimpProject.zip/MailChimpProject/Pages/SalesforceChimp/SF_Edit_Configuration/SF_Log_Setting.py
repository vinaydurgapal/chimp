from selenium.common import NoSuchElementException, StaleElementReferenceException, ElementClickInterceptedException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC


class Sf_Log_Setting(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        """
        Initializes the CF_Edit_Configuration class.

        Args:
            driver (WebDriver): The Selenium WebDriver instance.
        """
        super().__init__(driver)

    def Log_setting(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on an element based on the provided locator strategy and value.

        Args:
            locator_strategy (str): The strategy used for locating the element.
            locator_value (str): The value used with the locator strategy to locate the element.
            view (str): The view or context where this action is being performed.

        Returns:
            None
        """
        try:
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )
        except (StaleElementReferenceException, NoSuchElementException,ElementClickInterceptedException):
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )

    def number_of_days(
        self, locator_strategy: str, locator_value: str, view: str, send_text: str
    ) -> None:
        """
        Sends text to the element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy used for locating the element.
            locator_value (str): The value used with the locator strategy to locate the element.
            view (str): The view or context where this action is being performed.
            send_text (str): The text to be sent to the element.

        Returns:
            None
        """
        # Call the method to send text to the element
        self.sm_send_txt_to_elm(
            locator_strategy=locator_strategy,
            locator_value=locator_value,
            view=view,
            send_text=send_text,
        )

    def create_webhook_log(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on the element identified by the provided locator strategy and value.

        Args:
            locator_strategy (str): The strategy used to locate the element.
            locator_value (str): The value used with the locator strategy to locate the element.
            view (str): The view or context where this action is being performed.

        Returns:
            None
        """

        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def select_webhook_events(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> list:
        """
        Selects webhook events by returning a list of elements identified by the provided locator strategy and value.

        Args:
            locator_strategy (str): The strategy used to locate the elements.
            locator_value (str): The value used with the locator strategy to locate the elements.
            view (str): The view or context where this action is being performed.

        Returns:
            list: A list of elements identified by the locator strategy and value.
        """
        # Call the method to return a list of elements
        elem = self.sm_return_list_of_elms(
            locator_strategy=locator_strategy,  # The strategy used to locate the elements
            locator_value=locator_value,  # The value used with the locator strategy to locate the elements
            view=view,  # The view or context where this action is being performed
        )
        return elem

    def move_from_available_to_selected(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Moves an element from the available section to the selected section by clicking on it.

        Args:
            locator_strategy (str): The strategy used for locating the element.
            locator_value (str): The value used with the locator strategy to locate the element.
            view (str): The view or context where this action is being performed.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
