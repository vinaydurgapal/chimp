import time

from selenium.common import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC

from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import (
    CF_Edit_Configuration,
)


# class SF_Sync_Conditions(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium, CF_Edit_Configuration):
class SF_Sync_Conditions(
    CF_Edit_Configuration, ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
):
    # class definition
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        """
        Initializes the CF_Edit_Configuration class.
        Args:
            driver (WebDriver): The Selenium WebDriver instance.
        """
        super().__init__(driver)

    def sync_conditions(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Click on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None

        This function takes in three parameters: locator_strategy, locator_value, and view.
        It uses these parameters to locate and click on an element on the webpage.
        The locator_strategy parameter specifies the strategy to use for locating the element,
        while the locator_value parameter provides the value to use for locating the element.
        The view parameter specifies the view to display before clicking on the element.

        The function does not return anything.
        """
        # Click on the element identified by the given locator strategy and value
        try:
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )
        except StaleElementReferenceException:
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )

    def segments(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on a segment element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the segment element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def mailchimp_contact(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on a MailChimp contact element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def contact(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Click on a contact element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        # Click on the contact element using the specified locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def lead(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on a lead element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the lead element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def groups(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on a group element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the group element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def allow_record_creation(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        This function is used to allow the record creation.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def stop_record_creation(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        This function is used to stop the record creation.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def select_field(
        self,
        locator_strategy: str,
        locator_value: str,
        view: str,
        lst_locator_strategy: str,
        lst_locator_value: str,
        lst_view: str,
        match_text: str,
    ) -> None:
        """
        Selects a field from the list by clicking on the element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
            lst_locator_strategy (str): The strategy to use for locating the list element.
            lst_locator_value (str): The value to use for locating the list element.
            lst_view (str): The view to display before clicking on the list element.
            match_text (str): The text to match against the list element.

        Returns:
            None
        """
        # Click on the list element identified by the given locator strategy and value
        self.drop_down(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        self.dropdown_field_selection(
            locator_strategy=lst_locator_strategy,
            locator_value=lst_locator_value,
            view=lst_view,
            match_text=match_text,
        )

    def hover_and_select_field(
        self,
        locator_strategy: str,
        locator_value: str,
        view: str,
        value: str,
        lst_locator_strategy: str,
        lst_locator_value: str,
        lst_view: str,
        match_text: str,
    ) -> None:
        """
        Sends text to the input field and selects a field from a dropdown list.

        Args:
            locator_strategy (str): The strategy to use for locating the input field.
            locator_value (str): The value to use for locating the input field.
            view (str): The view to display before interacting with the input field.
            value (str): The text to send to the input field.
            lst_locator_strategy (str): The strategy to use for locating the dropdown list.
            lst_locator_value (str): The value to use for locating the dropdown list.
            lst_view (str): The view to display before interacting with the dropdown list.
            match_text (str): The text to match against the dropdown list.

        Returns:
            None
        """
        self.sm_move_and_send_text(
            locator_strategy=locator_strategy,
            locator_value=locator_value,
            view=view,
            send_keys=value,
        )
        time.sleep(1)
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        self.dropdown_field_selection(
            locator_strategy=lst_locator_strategy,
            locator_value=lst_locator_value,
            view=lst_view,
            match_text=match_text,
        )

    def select_operator(
        self,
        locator_strategy: str,
        locator_value: str,
        view: str,
        lst_locator_strategy: str,
        lst_locator_value: str,
        lst_view: str,
        match_text: str,
    ) -> None:
        """
        Selects an operator from a dropdown list.

        Args:
            locator_strategy (str): The strategy to use for locating the dropdown element.
            locator_value (str): The value to use for locating the dropdown element.
            view (str): The view to display before clicking on the dropdown element.
            lst_locator_strategy (str): The strategy to use for locating the list element.
            lst_locator_value (str): The value to use for locating the list element.
            lst_view (str): The view to display before clicking on the list element.
            match_text (str): The text to match against the list element.

        Returns:
            None
        """
        # Click on the dropdown element identified by the given locator strategy and value
        self.drop_down(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

        # Select the operator from the list element that matches the given match_text
        self.dropdown_field_selection(
            locator_strategy=lst_locator_strategy,
            locator_value=lst_locator_value,
            view=lst_view,
            match_text=match_text,
        )

    def set_value(
        self, locator_strategy: str, locator_value: str, view: str, value: str
    ) -> None:
        """
        Sets the value of an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before setting the value.
            value (str): The value to set for the element.

        Returns:
            None
        """
        # Set the value of the element identified by the given locator strategy and value
        self.sm_send_txt_to_elm(
            locator_strategy=locator_strategy,
            locator_value=locator_value,
            view=view,
            send_text=value,
        )

    def add_custom_logic(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on an element identified by the provided locator strategy and value.

        Args:
            locator_strategy (str): The strategy used for locating the element.
            locator_value (str): The value used for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the provided locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
