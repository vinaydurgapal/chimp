from selenium.common import NoSuchElementException, StaleElementReferenceException, ElementClickInterceptedException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC


class SF_Real_Time_Setting(
    ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        """
        Initializes the CF_Edit_Configuration class.

        Args:
            driver (WebDriver): The Selenium WebDriver instance.
        """
        super().__init__(driver)

    def real_time_setting(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Click on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        try:
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )
        except (StaleElementReferenceException, NoSuchElementException,ElementClickInterceptedException):
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )

    def site_missing_permission(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on the element representing a site with missing permission.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def provide_permission(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def webhook_list(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on the webhook element using the specified locator strategy and value.

        This function triggers the click action on the webhook element based on the provided locator strategy and value.
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def view_all_webhooks_toggle_btn(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on the element to view all webhooks.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view or context where this action is being performed.

        Returns:
            None

        This function clicks on the element identified by the given locator strategy and value.
        It is used to view all webhooks.
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def realtime_export_setting(
        self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on the element for real-time export setting.

        This function triggers the click action on the element identified by the provided locator strategy and value
        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view or context where this action is being performed.
        Returns:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
