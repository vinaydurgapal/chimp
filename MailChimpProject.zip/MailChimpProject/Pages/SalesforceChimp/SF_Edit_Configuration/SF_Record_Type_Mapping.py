from selenium.common import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC

from Pages.SalesforceChimp.SF_Edit_Configuration.SF_CF_Edit_Configuration import CF_Edit_Configuration


class SF_Record_Type_Mapping(CF_Edit_Configuration,
                             ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        """
        Initializes the CF_Edit_Configuration class.

        Args:
            driver (WebDriver): The Selenium WebDriver instance.
        """
        super().__init__(driver)

    def record_type_mapping(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Click on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        try:
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )
        except StaleElementReferenceException:
            # Click on the element identified by the given locator strategy and value
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )

    def record_type_drop_down(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Click on an element in the dropdown menu based on the provided locator strategy, value, and view.

        Args:
            locator_strategy (str): The strategy used to locate the dropdown element.
            locator_value (str): The value used to locate the dropdown element.
            view (str): The view in which the dropdown element is located.

        Returns:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def record_type_drop_downs(
            self,
            locator_strategy: str,
            locator_value: str,
            view: str,
            lst_locator_strategy: str,
            lst_locator_value: str,
            lst_view: str,
            match_text: str,
    ) -> None:
        """
        Selects a field from the list by clicking on the element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
            lst_locator_strategy (str): The strategy to use for locating the list element.
            lst_locator_value (str): The value to use for locating the list element.
            lst_view (str): The view to display before clicking on the list element.
            match_text (str): The text to match against the list element.

        Returns:
            None
        """
        # Click on the list element identified by the given locator strategy and value
        self.drop_down(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        self.dropdown_field_selection(
            locator_strategy=lst_locator_strategy,
            locator_value=lst_locator_value,
            view=lst_view,
            match_text=match_text,
        )
