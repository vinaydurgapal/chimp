import time

import pytest
from selenium.common import NoSuchElementException, StaleElementReferenceException, ElementClickInterceptedException, \
    TimeoutException
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium


class CF_Edit_Configuration(
    ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        """
        Initializes the CF_Edit_Configuration class.

        Args:
            driver (WebDriver): The Selenium WebDriver instance.
        """
        super().__init__(driver)

    def edit_configuration(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Edits the configuration using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None

        Raises:
            None

        Notes:
            This function is used to edit the configuration. It clicks on the element specified by the
            locator strategy and value.
        """
        # Click on the element

        try:
            self.js_click_on_elm(
                locator_strategys=locator_strategy, locator_values=locator_value, views=view
            )
            time.sleep(1)  # NEED REASON: ElementClickInterceptedException
        except (
                StaleElementReferenceException, NoSuchElementException, ElementClickInterceptedException,
                TimeoutException):
            self.js_click_on_elm(
                locator_strategys=locator_strategy, locator_values=locator_value, views=view
            )
            time.sleep(1)  # NEED REASON: ElementClickInterceptedException

    def close_modal(self, locator_strategy, locator_value, view):
        """
        Closes the modal using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None

        Raises:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def save_button(self, locator_strategy, locator_value, view):
        """
        This function represents the behavior of clicking on the save button using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the save button element.
            locator_value (str): The value to use with the locator strategy for locating the save button element.
            view (str): The view or context where this action is being performed.

        Returns:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def get_validation_message(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> str:
        """
        This method returns the text of the validation message.

        Args:
            locator_strategy (str): The strategy to use for locating the validation message.
            locator_value (str): The value to use with the locator strategy.
            view (str): The view or context where the action is being performed.

        Returns:
            str: The text of the validation message.
        """
        # Find the validation message element
        toast_message = self.sm_return_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        return toast_message

    def toggle_field(
            self,
            locator_strategy: str,
            locator_value: str,
            view: str,
            conditions_dict: dict,
            toggle_field_data=None,
    ):
        """
        Toggles the field using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the field.
            locator_value (str): The value to use for locating the field.
            view (str): The view to display before toggling the field.
            conditions_dict (dict): Dictionary containing conditions for toggling the field.
            toggle_field_data (optional): Data used for toggling.

        Returns:
            None

        Notes:
            This function is used to toggle the visibility or state of a field based on the provided strategy and value.
        """
        # Get the element based on the locator strategy and value
        get_element = self.sm_return_elm(
            locator_strategy=locator_strategy,
            locator_value=locator_value,
        )

        # Check if the toggle condition is True
        if conditions_dict.get(str(toggle_field_data)) == "True":
            # Check if the element is not checked
            if get_element.get_attribute("checked") is None:
                # Perform actions when the toggle is not selected
                self.logger.info(f"{view}: Enabled")
                get_element.click()
                self.logger.info(f"{view}: Marked Enabled")
            else:
                # Toggle is already selected
                self.logger.info(f"{view}: Enabled")
                self.logger.info(f"{view}: Already Marked Enabled")
        else:
            # Check if the element is checked
            if get_element.get_attribute("checked") is not None:
                # Perform actions when the toggle is selected
                self.logger.info(f"{view}: Enabled")
                get_element.click()
                self.logger.info(f"{view}: Marked Disabled")
            else:
                # Toggle is already deselected
                self.logger.info(f"{view}: Disabled :")
                self.logger.info(f"{view}: Already Marked Disabled")

    def toggle_field_with_checked_disabled_condition(
            self,
            locator_strategy: str,
            locator_value: str,
            view: str,
            conditions_dict: dict,
            toggle_field_data=None,
    ):
        """
        Toggles the field using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the field.
            locator_value (str): The value to use for locating the field.
            view (str): The view to display before toggling the field.
            conditions_dict (dict): Dictionary containing conditions for toggling the field.
            toggle_field_data (optional): Data used for toggling.

        Returns:
            None

        Notes:
            This function is used to toggle the visibility or state of a field based on the provided strategy and value.
        """
        # Get the element based on the locator strategy and value
        get_element = self.sm_return_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

        # Check if the toggle condition is True
        if conditions_dict.get(str(toggle_field_data)) == "True":
            # Check if the element is not checked
            if get_element.get_attribute("checked") is None:
                # Perform actions when the toggle is not selected
                get_element.click()
                self.logger.info(f"{view} {toggle_field_data} ")
            else:
                # Toggle is already selected
                pass
                # Uncomment the line below if you want to log the status of the toggle
                # self.logger.info(f"{toggle_data} is disabled now.")

            # Check if the element is disabled
            if get_element.get_attribute("disabled") is not None:
                # Perform actions when the element is disabled
                # For example, you can add a class to show it as disabled
                get_element.set_attribute("class", "disabled")
        else:
            # Check if the element is checked
            if get_element.get_attribute("checked") is not None:
                # Perform actions when the toggle is selected
                get_element.click()
                self.logger.info(f" {view} {toggle_field_data} ")
            else:
                # Toggle is already deselected
                pass
                # Uncomment the line below if you want to log the status of the toggle
                # self.logger.info(f"{toggle_data} is Already disabled now.")

    def drop_down(self, locator_strategy, locator_value, view):
        """
        Dropdown.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.

        Returns:

        """
        try:
            self.sm_click_on_elm(
                locator_strategy=locator_strategy,
                locator_value=locator_value,
                view=view,
            )
        except NoSuchElementException:
            self.logger.error("Dropdown Element not found")

    def dropdown_field_selection(
            self, locator_strategy, locator_value, view, match_text=None
    ):
        """
        Simulates the action of clicking on a dropdown element.

        Args:
            locator_strategy (str): The strategy used to locate the dropdown element.
            locator_value (str): The value used with the locator strategy to locate the dropdown element.
            view (str): The view or context where this action is being performed.
            match_text (str, optional): The text to match within the dropdown element. Defaults to None.

        Returns:
            None
        """
        # Get the dropdown element
        drop_down_elements = self.sm_return_list_of_elms(
            locator_value=locator_value, locator_strategy=locator_strategy, view=view
        )
        # Iterate through the dropdown elements and click on the element with matching text
        for element in drop_down_elements:
            if element.text == match_text:
                element.click()
                break

    def get_info_text(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> str:
        """
        This method returns the text of the info icon.

        Args:
            locator_strategy (str): The strategy to use for locating the info icon.
            locator_value (str): The value to use with the locator strategy.
            view (str): The view or context where the action is being performed.

        Returns:
            str: The text of the info icon.

        This method uses the `get_hover_text` method to find the info icon element and returns its text.
        """
        # Find the info icon element
        info_icon = self.get_hover_text(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
        if info_icon:
            # Return the text of the info icon
            return info_icon
        else:
            # Return an empty string if the info icon is not found
            pytest.fail("Return an empty string if the info icon is not found")

    def get_text(
            self,
            locator_strategy: str,
            locator_value: str,
            view: str,
    ) -> str:
        """
        This method returns the text of a static element.

        Args:
            locator_strategy (str): The strategy to use for locating the static element.
            locator_value (str): The value to use with the locator strategy.
            view (str): The view or context where the action is being performed.

        Returns:
            str: The text of the static element.
        """
        # Get the static element
        try:
            static_element = self.sm_return_elm(
                locator_strategy=locator_strategy, locator_value=locator_value, view=view
            )
            # Extract the text from the static element
            static_text = static_element.text
            # Uncomment the line below if you want to log the text of the static element
            # self.logger.debug(f"Text of the static element: {static_text}")
            return static_text
        except (StaleElementReferenceException, NoSuchElementException):
            static_element = self.sm_return_elm(
                locator_strategy=locator_strategy, locator_value=locator_value, view=view
            )
            # Extract the text from the static element
            static_text = static_element.text
            # Uncomment the line below if you want to log the text of the static element
            # self.logger.debug(f"Text of the static element: {static_text}")
            return static_text

    def check_box(
            self,
            locator_strategy: str,
            locator_value: str,
            view: str,
            conditions_dict: dict,
            check_box_data=None,
    ) -> None:
        """
        Checks the checkbox element based on the specified conditions.

        Args:
            locator_strategy (str): The strategy to use for locating the checkbox element.
            locator_value (str): The value to use with the locator strategy.
            view (str): The view or context where the action is being performed.
            conditions_dict (dict): A dictionary containing conditions for checking the checkbox.
            check_box_data (optional): Data related to the checkbox.

        Returns:
            None
        """
        # Get the checkbox element
        checkbox_element = self.sm_return_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

        # Check if the checkbox condition is True
        if conditions_dict.get(str(check_box_data)) == "True":
            # Check if the checkbox is not checked
            if checkbox_element.get_attribute("checked") is None:
                # Perform actions when the checkbox is not selected
                checkbox_element.click()
                self.logger.info(f"{view} {check_box_data} is enabled now.")
            else:
                # Checkbox is already selected
                pass
                # Uncomment the line below if you want to log the status of the checkbox
                # self.logger.info(f"{check_box_data} is already enabled.")
        else:
            # Check if the checkbox is checked
            if checkbox_element.get_attribute("checked") is not None:
                # Perform actions when the checkbox is selected
                checkbox_element.click()
                self.logger.info(f"{view} {check_box_data} is already enabled.")
            else:
                # Checkbox is already deselected
                pass
                # Uncomment the line below if you want to log the status of the checkbox
                # self.logger.info(f"{check_box_data} is already disabled.")

    def refresh_page_icon(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Refreshes the page by clicking on an element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        try:
            self.sm_click_on_elm(
                locator_strategy=locator_strategy, locator_value=locator_value, view=view
            )
        except (StaleElementReferenceException, NoSuchElementException, ElementClickInterceptedException):
            self.sm_click_on_elm(
                locator_strategy=locator_strategy, locator_value=locator_value, view=view
            )

    def remove_field(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Remove a field by clicking on the element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def add_icon(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def delete_icon(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on an element to delete it.

        Args:
            locator_strategy (str): The strategy to locate the element.
            locator_value (str): The value to locate the element.
            view (str): The view before clicking on the element.

        Returns:
            None
        """
        # Click on the element to delete it
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )

    def redirect_to_chimp_connect(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        # This function is used to redirect to the Chimp Connect page.
        # It uses the given locator strategy and value to locate the element.
        # The view to display before clicking on the element is specified by the 'view' parameter.
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
