import time

import pytest
from selenium.common import StaleElementReferenceException, NoSuchElementException, ElementClickInterceptedException

from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium


class SF_Merge_Field_Mapping(
    ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        """
        Initializes the CF_Edit_Configuration class.

        Args:
            driver (WebDriver): The Selenium WebDriver instance.
        """
        super().__init__(driver)

    def merge_field_mapping(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Click on an element identified by the given locator strategy and value.
        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        try:
            time.sleep(2)  # NEED REASON: ElementClickInterceptedException
            # Click on the element identified by the given locator strategy and value
            self.js_click_on_elm(
                locator_strategys=locator_strategy, locator_values=locator_value, views=view
            )
        except (StaleElementReferenceException, NoSuchElementException,ElementClickInterceptedException):
            time.sleep(2)  # NEED REASON: ElementClickInterceptedException
            # Click on the element identified by the given locator strategy and value
            self.js_click_on_elm(
                locator_strategys=locator_strategy, locator_values=locator_value, views=view
            )

    def create_required_field(
            self, locator_strategy: str, locator_value: str, view: str
    ) -> None:
        """
        Clicks on an element identified by the given locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        # Click on the element identified by the given locator strategy and value
        self.sm_click_on_elm(
            locator_strategy=locator_strategy, locator_value=locator_value, view=view
        )
