from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC


class CF_Dashboard_View(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        super().__init__(driver)

    def wait_for_loader_to_disappear(self, locator_strategy, locator_value, view):
        """
        Waits for the element to disappear.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before waiting for the element to disappear.
        """
        locator = (locator_strategy, locator_value)
        WebDriverWait(self.driver, 10).until_not(EC.presence_of_element_located(locator))

    def page_refresh(self, locator_strategy, locator_value, view):
        """
        Refreshes the page by clicking on an element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_mailchimp_account(self, locator_strategy, locator_value, view, locator_strategy2, locator_value2, view2):
        """
        Clicks on the MailChimp account using the specified locator strategy and value.

        Args:
            view2: The view to display before clicking on the MailChimp account element.
            locator_value2: The value to use for locating the MailChimp account element.
            locator_strategy2: The strategy to use for locating the MailChimp account element.
            locator_strategy (str): The strategy to use for locating the MailChimp account element.
            locator_value (str): The value to use for locating the MailChimp account element.
            view (str): The view to display before clicking on the MailChimp account element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

    def select_audience(self, locator_strategy, locator_value, view, locator_strategy2, locator_value2, view2):
        """
        Clicks on the MailChimp account using the specified locator strategy and value.

        Args:
            view2: The view to display before clicking on the MailChimp account element.
            locator_value2: The value to use for locating the MailChimp account element.
            locator_strategy2: The strategy to use for locating the MailChimp account element.
            locator_strategy (str): The strategy to use for locating the MailChimp account element.
            locator_value (str): The value to use for locating the MailChimp account element.
            view (str): The view to display before clicking on the MailChimp account element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

    def mass_import(self, locator_strategy, locator_value, view):
        """
        Imports mass by clicking on an element on the specified view.

        Args:
            locator_strategy (str): The strategy to use for locating the MailChimp account element.
            locator_value (str): The value to use for locating the MailChimp account element.
            view (str): The view to display before clicking on the MailChimp account element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def wait_for_progress_bar(self, locator_strategy, locator_value, view):
        """
        Waits for the progress bar to disappear.

        Args:
            locator_strategy (str): The strategy to use for locating the MailChimp account element.
            locator_value (str): The value to use for locating the MailChimp account element.
            view (str): The view to display before clicking on the MailChimp account element.
        """
        locator = (locator_strategy, locator_value)
        WebDriverWait(self.driver, 4).until_not(
            EC.presence_of_element_located(locator)
        )
