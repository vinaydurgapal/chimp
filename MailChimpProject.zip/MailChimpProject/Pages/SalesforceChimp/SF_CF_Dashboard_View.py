from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC





class CF_Dashboard_View(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        super().__init__(driver)

    def wait_for_loader_to_disappear(self, locator_strategy, locator_value, view):
        """
        Waits for the element to disappear.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before waiting for the element to disappear.

        Notes:
            - The until_not method waits until a certain condition is false or until a timeout occurs.
        """
        locator = (locator_strategy, locator_value)
        WebDriverWait(self.driver, 10).until_not(EC.presence_of_element_located(locator))

    def page_refresh(self, locator_strategy, locator_value, view):
        """
        Refreshes the page by clicking on an element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_mailchimp_account(self, locator_strategy, locator_value, view, locator_strategy2, locator_value2, view2):
        """
        Clicks on the MailChimp account using the specified locator strategy and value.

        Args:
            view2: The view to display before clicking on the element.
            locator_value2: The value to use for locating the element.
            locator_strategy2: The strategy to use for locating the element.
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

    def select_audience(self, locator_strategy, locator_value, view, locator_strategy2, locator_value2, view2):
        """
        Clicks on the MailChimp account using the specified locator strategy and value.

        Args:
            view2: The view to display before clicking on the element.
            locator_value2: The value to use for locating the element.
            locator_strategy2: The strategy to use for locating the element.
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

    def mass_import(self, locator_strategy, locator_value, view):
        """
        Imports mass by clicking on an element on the specified view.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def wait_for_progress_bar(self, locator_strategy, locator_value, view):
        """
        Waits for the progress bar to disappear.

        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        Notes:
            - The until_not method waits until a certain condition is false or until a timeout occurs.
        """
        locator = (locator_strategy, locator_value)
        WebDriverWait(self.driver, 10).until_not(
            EC.presence_of_element_located(locator)
        )

    def success_txt(self, locator_strategy, locator_value, view):
        """
        Returns the success text on the specified view.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        elem = self.sm_return_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return elem

    def search_bar(self, locator_strategy, locator_value, view, send_text
                   , locator_strategy2, locator_value2, view2
                   , locator_strategy3, locator_value3, view3):
        """
        Send text to the search bar on the specified view. And return the list of elements on the specified view.
        Args:
            view3: The view to display before clicking on the  element.
            locator_value3: The value to use for locating the  element.
            locator_strategy3: The strategy to use for locating the  element.
            view2: The view to display before clicking on the  element.
            locator_value2: The value to use for locating the  element.
            locator_strategy2: The strategy to use for locating the  element.
            send_text: The send text to the search bar on the specified view.
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """

        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                send_text=send_text)
        self.wait_for_loader_to_disappear(locator_strategy3, locator_value3, view3)
        elem = self.sm_return_list_of_elms(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)
        return elem

    def utility_setting(self, locator_strategy, locator_value, view, ):
        """
        Clicks on an element on the specified view.
        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def utility_setting_items(self, locator_strategy, locator_value, view):
        """
        Returns the list of elements on the specified view.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        elem = self.sm_return_list_of_elms(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return elem

    # Add Form With Recent Audiences:Mailchimp And Customised Audience
    def utility_setting_add_form_with_recent_audience(self, locator_strategy, locator_value, view, send_text,
                                                      locator_strategy2=None, locator_value2=None, view2=None,
                                                      locator_strategy3=None, locator_value3=None, view3=None,
                                                      condition=None
                                                      , locator_strategy4=None, locator_value4=None, view4=None,
                                                      send_text2=None):
        """
        Sends text to an element on the specified view and clicks based on a condition.

        Args:
            send_text2: The text to send.
            view4: The view to display before clicking on the element.
            locator_value4: The value to use for locating the element.
            locator_strategy4: The strategy to use for locating the element.
            view3: The view to display before sending the text.
            locator_value3: The value to use for locating the element.
            locator_strategy3: The strategy to use for locating the element.
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before sending the text.
            send_text (str): The text to send.
            view2: The view to display before clicking on the element.
            locator_value2: The value to use for locating the element.
            locator_strategy2: The strategy to use for locating the element.
            condition (bool): The condition based on which to click.
        NOTE:
            Add Form With Recent Audiences:Mailchimp And Customised Audience
        """
        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                send_text=send_text)
        if condition:
            self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)
            self.sm_click_on_elm(locator_strategy=locator_strategy3, locator_value=locator_value3, view=view3)
        else:
            self.sm_send_txt_to_elm(locator_strategy=locator_strategy4, locator_value=locator_value4, view=view4,
                                    send_text=send_text2)

    def utility_setting_add_form_with_new_audience(self, locator_strategy, locator_value, view, send_text,
                                                   locator_strategy2=None, locator_value2=None, view2=None,
                                                   send_text2=None, locator_strategy3=None, locator_value3=None,
                                                   view3=None, send_text3=None, locator_strategy4=None,
                                                   locator_value4=None, view4=None, locator_strategy5=None,
                                                   locator_value5=None, view5=None):
        """
        Sends text to an element on the specified view and clicks based on a condition.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before sending the text.
            send_text (str): The text to send.
            locator_strategy2 (str, optional): The strategy to use for locating the second element.
            locator_value2 (str, optional): The value to use for locating the second element.
            view2 (str, optional): The view to display before clicking on the second element.
            send_text2 (str, optional): The text to send to the second element.
            locator_strategy3 (str, optional): The strategy to use for locating the third element.
            locator_value3 (str, optional): The value to use for locating the third element.
            view3 (str, optional): The view to display before clicking on the third element.
            send_text3 (str, optional): The text to send to the third element.
            locator_strategy4 (str, optional): The strategy to use for locating the fourth element.
            locator_value4 (str, optional): The value to use for locating the fourth element.
            view4 (str, optional): The view to display before sending text to the fourth element.
            locator_strategy5 (str, optional): The strategy to use for locating the fifth element.
            locator_value5 (str, optional): The value to use for locating the fifth element.
            view5 (str, optional): The view to display before sending text to the fifth element.

        Returns:
            None

        Raises:
            Exception: If element not found.

        """
        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                send_text=send_text)

        if locator_strategy2 and locator_value2 and view2:
            self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

        if locator_strategy3 and locator_value3 and view3:
            if self.sm_click_on_elm(locator_strategy=locator_strategy3, locator_value=locator_value3, view=view3):
                if locator_strategy4 and locator_value4 and view4 and send_text2:
                    self.sm_send_txt_to_elm(locator_strategy=locator_strategy4, locator_value=locator_value4,
                                            view=view4,
                                            send_text=send_text2)
                if locator_strategy5 and locator_value5 and view5 and send_text3:
                    self.sm_send_txt_to_elm(locator_strategy=locator_strategy5, locator_value=locator_value5,
                                            view=view5,
                                            send_text=send_text3)
            else:
                raise Exception("Element not found")

    def cancel_btn(self, locator_strategy, locator_value, view):
        """
        Cancels a form by clicking on a cancel button.

        Args:
            locator_strategy (str): The strategy to use for locating the cancel button.
            locator_value (str): The value to use for locating the cancel button.
            view (str): The view to display before clicking on the cancel button.

        Returns:
            None
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def ok_btn(self, locator_strategy, locator_value, view):
        """
        ok button in popup

        Args:
            locator_strategy (str): The strategy to use for locating the cancel button.
            locator_value (str): The value to use for locating the cancel button.
            view (str): The view to display before clicking on the cancel button.

        Returns:
            None
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def close_pop_up(self, locator_strategy, locator_value, view):
        """
        Close a pop-up by clicking on a Cross button.

        Args:
            locator_strategy (str): The strategy to use for locating the cancel button.
            locator_value (str): The value to use for locating the cancel button.
            view (str): The view to display before clicking on the cancel button.

        Returns:
            None
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def selected_field_to_display_and_search(self, locator_strategy, locator_value, view):
        """
        Returns the list of elements on the specified view. is used to display the selected field. example
        Available Fields
        Visible Fields
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        elem = self.sm_return_list_of_elms(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return elem

    def move_selected_to_visible_field(self, locator_strategy, locator_value, view):
        """
        Move the selected field to the visible field.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_fields_move_from_available_to_visible(self, utility_setting_section, utility_setting_key,
                                                     utility_setting_view, available_selected_field_data_config,
                                                     select_fields_section, select_fields_key, select_fields_view,
                                                     available_data_config, move_button_section, move_button_key,
                                                     move_button_view, cancel_button_section, cancel_button_key,
                                                     cancel_button_view, ok_sure_btn_section, ok_sure_btn_key,
                                                     ok_sure_btn_view):
        """
        Process and move fields based on configuration.

        Args:
            utility_setting_section (str): Configuration section to read utility setting.
            utility_setting_key (str): Configuration key to read utility setting.
            utility_setting_view (str): View to display before clicking on the utility setting.
            available_selected_field_data_config (str): Configuration to read available selected field data.
            select_fields_section (str): Configuration section to read select fields.
            select_fields_key (str): Configuration key to read select fields.
            select_fields_view (str): View to display before clicking on the select fields.
            available_data_config (str): Configuration to read available data.
            move_button_section (str): Configuration section to read move button locator.
            move_button_key (str): Configuration key to read move button locator.
            move_button_view (str): View to display before clicking on the move button.
            cancel_button_section (str): Configuration section to read cancel button locator.
            cancel_button_key (str): Configuration key to read cancel button locator.
            cancel_button_view (str): View to display before clicking on the cancel button.
            ok_sure_btn_section (str): Configuration section to read cancel and sure button locator.
            ok_sure_btn_key (str): Configuration key to read cancel and sure button locator.
            ok_sure_btn_view (str): View to display before clicking on the cancel and sure button.
        """
        # Retrieve select fields to display

        select_fields_to_display = self.utility_setting_items(locator_strategy=utility_setting_section,
                                                              locator_value=utility_setting_key,
                                                              view=utility_setting_view)

        # Loop through select_field_to_display elements
        for field in select_fields_to_display:
            # Check if the text of the element matches the expected value from configuration
            if field.text == available_selected_field_data_config:
                field.click()
                # Retrieve available fields to display and search
                available_fields = self.selected_field_to_display_and_search(locator_strategy=select_fields_section,
                                                                             locator_value=select_fields_key,
                                                                             view=select_fields_view)

                # Loop through available_fields
                for available_field in available_fields:
                    # Check if the text of the field matches the expected available data from configuration
                    if available_field.text == available_data_config:
                        available_field.click()

                        # Move selected item to visible field
                        self.move_selected_to_visible_field(locator_strategy=move_button_section,
                                                            locator_value=move_button_key,
                                                            view=move_button_view)

                        # Cancel form action
                        self.cancel_btn(locator_strategy=cancel_button_section,
                                        locator_value=cancel_button_key,
                                        view=cancel_button_view)
                        # Confirm form action
                        self.ok_btn(locator_strategy=ok_sure_btn_section,
                                    locator_value=ok_sure_btn_key,
                                    view=ok_sure_btn_view)
                        break
                else:
                    # If the text of the field doesn't match the expected available data, log an error message
                    # self.logger.error("Field doesn't match the expected available data")
                    pass

    def checkboxes(self, locator_strategy, locator_value, view):
        """
        Checkboxes.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.

        Returns:

        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def delete_button(self, locator_strategy, locator_value, view):
        """
        Delete button.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.

        Returns:
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def filter_button(self, locator_strategy, locator_value, view):
        """
        Filter button.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.

        Returns:
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_field(self, locator_strategy: str, locator_value: str, view: str, send_keys: str) -> None:
        """
        Selects a field by clicking on an element located using the provided strategy and value.

        Args:
            send_keys:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
            send_keys (str): The text to send to the element.

        Returns:
            None
        """
        self.sm_move_and_send_text(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                   send_keys=send_keys)

    def apply_button(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Clicks on the apply button located using the provided strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the apply button element.
            locator_value (str): The value to use for locating the apply button element.
            view (str): The view to display before clicking on the apply button element.

        Returns:
            None
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_operator(self, locator_strategy: str, locator_value: str, view: str) -> None:
        """
        Selects a field by clicking on an element located using the provided strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """

        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_value(self, locator_strategy: str, locator_value: str, view: str , send_keys: str) -> None:
        """
        Selects a field by clicking on an element located using the provided strategy and value.

        Args:
            send_keys:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.

        Returns:
            None
        """
        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,send_text=send_keys)

    def add_filter_pop_ups(self, sf_locator_strategy: str, sf_locator_value: str, sf_view: str, sf_config_data: str,
                           sf_lst_locator_strategy: str, sf_lst_locator_value: str, sf_lst_view: str,
                           operator_locator_strategy: str, operator_locator_value: str, operator_view: str,
                           operator_config_data: str,
                           operator_lst_locator_strategy: str, operator_lst_locator_value: str, operator_lst_view: str,
                           val_locator_strategy: str, val_locator_value: str, val_view: str, val_config_data: str,
                           cancel_locator_strategy: str, cancel_locator_value: str, cancel_view: str,
                           apply_locator_strategy: str, apply_locator_value: str, apply_view: str, add_filter: bool
                           ) -> None:
        """
        Adds a filter to the dashboard view.

        Args:
            sf_locator_strategy (str): The strategy to locate the select field element.
            sf_locator_value (str): The value to locate the select field element.
            sf_view (str): The view where the select field element is located.
            sf_config_data (str): The data to send to the select field element.
            sf_lst_locator_strategy (str): The strategy to locate the select field dropdown list element.
            sf_lst_locator_value (str): The value to locate the select field dropdown list element.
            sf_lst_view (str): The view where the select field dropdown list element is located.
            operator_locator_strategy (str): The strategy to locate the operator element.
            operator_locator_value (str): The value to locate the operator element.
            operator_view (str): The view where the operator element is located.
            operator_config_data (str): The data to select in the operator dropdown list.
            operator_lst_locator_strategy (str): The strategy to locate the operator dropdown list element.
            operator_lst_locator_value (str): The value to locate the operator dropdown list element.
            operator_lst_view (str): The view where the operator dropdown list element is located.
            val_locator_strategy (str): The strategy to locate the value element.
            val_locator_value (str): The value to locate the value element.
            val_view (str): The view where the value element is located.
            val_config_data (str): The data to send to the value element.
            cancel_locator_strategy (str): The strategy to locate the cancel button element.
            cancel_locator_value (str): The value to locate the cancel button element.
            cancel_view (str): The view where the cancel button element is located.
            apply_locator_strategy (str): The strategy to locate the apply button element.
            apply_locator_value (str): The value to locate the apply button element.
            apply_view (str): The view where the apply button element is located.
            add_filter (bool): Whether or not to add the filter.

        Raises:
            Exception: If an error occurs while adding the filter.

        Returns:
            None
        """
        try:
            # Select the select field element
            self.select_field(locator_strategy=sf_locator_strategy, locator_value=sf_locator_value, view=sf_view,
                              send_keys=sf_config_data)
            # Get the list of select field dropdown list elements
            select_field_list = self.sm_return_list_of_elms(locator_strategy=sf_lst_locator_strategy,
                                                            locator_value=sf_lst_locator_value, view=sf_lst_view)
            # Iterate over the list of select field dropdown list elements
            for select_field_dropdown_element in select_field_list:
                # Check if the text of the current element matches the specified text
                if select_field_dropdown_element.text == sf_config_data:
                    # If a match is found, click on the element
                    select_field_dropdown_element.click()
                    self.select_operator(locator_strategy=operator_locator_strategy,
                                         locator_value=operator_locator_value,
                                         view=operator_view)
                    operator_field_list = self.sm_return_list_of_elms(locator_strategy=operator_lst_locator_strategy,
                                                                      locator_value=operator_lst_locator_value,
                                                                      view=operator_lst_view)
                    # Find the select field dropdown list element with the specified text and click it
                    for _ in operator_field_list:
                        # Check if the text of the current element matches the specified text
                        if _.text == operator_config_data:
                            # If a match is found, click on the element
                            _.click()
                            self.logger.info(
                                f"Filter added: Select Field: {sf_config_data} : Operator: {operator_config_data}")
                            self.select_value(locator_strategy=val_locator_strategy, locator_value=val_locator_value,
                                              view=val_view, send_keys=val_config_data)
                            if add_filter:
                                self.apply_button(locator_strategy=apply_locator_strategy,
                                                  locator_value=apply_locator_value, view=apply_view)
                            else:
                                self.cancel_btn(locator_strategy=cancel_locator_strategy,
                                                locator_value=cancel_locator_value, view=cancel_view)
                            break
                else:
                    self.cancel_btn(locator_strategy=cancel_locator_strategy, locator_value=cancel_locator_value,
                                    view=cancel_view)
                    self.logger.error(f"Select field dropdown list element not found: {sf_config_data}.")
                    break
        except Exception as e:
            self.logger.error(f"An error occurred: {e}. Closing the filter pop-up.")
            self.cancel_btn(locator_strategy=cancel_locator_strategy, locator_value=cancel_locator_value,
                            view=cancel_view)

    def return_page_heading(self, locator_strategy, locator_value, view=None):
        """
        This function returns the heading of the dashboard view based on the provided locator strategy, locator value,
        view, and inputs to be sent.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before sending keys.

        Returns:
            str: The heading of the dashboard view.
        """
        page_heading = self.sm_return_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return page_heading