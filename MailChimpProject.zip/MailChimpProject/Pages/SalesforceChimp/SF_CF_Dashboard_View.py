from selenium.webdriver import Keys
from selenium.webdriver.support.wait import WebDriverWait
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from selenium.webdriver.support import expected_conditions as EC


class CF_Dashboard_View(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        super().__init__(driver)

    def wait_for_loader_to_disappear(self, locator_strategy, locator_value, view):
        """
        Waits for the element to disappear.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before waiting for the element to disappear.

        Notes:
            - The until_not method waits until a certain condition is false or until a timeout occurs.
        """
        locator = (locator_strategy, locator_value)
        WebDriverWait(self.driver, 10).until_not(EC.presence_of_element_located(locator))

    def page_refresh(self, locator_strategy, locator_value, view):
        """
        Refreshes the page by clicking on an element using the specified locator strategy and value.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def select_mailchimp_account(self, locator_strategy, locator_value, view, locator_strategy2, locator_value2, view2):
        """
        Clicks on the MailChimp account using the specified locator strategy and value.

        Args:
            view2: The view to display before clicking on the element.
            locator_value2: The value to use for locating the element.
            locator_strategy2: The strategy to use for locating the element.
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

    def select_audience(self, locator_strategy, locator_value, view, locator_strategy2, locator_value2, view2):
        """
        Clicks on the MailChimp account using the specified locator strategy and value.

        Args:
            view2: The view to display before clicking on the element.
            locator_value2: The value to use for locating the element.
            locator_strategy2: The strategy to use for locating the element.
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

    def mass_import(self, locator_strategy, locator_value, view):
        """
        Imports mass by clicking on an element on the specified view.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def wait_for_progress_bar(self, locator_strategy, locator_value, view):
        """
        Waits for the progress bar to disappear.

        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        Notes:
            - The until_not method waits until a certain condition is false or until a timeout occurs.
        """
        locator = (locator_strategy, locator_value)
        WebDriverWait(self.driver, 10).until_not(
            EC.presence_of_element_located(locator)
        )

    def success_txt(self, locator_strategy, locator_value, view):
        """
        Returns the success text on the specified view.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        elem = self.sm_return_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return elem

    def search_bar(self, locator_strategy, locator_value, view, send_text
                   , locator_strategy2, locator_value2, view2
                   , locator_strategy3, locator_value3, view3):
        """
        Send text to the search bar on the specified view. And return the list of elements on the specified view.
        Args:
            view3: The view to display before clicking on the  element.
            locator_value3: The value to use for locating the  element.
            locator_strategy3: The strategy to use for locating the  element.
            view2: The view to display before clicking on the  element.
            locator_value2: The value to use for locating the  element.
            locator_strategy2: The strategy to use for locating the  element.
            send_text: The send text to the search bar on the specified view.
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """

        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                send_text=send_text)
        self.wait_for_loader_to_disappear(locator_strategy3, locator_value3, view3)
        elem = self.sm_return_list_of_elms(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)
        return elem

    def utility_setting(self, locator_strategy, locator_value, view, ):
        """
        Clicks on an element on the specified view.
        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before clicking on the element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def utility_setting_items(self, locator_strategy, locator_value, view):
        """
        Returns the list of elements on the specified view.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        elem = self.sm_return_list_of_elms(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return elem

    # Add Form With Recent Audiences:Mailchimp And Customised Audience
    def utility_setting_add_form_with_recent_audience(self, locator_strategy, locator_value, view, send_text,
                                                      locator_strategy2=None, locator_value2=None, view2=None,
                                                      locator_strategy3=None, locator_value3=None, view3=None,
                                                      condition=None
                                                      , locator_strategy4=None, locator_value4=None, view4=None,
                                                      send_text2=None):
        """
        Sends text to an element on the specified view and clicks based on a condition.

        Args:
            send_text2: The text to send.
            view4: The view to display before clicking on the element.
            locator_value4: The value to use for locating the element.
            locator_strategy4: The strategy to use for locating the element.
            view3: The view to display before sending the text.
            locator_value3: The value to use for locating the element.
            locator_strategy3: The strategy to use for locating the element.
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before sending the text.
            send_text (str): The text to send.
            view2: The view to display before clicking on the element.
            locator_value2: The value to use for locating the element.
            locator_strategy2: The strategy to use for locating the element.
            condition (bool): The condition based on which to click.
        NOTE:
            Add Form With Recent Audiences:Mailchimp And Customised Audience
        """
        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                send_text=send_text)
        if condition:
            self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)
            self.sm_click_on_elm(locator_strategy=locator_strategy3, locator_value=locator_value3, view=view3)
        else:
            self.sm_send_txt_to_elm(locator_strategy=locator_strategy4, locator_value=locator_value4, view=view4,
                                    send_text=send_text2)

    def utility_setting_add_form_with_new_audience(self, locator_strategy, locator_value, view, send_text,
                                                   locator_strategy2=None, locator_value2=None, view2=None,
                                                   send_text2=None, locator_strategy3=None, locator_value3=None,
                                                   view3=None, send_text3=None, locator_strategy4=None,
                                                   locator_value4=None, view4=None, locator_strategy5=None,
                                                   locator_value5=None, view5=None):
        """
        Sends text to an element on the specified view and clicks based on a condition.

        Args:
            locator_strategy (str): The strategy to use for locating the element.
            locator_value (str): The value to use for locating the element.
            view (str): The view to display before sending the text.
            send_text (str): The text to send.
            locator_strategy2 (str, optional): The strategy to use for locating the second element.
            locator_value2 (str, optional): The value to use for locating the second element.
            view2 (str, optional): The view to display before clicking on the second element.
            send_text2 (str, optional): The text to send to the second element.
            locator_strategy3 (str, optional): The strategy to use for locating the third element.
            locator_value3 (str, optional): The value to use for locating the third element.
            view3 (str, optional): The view to display before clicking on the third element.
            send_text3 (str, optional): The text to send to the third element.
            locator_strategy4 (str, optional): The strategy to use for locating the fourth element.
            locator_value4 (str, optional): The value to use for locating the fourth element.
            view4 (str, optional): The view to display before sending text to the fourth element.
            locator_strategy5 (str, optional): The strategy to use for locating the fifth element.
            locator_value5 (str, optional): The value to use for locating the fifth element.
            view5 (str, optional): The view to display before sending text to the fifth element.

        Returns:
            None

        Raises:
            Exception: If element not found.

        """
        self.sm_send_txt_to_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view,
                                send_text=send_text)

        if locator_strategy2 and locator_value2 and view2:
            self.sm_click_on_elm(locator_strategy=locator_strategy2, locator_value=locator_value2, view=view2)

        if locator_strategy3 and locator_value3 and view3:
            if self.sm_click_on_elm(locator_strategy=locator_strategy3, locator_value=locator_value3, view=view3):
                if locator_strategy4 and locator_value4 and view4 and send_text2:
                    self.sm_send_txt_to_elm(locator_strategy=locator_strategy4, locator_value=locator_value4,
                                            view=view4,
                                            send_text=send_text2)
                if locator_strategy5 and locator_value5 and view5 and send_text3:
                    self.sm_send_txt_to_elm(locator_strategy=locator_strategy5, locator_value=locator_value5,
                                            view=view5,
                                            send_text=send_text3)
            else:
                raise Exception("Element not found")

    def cancel_form(self, locator_strategy, locator_value, view):
        """
        Cancels a form by clicking on a cancel button.

        Args:
            locator_strategy (str): The strategy to use for locating the cancel button.
            locator_value (str): The value to use for locating the cancel button.
            view (str): The view to display before clicking on the cancel button.

        Returns:
            None
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def close_pop_up(self, locator_strategy, locator_value, view):
        """
        Close a pop-up by clicking on a Cross button.

        Args:
            locator_strategy (str): The strategy to use for locating the cancel button.
            locator_value (str): The value to use for locating the cancel button.
            view (str): The view to display before clicking on the cancel button.

        Returns:
            None
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)

    def selected_field_to_display_and_search(self, locator_strategy, locator_value, view):
        """
        Returns the list of elements on the specified view. is used to display the selected field. example
        Available Fields
        Visible Fields
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        elem = self.sm_return_list_of_elms(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
        return elem

    def move_selected_to_visible_field(self, locator_strategy, locator_value, view):
        """
        Move the selected field to the visible field.
        Args:
            locator_strategy (str): The strategy to use for locating the  element.
            locator_value (str): The value to use for locating the  element.
            view (str): The view to display before clicking on the  element.
        """
        self.sm_click_on_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
