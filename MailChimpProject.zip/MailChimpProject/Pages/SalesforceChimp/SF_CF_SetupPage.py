from selenium.webdriver.common.by import By
from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from Utilities import ConfigReader


class SF_CF_SetupPage(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Salesforce common function.
    This class inherits from `SalesForceBaseTest` and provides additional functionality related to audience management in Salesforce.
    """

    def __init__(self, driver):
        super().__init__(driver)

    # common function to redirect to app page that's why we are using passing there locator strategy and locator value
    def redirect_to_app_page(self):
        """
        Redirects to the app page  from setup page by clicking on the nine dots icon and searching for "ChimpConnect".

        This function performs the following steps:
        1. Clicks on the nine dots icon using the XPATH locator strategy and the value obtained from the config file.
        2. Sends the text "ChimpConnect" to the search box using the XPATH locator strategy and the value obtained from the config file.
        3. Clicks on the "ChimpConnect" app name using the CSS locator strategy and the value obtained from the config file.

        Parameters:
        - self: The instance of the SF_Common_Function class.

        Returns:
        - None
        """
        self.js_click_on_elm(locator_strategys=By.XPATH,
                             locator_values=ConfigReader.locatorsReadConfig("app common locators", "nine_dots_css")
                             , views="Home : Setup Page : ")
        self.js_send_txt_to_elm(locator_strategy=By.XPATH,
                                locator_value=ConfigReader.locatorsReadConfig("app common locators",
                                                                              "inpt_search_box_xpath")
                                , send_text="ChimpConnect", view="Home : Setup Page :  Search  ")
        self.js_click_on_elm(locator_strategys=By.XPATH,
                             locator_values=ConfigReader.locatorsReadConfig("app common locators", "app_name_css")
                             , views="Home : Setup Page : Search : ChimpConnect : ")

    # MailChimp is defined in this function as mc
    def add_mc_account(self):
        """
        Adds a MailChimp account.

        This function attempts to add a MailChimp account by clicking on a button located by its XPath.
        The XPath is obtained from the configuration file using the `locatorsReadConfig` method of the `ConfigReader` class.

        If the button is found and clicked successfully, the function logs a message indicating that the MailChimp account was added.
        If the button is not found, the function logs a message indicating that the MailChimp account is already added.

        """
        elem = self.sm_return_elm(locator_strategy=By.XPATH,
                                  locator_value=ConfigReader.locatorsReadConfig("app common locators",
                                                                                "btn_app_cred_xpath")
                                  , view="ChimpConnect : Add Mail Chimp Account : ")
        if elem:
            self.js_click_on_elm(locator_strategys=By.XPATH,
                                 locator_values=ConfigReader.locatorsReadConfig("app common locators",
                                                                                "btn_app_cred_xpath")
                                 ,  views="ChimpConnect : Add Mail Chimp Account : ")
        else:
            self.logger.info("Mail Chimp Account is already added !")


    def credentials_pop_up(self):
        self.js_click_on_elm(locator_strategys=By.XPATH,
                             locator_values=ConfigReader.locatorsReadConfig("app common locators","btn_app_cred_xpath"),
                             views="ChimpConnect : Add Mail Chimp Account : Credentials pop up : Copy URI")