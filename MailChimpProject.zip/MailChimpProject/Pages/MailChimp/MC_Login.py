import time

import pytest
from selenium.webdriver.common.by import By

from Pages.BasePage import ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium
from Utilities import ConfigReader


class MC_MailChimpLogin(ActionOnElementUsingJavaScript, ActionOnElementUsingSelenium):
    """
    A class representing a Mailchimp login page.
    This class inherits from `MailChimpBaseTest` and provides additional functionality related to login in Mailchimp.
    """

    def __init__(self, driver):
        super().__init__(driver)

    def login_page(self):
        """
        Clicks on an element on the Mailchimp login page.

        Notes:
            - This method uses JavaScript to click on the element.
        """
        self.sm_send_txt_to_elm(locator_strategy=By.XPATH,
                                locator_value=ConfigReader.locatorsReadConfig("mailchimp locators", "inpt_us_name"),
                                view="Mailchimp Login Page : User Name :",
                                send_text=ConfigReader.dataReadConfig("mailchimp login", "username"))
        #time.sleep(100)
        self.sm_send_txt_to_elm(locator_strategy=By.CSS_SELECTOR,
                                locator_value=ConfigReader.locatorsReadConfig("mailchimp locators", "inpt_pw_name"),
                                view="Mailchimp Login Page : Password : ",
                                send_text=ConfigReader.dataReadConfig("mailchimp login", "password"))
        try:
            self.switch_to_frame(locator_strategy=By.XPATH,
                                 locator_value=ConfigReader.locatorsReadConfig("mailchimp locators", "iframe_xpath"),
                                 view="Mailchimp Login Page : Iframe :")

            self.js_click_on_elm(locator_strategys=By.CSS_SELECTOR,
                                 locator_values=ConfigReader.locatorsReadConfig("mailchimp locators", "check_box_css"),
                                 views="Mailchimp Login Page : I'm Not robot Checkbox")
            self.driver.default_content()
        except Exception as e:
            self.logger.error(f"Mailchimp Login Page : I'm not robot Checkbox : Not found")
        finally:
            self.js_click_on_elm(locator_strategys=By.CSS_SELECTOR,
                                 locator_values=ConfigReader.locatorsReadConfig("mailchimp locators", "btn_login_css"),
                                 views="Mailchimp Login Page : Login Button")
            pytest.fail("pooooooooooooooooooooooooooooooo")
