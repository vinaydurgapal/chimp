# NOTE:  Before using Base Class Please read these Shortcuts of Selenium , Javascript , Text , Send , click , element , validation
# javascript = js
# Selenium = sm
# Text = txt
# Send = snd
# element = elm
# validation = vld

from selenium.common import NoSuchElementException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Utilities.LogUtil import LogGen
from selenium.webdriver import ActionChains, Keys


class BasePage:
    """
    Base class for all pages in the application.

    This class provides common functionality for all pages, such as logging and waiting for elements.

    Attributes:
        driver (WebDriver): The Selenium WebDriver instance.
        logger (LogGen): The logger instance.
        wait (WebDriverWait): The WebDriverWait instance for waiting for elements.

    Methods:
        __init__(self, driver)
            Initializes the BasePage instance.

            Parameters:
                driver (WebDriver): The Selenium WebDriver instance.

    """

    def __init__(self, driver):
        self.driver = driver
        self.logger = LogGen.loggen()
        self.wait = WebDriverWait(self.driver, timeout=30, poll_frequency=3)
        # Set a global implicit wait for the driver


class ElementPresenceCheck(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    def checks_for_elm_presence(self, locator_strategy, locator_value, view):
        """
        Wait for the element present in the page.

        Parameters:
        - locator_strategy: The strategy used to locate the rows (e.g., By.XPATH).
        - locator_value: The value used with the locator strategy to locate the rows.
        - timeout: wait for the element

        Returns:
        - True if an element present, False otherwise.
        -The until method waits until a certain condition is true or until a timeout occurs.
        """
        try:
            element = self.wait.until(
                EC.presence_of_element_located((locator_strategy, locator_value))
                and EC.visibility_of_element_located((locator_strategy, locator_value))
                and EC.element_to_be_clickable((locator_strategy, locator_value))

            )
            # Scroll Action to the element
            self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
            # Focus Action on the element
            self.driver.execute_script("arguments[0].focus();", element)
            return True
        except TimeoutException:
            self.logger.error(f"{view}: Timed out waiting for element {locator_value} .")
            return False
        except Exception as e:
            print(f"{view}: Element {locator_value} not present. Skipping action. Exception: {e}")
            self.logger.error(f"{view}: Element {locator_value} not present. Skipping action. Exception:")
            return False


class ActionOnElementUsingJavaScript(ElementPresenceCheck):
    def __init__(self, driver):
        super().__init__(driver)

    def js_send_txt_to_elm(self, locator_strategy, locator_value, send_text, view):
        """
        Send text to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - send_text: The text to be sent to the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.driver.execute_script(f"arguments[0].value = '{send_text}';", element)
            self.logger.info(f"{view}: {send_text} Sent Successfully")
        else:
            self.logger.error(f"{view} :Element {locator_value} not enabled. Skipping send text action.")

    def js_click_on_elm(self, locator_strategys, locator_values, views):
        """
        Click to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategys, locator_values, views):
            element = self.wait.until(EC.presence_of_element_located((locator_strategys, locator_values)))
            self.wait.until(EC.element_to_be_clickable(element))
            self.driver.execute_script("arguments[0].click();", element)
            self.logger.info(f"{views} Clicked!")
        else:
            self.logger.error(f"{views} :Element {locator_values} not enable. Skipping click action.")

    def js_get_vld_txt(self, locator_strategy, locator_value, view):
        """
        Get the validation text to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            validation_text = self.driver.execute_script(
                f"return document.querySelector('{locator_value}').textContent")
            self.logger.info(f"{view}:Get Validation Text Successfully ! {validation_text}")
            return validation_text
        else:
            self.logger.error(f"{view} :Element {locator_value} not enabled. Skipping get validation action.")


class ActionOnElementUsingSelenium(ElementPresenceCheck):
    def __init__(self, driver):
        super().__init__(driver)

    def sm_move_and_send_text(self, locator_strategy, locator_value, view, send_keys):
        """
        Clicks on the element if it is present, otherwise logs an error message.

        Args:
            locator_strategy (str): The strategy used to locate the element.
            locator_value (str): The value used with the locator strategy to locate the element.
            view (str): The view or context where this action is being performed.
            send_keys (str): The text to be sent to the element.

        Returns:
            None

        Raises:
            NoSuchElementException: If the element is not found.

        Notes:
            - This method uses JavaScript to click on the element.
            - The element is clicked and held, and then the text is sent using the `send_keys` parameter.
            - The element is clicked and held to ensure that the text is sent to the correct location.
            - The `perform` method is called to execute the action.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            element_x, element_y = element.location['x'], element.location['y']
            action = ActionChains(self.driver)
            action.move_to_element(element).click_and_hold().move_by_offset(element_x, element_y).send_keys(
                send_keys).perform()
            self.logger.info(f"{view}: {send_keys} Sent Successfully")
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping click action.")

    def return_elm_from_root_elm(self, locator_strategy, locator_value, view, elm_locator_strategy, elm_locator_value,
                                 elm_view):
        """
        Return the element if it is present, otherwise return None.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        try:
            form_elm = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.logger.info(f"{view} Switched to form Successfully!")

            if form_elm:
                elm = form_elm.find_element(elm_locator_strategy, elm_locator_value)
                if elm:
                    self.logger.info(f"{elm_view} Returned Element Successfully!")
                    return elm
                else:
                    self.logger.warning(f"{elm_view}: Element {elm_locator_value} not found. Returning None.")
                    return None
            else:
                self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
                return None

        except NoSuchElementException:
            self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
            return None

    def return_elms_from_root_elm(self, locator_strategy, locator_value, view, elm_locator_strategy, elm_locator_value,
                                  elm_view):
        """
        Return the element if it is present, otherwise return None.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        try:
            form_elm = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.logger.info(f"{view} Switched to form Successfully!")

            if form_elm:
                elm = form_elm.find_elements(elm_locator_strategy, elm_locator_value)
                if elm:
                    self.logger.info(f"{elm_view} Returned Element Successfully!")
                    return elm
                else:
                    self.logger.warning(f"{elm_view}: Element {elm_locator_value} not found. Returning None.")
                    return None
            else:
                self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
                return None

        except NoSuchElementException:
            self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
            return None

    def sm_return_elm(self, locator_strategy, locator_value, view=None):
        """
        Return the element presence inside form if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - send_text: The text to be sent to the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            elm = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            # to avoid return element successfully message in logger info , I had used print
            # print(f"Return Element Successfully!")
            self.logger.info(f"{view}")
            return elm
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping send text action.")

    def sm_send_txt_to_elm(self, locator_strategy, locator_value, send_text, view):
        """
        Send text to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - send_text: The text to be sent to the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            element.clear()
            element.send_keys(send_text)
            element.send_keys(Keys.ENTER)
            self.logger.info(f"{view}: {send_text} Sent!")
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping send text action.")

    def sm_send_txt_to_elm_using_root_elm(self, locator_strategy, locator_value, send_text, view, elm_locator_strategy,
                                          elm_locator_value, elm_view):
        """
        Send text to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - send_text: The text to be sent to the element.
         - view: The view or context where this action is being performed.
        """
        try:
            form_elm = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.logger.info(f"{view} Switched to form Successfully!")

            if form_elm:
                elm = form_elm.find_element(elm_locator_strategy, elm_locator_value)
                if elm:
                    self.logger.info(f"{elm_view} Returned Element!")
                    elm.send_keys(send_text)
                    self.logger.info(f"{elm_view} Sent!")
                else:
                    self.logger.warning(f"{elm_view}: Element {elm_locator_value} not found. Returning None.")
                    return None
            else:
                self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
                return None

        except NoSuchElementException:
            self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
            return None

    def sm_move_and_click_on_elm(self, locator_strategy, locator_value, view):
        """
        Click to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element .
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            action = ActionChains(self.driver)
            action.move_to_element(element).click().perform()
            self.logger.info(f"Clicked on {view}!")
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping click action.")

    def sm_click_on_elm(self, locator_strategy, locator_value, view):
        """
        Click to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element .
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            element.click()
            self.logger.info(f"{view} : Clicked !")
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping click action.")

    def sm_get_vld_txt(self, locator_strategy, locator_value, view):
        """
        Get the validation text to the element if it is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            driver.execute_script("arguments[0].focus();", element)
            validation_text = driver.execute_script(
                "return document.querySelector('div.alert.alert-success.alert-dismissible.fade.show').textContent")
            self.logger.info(f"{view}:Get Validation Text Successfully !")
            return validation_text
        else:
            self.logger.error(f"{view} :Element {locator_value} not enable. Skipping get validation action.")

    def sm_switch_to_iframe(self, locator_strategy, locator_value, view):
        """
        get the element and switch to the element if it is present, else log an error message.
        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            iframe = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.driver.switch_to.frame(iframe)
            self.logger.info(f"{view} Switched to Iframe !")
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping click action.")

    def sm_get_the_elm_from_the_root_and_clk(self, locator_strategy, locator_value, view, elm_locator_strategy,
                                             elm_locator_value, elm_view):
        """
        Get the Form element and the  use that form element switch to the target element if it is present, else log an error message.
        Parameters:
         - locator_strategy: The strategy used to locate the form element
         - locator_value: The value used with the locator strategy to locate the form element.
         - view: The view or context where this action is being performed.
         - elm_locator_strategy: The strategy used to locate the element
         - elm_locator_value: The value used with the locator strategy to locate the element.
         - elm_view: The view or context where this action is being performed.
        """
        try:
            form_elm = self.driver.find_element(locator_strategy, locator_value)
            self.logger.info(f"{view} Switched to form Successfully!")

            if form_elm:
                elm = form_elm.find_element(elm_locator_strategy, elm_locator_value)
                self.driver.execute_script("arguments[0].scrollIntoView(true);", elm)  # Scroll Action
                if elm:
                    self.logger.info(f"{elm_view} Returned Element Successfully!")
                    elm.click()
                    self.logger.info(f"{elm_view}Clicked !")
                else:
                    self.logger.warning(f"{elm_view}: Element {elm_locator_value} not found. Returning None.")
                    return None
            else:
                self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
                return None

        except NoSuchElementException:
            self.logger.warning(f"{view}: Element {locator_value} not found. Returning None.")
            return None

    def sm_alerts_acceptance(self):
        """
        Accepts the alert that appears on the current page.

        Returns:
         - alert_txt: The text of the alert before accepting it.
        """
        try:
            Alert = self.driver.switch_to.alert
            alert_txt = Alert.text
            Alert.accept()
            return alert_txt
        except Exception as e:
            print(f"No alert found {e}")
            self.logger.info("No alert found")

    def sm_alerts_dismiss(self):
        """
        Dismisses the alert that appears on the current page.

        Returns:
         - alert_txt: The text of the alert before dismissing it.
        """
        try:
            Alert = self.driver.switch_to.alert
            alert_txt = Alert.text
            Alert.dismiss()
            return alert_txt
        except Exception as e:
            print(f"No alert found {e}")
            self.logger.info("No alert found")

    def sm_elm_attribute(self, locator_strategy, locator_value, view, attribute_value):
        """
        get the element and switch to the element if it is present, else log an error message.
        Parameters:
         - locator_strategy: The strategy used to locate the element
         - locator_value: The value used with the locator strategy to locate the element.
         - view: The view or context where this action is being performed.
        """

        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.driver.execute_script("arguments[0].focus();", element)
            element_attribute = element.get_attribute(attribute_value)
            self.logger.info(f"{view} Attribute of the Element: {element_attribute}")
            return element_attribute
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping get attribute action.")

    def sm_return_list_of_elms(self, locator_strategy, locator_value, view):
        """
        Return a list of elements based on the locator strategy and value if the element is present, else log an error message.

        Parameters:
         - locator_strategy: The strategy used to locate the elements.
         - locator_value: The value used with the locator strategy to locate the elements.
         - view: The view or context where this action is being performed.

        Returns:
         - element: A list of elements if found, otherwise None
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            # time.sleep(2) # Make Common function for all elements to use and attempt to hold the page to load the frame completely
            element = self.wait.until(EC.presence_of_all_elements_located((locator_strategy, locator_value)))
            return element
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping get attribute action.")

    def wait_for_page_load(self):
        """
          Wait for the page to load completely before proceeding with the next actions.
        """
        self.wait.until(
            lambda driver: driver.execute_script('return document.readyState') == 'complete'
        )

    def switch_to_frame(self, locator_strategy, locator_value, view):
        """
        Switches the WebDriver to the specified frame.

        Args:
            locator_strategy (str): The strategy to locate the frame.
            locator_value (str): The value to locate the frame.
            view (str): The view where the frame is located.

        Returns:
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            iframe = self.wait.until(EC.presence_of_element_located((locator_strategy, locator_value)))
            self.driver.switch_to.frame(iframe)
            print(f"{view}Frame switched successfully")
        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping get attribute action.")

    def get_hover_text(self, locator_strategy, locator_value, view):
        """
        Get the hover text of an element.

        Args:
            locator_strategy (str): The strategy to locate the element.
            locator_value (str): The value to locate the element.
            view (str): The view where the element is located.

        Returns:
            str: The hover text of the element.
        """
        if self.checks_for_elm_presence(locator_strategy, locator_value, view):
            element = self.sm_return_elm(locator_strategy=locator_strategy, locator_value=locator_value, view=view)
            # Create a new ActionChains object
            actions = ActionChains(self.driver)
            # Hover over the element
            actions.move_to_element(element).perform()
            # Get the text of the element if required
            text = element.text
            return text

        else:
            self.logger.error(f"{view}: Element {locator_value} not enabled. Skipping get attribute action.")

    def refresh_page(self):
        """
        Refreshes the current page.
        """
        self.driver.refresh()
