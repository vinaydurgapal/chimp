from selenium import webdriver

# Create a new instance of the Chrome driver
driver = webdriver.ChromeOptions()

# Navigate to a webpage
driver.get("https://example.com")

# Define a function to be executed in the browser context
def is_element_visible(element_selector):
    return driver.execute_script(
        """
        const observer = new IntersectionObserver((entries) => {
            const isVisible = entries[0].isIntersecting;
            observer.disconnect();
            return isVisible;
        });
        observer.observe(document.querySelector('{}'));
        """.format(element_selector)
    )
# Use the function to check if an element is visible
element_selector = "#my-element"
is_visible = is_element_visible(element_selector)
print("Element is visible:", is_visible)

# Close the browser